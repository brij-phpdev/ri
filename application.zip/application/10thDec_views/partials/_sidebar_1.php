  <div class="page-body">
      <!-- partial:partials/_sidebar.html -->
      <div class="sidebar">
        <div class="user-profile">
          <div class="display-avatar animated-avatar">
            <img class="profile-img img-lg rounded-circle" src="<?php echo base_url();?>assets/images/profile/male/image_1.png" alt="profile image">
          </div>
          <div class="info-wrapper">
            <p class="user-name"><?php echo $first_name ?></p>
            <h6 class="display-income">Field Coordinator</h6>
          </div>
        </div>
        <ul class="navigation-menu">
          <li class="nav-category-divider">MAIN</li>
          <li>
            <a href="<?php echo base_url();?>index.php/anm/index">
              <span class="link-title">Today's Due List</span>
              <i class="mdi mdi-gauge link-icon"></i>
            </a>
          </li>
          <li>
		<a href="#vaccination-data" data-toggle="collapse" aria-expanded="false">
              <span class="link-title">Vaccination Data</span>
              <i class="mdi mdi-users link-icon"></i>
            </a>
            <ul class="collapse navigation-submenu" id="vaccination-data">
		<li>
            <a href="<?php echo base_url();?>index.php/mothers/list">
              <span class="link-title">Mother List</span>
              <i class="mdi mdi-user-circle link-icon"></i>
            </a>
		</li>
		<li>
            <a href="<?php echo base_url();?>index.php/anm/done_list">
              <span class="link-title">Vaccination Done(Today)</span>
              <i class="mdi mdi-user-circle link-icon"></i>
            </a>
		</li>
		<li>
            <a href="<?php echo base_url();?>index.php/mothers/search">
              <span class="link-title">Mother Search</span>
              <i class="mdi mdi-user-circle link-icon"></i>
            </a>
		</li>
		<li>
                <a href="#" target="_blank">Ladies (pregnant)</a>
              </li>
            </ul>
          </li>

          <li style="display: none";>
            <a href="#sample-pages" data-toggle="collapse" aria-expanded="false">
              <span class="link-title">Collected Data</span>
              <i class="mdi mdi-flask link-icon"></i>
            </a>
            <ul class="collapse navigation-submenu" id="sample-pages">
		<li>
                <a href="add_vaccination">Add Vaccination</a>
              </li>
		<li>
                <a href="<?php echo base_url();?>index.php/coordinator/import">Import Data</a>
              </li>
		<li>
                <a href="<?php echo base_url();?>index.php/coordinator/profile">Profile</a>
              </li>
              <li>
                <a href="#" target="_blank">Kids</a>
              </li>
              <li>
                <a href="#" target="_blank">Ladies (pregnant)</a>
              </li>
            </ul>
          </li>
          <li style="display: none;">
            <a href="#ui-elements" data-toggle="collapse" aria-expanded="false">
              <span class="link-title">Target</span>
              <i class="mdi mdi-bullseye link-icon"></i>
            </a>
            <ul class="collapse navigation-submenu" id="ui-elements">
              <li>
                <a href="pages/ui-components/buttons.html">Kids</a>
              </li>
              <li>
                <a href="pages/ui-components/tables.html">Ladies (pregnant)</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="<?php echo base_url();?>index.php/anm/profile">
              <span class="link-title">Edit Profile</span>
              <i class="mdi mdi-clipboard-outline link-icon"></i>
            </a>
          </li>
          <li style="display: none;">
            <a href="pages/charts/chartjs.html">
              <span class="link-title">Reports</span>
              <i class="mdi mdi-chart-donut link-icon"></i>
            </a>
          </li>
          
          <li class="nav-category-divider">Support</li>
          <li>
            <a href="#">
              <span class="link-title">Ticket</span>
              <i class="mdi mdi-ticket link-icon"></i>
            </a>
          </li>
	<li>
		<a href="../user/logout">Logout</a>
	</li>
        </ul>
      </div>
