 <!-- partial -->
      <div class="page-content-wrapper">
        <div class="page-content-wrapper-inner">
          <div class="content-viewport">
            <div class="row">
              <div class="col-12 py-5">
                <h4>Dashboard</h4>
                <p class="text-gray">Welcome aboard, <?php echo $first_name ?></p>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="grid">
                  <p class="grid-header">Search For Mother Details</p>
                  <div class="grid-body">
                    <div class="item-wrapper">
                      <div class="row">
                        <div class="col-md-8 mx-auto">
                          <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                              <label for="inputType12">Mobile</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
				<form method="post">
                              <input type="text" class="form-control form-control-lg" id="mother_mobile" placeholder="9876543210">
				</form>
				<br/>
				<div id="mother_data_result_div" class="table-responsive">
					<table class="table info-table table-dark" id="mother_search_result">
						<thead><tr><th>Mother Name</th><th>Mobile Number</th><th>Area code</th><th>Asha Name</th></tr></thead>
						<tbody></tbody>
						
					</table>
				</div>
                            </div>
                          </div>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content viewport ends -->

