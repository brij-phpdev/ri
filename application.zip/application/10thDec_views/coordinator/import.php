
  
      <!-- partial -->
      <div class="page-content-wrapper">
        <div class="page-content-wrapper-inner">
          <div class="content-viewport">
            <div class="row">

              <div class="col-lg-12">
                <div class="grid">
                  <p class="grid-header">CSV Import</p>
                  <div class="grid-body">
                    <div class="item-wrapper">
                      <div class="row mb-3">
                        <div class="col-md-8 mx-auto">

			<form method="post" id="import_csv" enctype="multipart/form-data">
	<div class="form-group row showcase_row_area">
                    <div class="row showcase_row_area mb-3">
                            <div class="col-md-3 showcase_text_area">
                              <label>File Upload</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input" name="csv_file" id="csv_file" required accept=".csv" >
                                <label class="custom-file-label" for="csv_file">Choose file</label>
                              </div>
                            </div>
                          </div>
			</div>

                    <button type="submit" id="import_csv_btn" class="btn btn-sm btn-primary"> Import </button>

                  </form>

                        </div>
                      </div>
<div id="imported_csv_data"></div>
                    </div>
                  </div>
                </div>
              </div>

	</div>
	<div class="row">
		<div class="col-lg-12">
                <div class="grid">
                  <p class="grid-header">Confirm the CSV column(s)</p>
                  <div class="item-wrapper">
                    <div class="table-responsive">
                      <table class="table info-table table-striped" id="csv_column">
                        <thead>
                          <tr>
                            <th>Data to be saved</th>
                            <th>CSV Column</th>
                          </tr>
                        </thead>
                        <tbody>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content viewport ends -->


<?php
$username = "Mother";
$password = " Name";
/*
if(stripos("abc", "a")!==false) { 
  echo "Yes";
} else {
  echo "No";
}*/

echo (stripos($username, $password)==false);

echo (compareStrings($username, $password, 5)!==false) ? "no" : "Matched $username & it was for $password";

function compareStrings($firstString, $secondString, $maxInCommon)
{
	for ($i = 0; $i <= strlen($firstString) - $maxInCommon; $i ++) {
		if (strpos(strtolower($secondString), strtolower(substr($firstString, $i, $maxInCommon))) !== false) {
			return false;
		}
	}
	return true;
}
?>
 
