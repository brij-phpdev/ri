
<!-- partial -->

<div class="row">

    <div class="col-md-12">
        <div class="grid">
            
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-6">
                            <div id="msg" class="alert alert-success success"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="grid-header panel-title">आज की टीकाकरण सूची (पूर्ण)</h3>
                        </div>
                    </div>
                    
                </div>
                <div class="table-responsive table-responsive-md table-responsive-sm table-responsive-lg table-responsive-xl panel-body" id="vaccination_done_list">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr class="solid-header">
                                <td>मां का नाम</td>
                                <td>बच्चे का नाम</td>
                                <td>मोबाइल नंबर</td>
                                <td>टीका</td>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

</div>