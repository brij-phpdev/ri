
<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="<?php echo base_url(); ?>anm/index"><img src="<?php echo base_url(); ?>/assets/images/logo.png" alt="site logo" width="50%" /></a>
    <button id="mobile-nav" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#top-nav" aria-controls="top-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="top-nav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="#"><?php echo $this->lang->line('welcome_message'); ?>, <span class="anm_detail_name"></span> [ <span class="anm_detail_mobile"></span> ] <?php echo $this->lang->line('date') ?> <strong class="active"><?php echo date('d-m-Y') ?></strong></a>
            </li>
            <li class="nav-item <?php echo $this->uri->segment(2) == "index" ? 'active' : ''; ?>">
                <a class="nav-link" href="<?php echo base_url(); ?>anm/index"><?php echo $this->lang->line('todays_due_vaccine_list') ?></a>
            </li>
            <li class="nav-item <?php echo $this->uri->segment(2) == "done_list" ? 'active' : ''; ?>">
                <a class="nav-link" href="<?php echo base_url(); ?>anm/done_list"><?php echo $this->lang->line('todays_done_vaccine_list') ?></a>
            </li>
            <!--      <li class="nav-item">
                    <a class="nav-link" href="<?php // echo base_url();  ?>index.php/mothers/search">मोबाइल खोजें</a>
                  </li>-->
            <li class="nav-item <?php echo $this->uri->segment(2) == "add_new_mother" ? 'active' : ''; ?>">
                <a class="nav-link" href="<?php echo base_url(); ?>anm/add_new_mother"><?php echo $this->lang->line('new_entry_mother_or_child') ?></a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo base_url(); ?>index.php/user/logout"><?php echo $this->lang->line('logout') ?></a>
            </li>
        </ul>

    </div>
</nav>

<main role="main" class="container">

