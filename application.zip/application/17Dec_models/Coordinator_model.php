<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coordinator_model extends CI_Model{
    
    function __construct() {
        // Set table name
	parent::__construct();
	$this->load->library('CSVReader');
    }

	public function getTableForCsvTitles(){

		// If file uploaded
                if(is_uploaded_file($_FILES['csv_file']['tmp_name'])){
                    // Load CSV reader library

		
		    // column array..
		    $columnArr = array("Mother", "Father", "Child", "Child D.O.B", "Contact Number", "Additional Number", "Last Vacination", "Vaccination Date","ANM Name","Asha Name","Location");                    

                    // Parse data from CSV file
                    $csvTitles = $this->csvreader->parse_csv_titles($_FILES['csv_file']['tmp_name']);

		$table ='<table class="">';
	
		foreach($columnArr as $c => $column):
		
			$table .= '<tr><td>'.$column.'</td>';

			$csvTitlesSelect = '<select class="custom-select">';
			$selected = '';
			$csvTitlesSelect .= '<option value=""> Select One Column </option>';
			if(count($csvTitles)):
				foreach($columnArr as $c => $column):
//					$selected =  (stripos($csvTitles[$c+1],$column)!==false) ? 'selected="selected"' : "" ;
//					$csvTitlesSelect .= '<option '.$selected.' value="'.$c.'">'.($c).$csvTitle.'=>'. $columnArr[$c].'</option>';
					$selected =  ($this->compareStrings($column,$csvTitles[$c+1],5)!==false) ? '' : 'selected="selected"'; // +1 just to skip S.No
					$csvTitlesSelect .= '<option '.$selected.' value="'.$c.'">'.$csvTitles[$c+1].'-'.$column.'</option>';
				endforeach;
			$csvTitlesSelect .= '</select>';
			endif;
			endforeach;
		$table .='</table>';	
			
                    echo $csvTitlesSelect;
		}
	}
}
