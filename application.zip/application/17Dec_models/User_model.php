<?php

Class User_model extends CI_Model {

// Insert registration data in database
    public function registration_insert($data) {

// Query to check whether username already exist or not
        $condition = "user_name =" . "'" . $data['user_name'] . "'";
        $this->db->select('*');
        $this->db->from('user_login');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {

// Query to insert data in database
            $this->db->insert('user_login', $data);
            if ($this->db->affected_rows() > 0) {
                return true;
            }
        } else {
            return false;
        }
    }

// Read data using username and password
    public function login($data) {

        $condition = "mobile =" . "'" . $data['mobile'] . "' AND " . "login_code =" . "'" . $data['code'] . "'";
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();
        $str = $this->db->last_query();

        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }

// Read data from database to show data in admin page
    public function read_user_information($mobile) {

        $condition = "mobile =" . "'" . $mobile . "'";
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }

// Read data from database to show data in admin page
    public function get_mother_detials($mobile_number) {

        $condition = "mthrs_mbl_no LIKE " . "'" . $mobile_number . "%'";
        $this->db->select('*');
        $this->db->from('mothers_details');
        $this->db->where($condition);
        $this->db->limit(10);
        $query = $this->db->get();
//echo $query->num_rows();
        /* $str = $this->db->last_query();

          echo "<pre>";
          print_r($str);
          exit;
         */
//	if ($query->num_rows() > 0) {
        return $query->result();
//	} else {
//		return false;
//	}
    }

}

?>
