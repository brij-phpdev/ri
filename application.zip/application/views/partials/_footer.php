</main>
<!--page body ends -->


<!-- endbuild -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->


<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<!--<script src="<?php echo base_url(); ?>assets/vendors/js/core.js"></script>-->

<?php if (is_array($js_to_load)) : ?>
    <?php foreach ($js_to_load as $row): ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/<?= $row; ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
<script>
    $(document).ready(function () {
        $('#mobile-nav').on('click', function () {
            $("#top-nav").toggle('slow');
        });
    });

</script>

</body>
</html>
