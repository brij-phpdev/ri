<?php
$mobile = $this->uri->segment(3);
?>


<style>
    
.chckbxcls{


width: 33% !important;
float: left;
}


.chcklbls{

font-size: 13px;

}

</style>



<div class="row">

    <div class="col-md-12 col-12 col-sm-12 col-lg-12">

        <div class="grid">
            <p class="grid-header">माँ / बच्चे की नई इंट्री करें</p>
            <div class="grid-body">
                <div class="row">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12 alert alert-success" id="msg">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12">

                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">मोबाइल नंबर</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <input type="text" class="form-control" name="mobile" id="mobile" <?php echo isset($mobile) ? 'readonly="readonly"' : '' ?> value="<?php echo isset($mobile) ? $mobile : '' ?>" placeholder="मोबाइल नंबर">
                            </div>
                        </div>

                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">मां का नाम</label>
                            </div>

                            <div class="col-md-9 showcase_content_area">
                                <div class="table-responsive" id="mother_details">

                                    <div class="options" >
                                        <table id="table" class="table table-bordered">
                                            <tbody>
                                            </tbody>

                                        </table>
                                    </div> 
                                </div>
                                    <input type="text" class="form-control" id="mother_name" name="mother_name" value="" placeholder="मां का नाम">
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">बच्चे का नाम</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <input type="text" class="form-control" id="child_name" name="child_name" value="" placeholder="बच्चे का नाम">
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">बच्चे की जन्म तिथि</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <input type="date" data-provide="datepicker" class="form-control" id="child_dob" value="" name="child_dob">

                            </div>
                        </div>
                        <div class="form-group row showcase_row_area hidden">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">एएनएम का नाम</label>
                            </div>
                            <div class="col-md-9 showcase_content_area hidden">
                                <input type="text" class="form-control" id="anm_name" value="" name="anm_name">
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area hidden hidden-lg hidden-md hidden-sm hidden-xs">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">अनम फोन नंबर</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <input type="text" class="form-control" id="anm_contact" value="" name="anm_contact">
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">आशा का नाम</label>
                            </div>
                            <div id="asha_name_list" class="col-md-9 showcase_content_area">

                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">स्थान का नाम</label>
                            </div>
                            <div id="area_name_list" class="col-md-9 showcase_content_area">

                            </div>
                        </div>


                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">टीकाकरण जो किया गया है</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <div id="vaccination_array">

                                </div>
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1"></label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <button class="btn btn-warning my-2 my-sm-0" type"submit" id="add_mother" value="Update">इंट्री करें</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script>

    get_mothers_by_phone('<?php echo $mobile ?>');

    function get_mothers_by_phone(phone_number) {

        $.ajax({
            url: api_url + "api/get_mothers_by_phone/",
            method: "POST",
            data: JSON.stringify({"mobile": phone_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $("#msg").hide();
            },
            success: function (data)
            {

                if (data.status == '200') {
                    var myObj = data.data;
                    var mother_list = '';
                    mother_list += '<tr>';
                    for (var m in myObj) {
                        mother_list += '<td><button class="btn btn-success setMotherName" data-title="' + myObj[m].mthrs_name + '" >' + myObj[m].mthrs_name + '</button></td>';
                    }
                    mother_list += '</tr>';
                    $("#mother_details tbody").append(mother_list);
                    $("button.setMotherName").on("click", function () {
                        //
                        var mother_name = $(this).attr('data-title');
                        $("#mother_name").val(mother_name);
                    });

                } else {
//                                    $("msg").addClass('alert alert-warning').removeClass('alert-success').text('no details found!');
                }

            }
        });
    }


</script>
