
      


 
      <?php
      //flash messages
      if($this->session->flashdata('flash_message')){
        if($this->session->flashdata('flash_message') == 'updated')
        {
          echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Well done!</strong> product updated with success.';
          echo '</div>';       
        }else{
          echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
          echo '</div>';          
        }
      }
      ?>
      
      <?php
      //form data
      $attributes = array('class' => 'form-horizontal', 'id' => '');

      //form validation
      echo validation_errors();

      echo form_open('admin/anm/update/'.$this->uri->segment(4).'', $attributes);

      ?>
        <fieldset>
          <div class="control-group">
            <label for="inputError" class="control-label">Anm name</label>
            <div class="controls">
              <input type="text" id="" name="anm_name" value="<?php echo $anm[0]->anm_name; ?>" >
              <!--<span class="help-inline">Woohoo!</span>-->
            </div>
          </div>
          <div class="control-group">
            <label for="inputError" class="control-label">Mobile Number</label>
            <div class="controls">
              <input type="text" id="" name="mobile_number" value="<?php echo $anm[0]->mobile_number; ?>">
              <!--<span class="help-inline">Cost Price</span>-->
            </div>
          </div>          
         
        
          <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save changes</button>
            <button class="btn" type="reset">Cancel</button>
          </div>
        </fieldset>

      <?php echo form_close(); ?>


     