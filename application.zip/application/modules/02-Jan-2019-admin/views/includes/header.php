<!DOCTYPE html> 
<html lang="en-US">
    <head>
        <title>OKC | RI | Admin Panel</title>
        <meta charset="utf-8">
        <link href="<?php echo base_url(); ?>assets/css/admin/global.css" rel="stylesheet" type="text/css">
        <!--<link href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">-->
        <link href="<?php echo base_url() ?>assets/css/datatable/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

    </head>

    <body>


        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="brand" href="<?php echo base_url(); ?>admin/dashboard"><img src="<?php echo base_url(); ?>/assets/images/logo.png" alt="site logo" width="50%" /></a>
                    <ul class="nav">


                        <li class="nav-item <?php echo $this->uri->segment(2) == "anm" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/anm">ANM</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(2) == "asha" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/asha">Asha</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(2) == "locations" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/locations">Locations</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(2) == "anm_location_asha" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/anm_location_asha">ANM/ASHA</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(2) == "child" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/child">Child</a>
                        </li>
            <!--                        <li class="nav-item <?php echo $this->uri->segment(2) == "index" ? 'active' : ''; ?>">
                                        <a class="nav-link" href="<?php echo base_url(); ?>anm/index"><?php echo $this->lang->line('todays_due_vaccine_list') ?></a>
                                    </li>-->
                        <li class="nav-item <?php echo $this->uri->segment(2) == "done_list" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/done_list"><?php echo $this->lang->line('todays_done_vaccine_list') ?></a>
                        </li>
                        <!--                        <li class="nav-item">
                                                    <a class="nav-link" href="<?php // echo base_url();     ?>index.php/mothers/search">मोबाइल खोजें</a>
                                                </li>-->
<!--                        <li class="nav-item <?php echo $this->uri->segment(2) == "add_new_mother" ? 'active' : ''; ?>">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/add_new_mother"><?php echo $this->lang->line('new_entry_mother_or_child') ?></a>
                        </li>-->

                        <li class="nav-item ">
                            <a class="nav-link" href="<?php echo base_url(); ?>admin/logout"><?php echo $this->lang->line('logout') ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>	



        <div class="container top">

            <ul class="breadcrumb">
                <li>
                    <a href="<?php echo site_url("admin/dashboard"); ?>">
                        <?php echo ucfirst($this->uri->segment(1)); ?>
                    </a> 
                    <span class="divider">/</span>
                </li>
                <li class="active">
                    <?php echo str_replace('_', ' ', ucfirst($this->uri->segment(2))); ?>
                </li>
            </ul>

            <?php
            $add_button_exclude_array = array('dashboard', 'done_list');
            ?>

            <div class="page-header users-header">
                <h2>
                    <?php echo str_replace('_', ' ', ucfirst($this->uri->segment(2))); ?>
                    <?php if (empty($this->uri->segment(3)) && !in_array($this->uri->segment(2), $add_button_exclude_array)): ?>
                        <a  href="<?php echo site_url("admin") . '/' . $this->uri->segment(2); ?>/add" class="btn btn-success">Add a new</a>
                    <?php endif; ?>
                </h2>
            </div>
