<!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">-->
<style type="text/css">
    .btn{
        color: #fff;
        font-size: 16px !important;
    }
    td{

       /* width: 33.5%;*/
    border: 1px solid #f2f4f9;
    padding: 10px;
    }


    ul.ks-cboxtags {
    list-style: none;
    padding: 20px;
}
ul.ks-cboxtags li{
  display: inline;
}
ul.ks-cboxtags li label{
    display: inline-block;
    background-color: rgba(255, 255, 255, .9);
    border: 2px solid rgba(139, 139, 139, .3);
    color: #adadad;
    border-radius: 25px;
    white-space: nowrap;
    margin: 3px 0px;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-tap-highlight-color: transparent;
    transition: all .2s;
}

ul.ks-cboxtags li label {
    padding: 8px 12px;
    cursor: pointer;
}

ul.ks-cboxtags li label::before {
    display: inline-block;
    font-style: normal;
    font-variant: normal;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    font-size: 12px;
    padding: 2px 6px 2px 2px;
    content: "\f067";
    transition: transform .3s ease-in-out;
}

ul.ks-cboxtags li input[type="checkbox"]:checked + label::before {
    content: "\f00c";
    transform: rotate(-360deg);
    transition: transform .3s ease-in-out;
}

ul.ks-cboxtags li input[type="checkbox"]:checked + label {
    border: 2px solid #1bdbf8;
    background-color: #12bbd4;
    color: #fff;
    transition: all .2s;
}

ul.ks-cboxtags li input[type="checkbox"] {
  display: absolute;
}
ul.ks-cboxtags li input[type="checkbox"] {
  position: absolute;
  opacity: 0;
}
ul.ks-cboxtags li input[type="checkbox"]:focus + label {
  border: 2px solid #e9a1ff;
}
</style>

<div class="row">

    <div class="col-md-12">

        <div class="grid">
            <p class="grid-header">माँ / बच्चे की नई इंट्री करें</p>
            <div class="grid-body">
                <div class="row">
                    <div class="col-md-8 alert alert-success" id="msg">
                    </div>
                </div>
             

    <!--                     <div class="user-content" style="display: none;">
    <h4>User Details</h4>
    <p>Name: <span id="userName"></span></p>
   
    <p>Phone: <span id="userPhone"></span></p>
    <p>Unique No: <span id="userUnique"></span></p>
</div> -->


<!-- <div class="table-responsive">          
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Age</th>
        <th>City</th>
        <th>Country</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Anna</td>
        <td>Pitt</td>
        <td>35</td>
        <td>New York</td>
        <td>USA</td>
      </tr>
    </tbody>
  </table>
  </div> -->
  <div class="row">

    <div class="col-md-12">
      <label>Child Name : </label> Rajesh Kumar
    </div>
     <div class="col-md-12">
      <label>Child Dob : </label> 15 Dec 2018
    </div>
     
  <form method="post" action="">
<div class="container">
  <ul class="ks-cboxtags">

    <li><input type="checkbox" id="checkboxOne" value="Rainbow Dash"><label for="checkboxOne">Hep B</label></li>
    <li><input type="checkbox" id="checkboxTwo" value="Cotton Candy" checked><label for="checkboxTwo">BCG</label></li>
    <li><input type="checkbox" id="checkboxThree" value="Rarity" checked><label for="checkboxThree">OPV0</label></li>
    <li><input type="checkbox" id="checkboxFour" value="Moondancer"><label for="checkboxFour">OPV1</label></li>
    <li><input type="checkbox" id="checkboxFive" value="Surprise"><label for="checkboxFive">IPV1</label></li>
    <li><input type="checkbox" id="checkboxSix" value="Twilight Sparkle" checked><label for="checkboxSix">DPT1
                    </label></li>
    <li><input type="checkbox" id="checkboxSeven" value="Fluttershy"><label for="checkboxSeven">PENTA1</label></li>
    <li><input type="checkbox" id="checkboxEight" value="Derpy Hooves"><label for="checkboxEight">RVV1</label></li>
    <li><input type="checkbox" id="checkboxNine" value="Princess Celestia"><label for="checkboxNine">OPV2
                    </label></li>
    <li><input type="checkbox" id="checkboxTen" value="Gusty"><label for="checkboxTen">DPT2</label></li>
    <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">PENTA2</label></li>
    <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">Clover</label></li>
    <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">RVV2
                    </label></li>
   
  </ul>

  <div class="col-md-12">
<button class="btn btn-success"> Update Vaccines</button>
 </div>

</div>


</form>

  </div></div></div></div></div>


          