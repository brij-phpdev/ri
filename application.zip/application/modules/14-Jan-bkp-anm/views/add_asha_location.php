<?php
//$skip_anm_ids = array(11,13);
//for($i=1;$i<=14;$i++):
//    if(in_array($i, $skip_anm_ids)){
//        continue;
//    }
//    echo "SELECT GROUP_CONCAT(location_id SEPARATOR ', ') as territory_list FROM `anm_asha_relation` WHERE anm_id = $i ORDER BY `location_id` ASC;\r\n";
//endfor;

?>

<div class="row">

    <div class="col-md-12 col-12 col-sm-12 col-lg-12">

        <div class="grid">
            <p class="grid-header">ASHA ANM Location relation view</p>
            <div class="grid-body">
<!--                <div class="row">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12 alert alert-success" id="msg">
                    </div>
                </div>-->
                <div class="row mb-3">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12">
                        <form action="<?php echo base_url(); ?>anm/add_asha_anm_relation" method="post">

                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">एएनएम का नाम</label>
                            </div>
                            <div class="col-md-9 showcase_content_area ">
                                <select name="anm_id">
                                    <option value="">-- select -- </option>
                                <?php foreach ($anm_list as $anm): ?>
                                    <option value="<?php echo $anm->id ?>"><?php echo $anm->anm_name ?> [<?php echo $anm->mobile_number ?>]</option>
                                <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">आशा का नाम</label>
                            </div>
                            <div id="asha_name_list" class="col-md-9 showcase_content_area">
                                <select name="asha_id">
                                    <option value="">-- select -- </option>
                                <?php foreach ($asha_list as $asha): ?>
                                    <option value="<?php echo $asha->id ?>"><?php echo $asha->mobile_number ?> [<?php echo $asha->asha_name ?>]</option>
                                <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">स्थान का नाम</label>
                            </div>
                            <div id="area_name_list" class="col-md-9 showcase_content_area">
                                <select name="location_id">
                                    <option value="">-- select -- </option>
                                <?php foreach ($locations_list as $location): ?>
                                    <option value="<?php echo $location->id ?>"><?php echo $location->territory_en_name ?> [<?php echo $location->territory_name ?>]</option>
                                <?php endforeach; ?>
                                </select>
                            </div>
                        </div>


                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1"></label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <button class="btn btn-warning my-2 my-sm-0" type"submit" id="add_mother" value="Update">इंट्री करें</button>
                            </div>
                        </div>
                    </form>
                    </div>
                    
                    <!--<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">-->
                    
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                            <th>Anm name</th>
                            <th>Asha name</th>
                            <th>Location name</th>
                            <th>Location name(EN)</th>
                            <th>DB id</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                        <?php foreach($anm_asha_arr as $a => $anm_asha): ?>
                                <tr>
                                    <td><?php echo $anm_asha['anm_name'] ?></td>
                                    <td><?php echo $anm_asha['asha_name'] ?> [<?php echo $anm_asha['asha_contact'] ?>] </td>
                                    <td><?php echo $anm_asha['territory_name'] ?></td>
                                    <td><?php echo $anm_asha['territory_en_name'] ?></td>
                                    <td><?php echo $anm_asha['id'] ?></td>
                                </tr>
                        <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>



<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
