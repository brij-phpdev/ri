<?php ?>


<div class="row">

    <div class="col-md-12 col-12 col-sm-12 col-lg-12">

        <div class="grid">
            <div class="grid-body">
                <div class="row">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12 alert alert-success" id="msg">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12 col-12 col-sm-12 col-lg-12">

                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">मोबाइल नंबर</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <div id="child_contact"></div>

                            </div>
                        </div>


                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">बच्चे का नाम</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <div id="child_name"></div>
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">बच्चे की जन्म तिथि</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <div id="child_dob"></div>

                            </div>
                        </div>


                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">टीकाकरण जो किया गया है</label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <span><?php echo $this->lang->line('vaccines_already_given') ?></span>
                                <div style="overflow-y: scroll; height: auto;" id="done_vaccination_array">

                                </div>
                                <strong><?php echo $this->lang->line('todays_vaccine_list') ?></strong>
                                <div style="overflow-y: scroll; height: auto;" id="today_vaccination_array">

                                </div>
                                <span><?php echo $this->lang->line('future_vaccine_list') ?></span>
                                <div style="overflow-y: scroll; height: 175px;" id="future_vaccination_array">

                                </div>
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="vaccine_date"><?php echo $this->lang->line('vaccine_done_date') ?></label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <input type="date" data-provide="datepicker" class="form-control" name="vaccine_date" id="vaccine_date" value="<?php echo date('Y-m-d') ?>" max="<?php echo date('Y-m-d') ?>">
                            </div>
                        </div>
                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1"></label>
                            </div>
                            <div class="col-md-9 showcase_content_area">
                                <button class="btn btn-warning my-2 my-sm-0" type"submit" onclick="update_child_record()" value="Update">अपडेट करें</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
$mobile = $this->uri->segment(4);
$child_id = $this->uri->segment(3);
?>
<script>


    get_child_by_id_and_phone('<?php echo $child_id ?>', '<?php echo $mobile ?>');

    function get_child_by_id_and_phone(child_id, phone_number) {

        $.ajax({
            url: api_url + "api/get_child_by_id_and_phone/",
            method: "POST",
            data: JSON.stringify({"child_id": child_id, "mobile": phone_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $("#msg").hide();
            },
            success: function (data)
            {
//                console.log(data);
                var done_vaccine_output;
                var today_vaccine_output;
                var future_vaccine_output;
                var myObj = data.data;

                $(".child_id").attr('id', myObj.child_id)
                $("#child_name").text(myObj.child_name)
                $("#child_dob").text(myObj.child_dob)
                $("#child_contact").text(myObj.child_contact)
                var done_vaccines = myObj.done_vaccines;
                var today_due_vaccines = myObj.today_due_vaccines;
                var future_due_vaccines = myObj.future_due_vaccines;
                if (done_vaccines == undefined) {
                    done_vaccine_output += '<span><strong>कोई रिकॉर्ड नहीं मिला!</strong></span>';

                }else{
                    for (var done_vaccine in  done_vaccines) {
                        done_vaccine_output += '<label class="custom-input-done">' + done_vaccines[done_vaccine].replace("_", " ").replace("_", " ") + '	&#9745;</label>';
                    }
                }
                
                $("#done_vaccination_array").html(done_vaccine_output.replace('undefined', ''));
                
//                console.log(today_due_vaccines);
                if (today_due_vaccines == undefined) {
                    today_vaccine_output += '<span>कोई रिकॉर्ड नहीं मिला!</span>';

                }else{
                    for (var today_due_vaccine in  today_due_vaccines) {
                        today_vaccine_output += '<label class="custom-input"><input class="form-check-input" type="checkbox" name="vaccination_name[]" value="' + today_due_vaccines[today_due_vaccine] + '">' + today_due_vaccines[today_due_vaccine].replace("_", " ").replace("_", " ") + '<span class="checkmark"></span></label>';
                    }
                }
                
                $("#today_vaccination_array").html(today_vaccine_output.replace('undefined', ''));
                
                if (future_due_vaccines == undefined) {
                    future_vaccine_output += '<span><strong>कोई रिकॉर्ड नहीं मिला!</strong></span>';

                }else{
                    for (var future_due_vaccine in  future_due_vaccines) {
//                        future_vaccine_output += '<label class="custom-input-future">' + future_due_vaccines[future_due_vaccine].replace("_", " ").replace("_", " ") + '</label>';
                        future_vaccine_output += '<label class="custom-input-future"><input type="checkbox" name="vaccination_name[]" value="'+ future_due_vaccines[future_due_vaccine]+'"> ' + future_due_vaccines[future_due_vaccine].replace("_", " ").replace("_", " ") + '</label>';
                    }
                }
                $("#future_vaccination_array").html(future_vaccine_output.replace('undefined', ''));
            }
        });
    }
    
    
    
    function update_child_record() {

        // update record based on selection of vaccinations... and update button click..
//        $(".update_vaccine").on("click", function () {
            if (confirm("<?php echo $this->lang->line('update_conform_msg'); ?>")) {
                // now proceed with updating vaccination..
                var selected_vaccinations = [];
                $.each($("input[name='vaccination_name[]']:checked"), function () {
                    selected_vaccinations.push($(this).val());
                });

                // now hit the update API..
                $.ajax({
                    url: api_url + "api/update_vaccination/",
                    method: "POST",
                    data: JSON.stringify({
                        "vaccination_name": selected_vaccinations,
                        "vaccine_date": $("#vaccine_date").val(),
                        "select": 'true',
                        "child_id": "<?php echo $child_id ?>"
                    }),
                    headers: {
                        "Authorization": token,
                        "User-ID": user_id,
                        "Content-Type": "application/json"
                    },
                    beforeSend: function () {
                        $('#msg').empty();
                    },
                    success: function (data)
                    {
                                    console.log(data);
                        // success
                        if (data.status == '200') {
                            //                    alert(data.message);

                            $("#msg").show().removeClass('alert-warning').addClass('alert-success').html(data.message);
                            $("#msg").scrollTop(0);
//                            alert(data.message);

                                setTimeout(function () {
                                    location.reload();
                                }, 2000);
                           
                        } else {
                            //                    alert(data.message);
                            $("#msg").show().removeClass('alert-success').addClass('alert-warning').html(data.message);

                        }

                    }
                });

            } else {
                alert('cancelled!');
            }
//        });
    }
    

</script>

