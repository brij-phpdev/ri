<?php
if(isset($query)): ?>
<div class="alert alert-danger">
<?php 
foreach ($query as $q => $qry):
    echo  "<br/><strong>Query: {$q} =></strong> ",$qry;
endforeach;
?>
</div>
<?php endif;
?>
</div>	
<div id="footer">
    <hr>
    <div class="inner">
        <div class="container">
            <p class="right"><a href="#">Back to top</a></p>
            <p>
            </p>
        </div>
    </div>
</div>
<script src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/admin.min.js"></script>
<!--<script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>-->
<script src="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.js"></script>

<?php if (is_array($js_to_load)) : ?>
    <?php foreach ($js_to_load as $row): ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/<?= $row; ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
<script>
    $(document).ready(function () {
        $('#mobile-nav').on('click', function () {
            $("#top-nav").toggle('slow');
        });
    });


    $(document).ready(function () {
        $('#myTable').DataTable();
//    $('#myTable_info,#myTable_paginate').addClass('well');

    });

</script>

</body>
</html>