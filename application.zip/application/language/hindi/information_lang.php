<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$lang['welcome_message'] = 'आपका स्वागत है!';
$lang['date'] = 'दिनांक:';

// top nav

$lang['todays_due_vaccine_list'] = 'आज की टीकाकरण सूची!';
$lang['todays_done_vaccine_list'] = 'आज की टीकाकरण सूची (पूर्ण)';
$lang['new_entry_mother_or_child'] = 'माँ / बच्चे की नई इंट्री करें';
$lang['asha_anm_location'] = 'एएनएम आशा (Link)';
$lang['logout'] = 'लोग आउट';

// listing
$lang['mother_name'] = 'मां का नाम';
$lang['child_name'] = 'बच्चे का नाम';
$lang['mobile_number'] = 'मोबाइल नंबर';
$lang['child_dob'] = 'बच्चे की जन्म तिथि';
$lang['anm_mobile_number'] = 'अनम का फोन नंबर';
$lang['anm_name'] = 'एएनएम का नाम';
$lang['asha_name'] = 'आशा का नाम';
$lang['asha_contact_number'] = 'आशा का फोन नंबर';
$lang['location_name'] = 'स्थान का नाम';
$lang['list_vaccines'] = 'टीकों की सूची';

$lang['vaccine_done_date'] = 'वैक्सीन की तारीख (अगर आज की जाए तो खाली छोड़ दें)';

$lang['vaccine'] = 'टीका';
$lang['action_title'] = 'एक्शन';
$lang['action_text'] = 'एक्शन';

$lang['todays_due_list'] = 'आज के कारण टीका';

$lang['search_mother_or_child_by_mobile'] = 'मोबाइल का उपयोग करके माँ या बच्चे को खोजें';
$lang['search_using_mobile'] = 'मोबाइल का उपयोग करके खोजें';
$lang['dashboard'] = 'डैशबोर्ड';
$lang['details_of_mother'] = 'माँ की जानकारी';
$lang['vaccines_already_given'] = 'जो टीके दिए गए हैं';
$lang['vaccines_given_today'] = 'टीकाकरण जो किया गया है';
$lang['todays_vaccine_list'] = 'आज के टीके';
$lang['future_vaccine_list'] = 'भविष्य की वैक्सीन सूची';




// buttons
$lang['update_button_text'] = 'अपडेट करें';
$lang['entry_button_text'] = 'इंट्री करें';


// alert / confirm messages...
$lang['update_conform_msg'] = 'क्या आप वाकई अपडेट करना चाहते हैं?';