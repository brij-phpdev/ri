<?php

#session_start(); //we need to start session in order to access it through CI

Class Anm extends CI_Controller {

    public function __construct() {

        parent::__construct();

        // Load form helper library
        $this->load->helper('form', 'url');

        // Load form validation library
        $this->load->library('form_validation');

        // Load session library
        $this->load->library('session');
        
        $this->lang->load('information','hindi');

    }

    // Show dashboard page
    public function main() {

        $token = $this->input->get('token');
        $user_id = $this->input->get('user_id');

        $this->session->set_userdata('token', $token);
        $this->session->set_userdata('user_id', $user_id);
        $this->session->set_userdata('logged_in', TRUE);
        redirect('anm/index');
    }

    // Show dashboard page
    public function index() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            // mothers due list data..
            
//            print_r($data);
            $data['js_to_load']=array("common-functions.js","search-mother.js");
//            print_r($data);die;
            
            $this->load->view('partials/_header', $data);
            $this->load->view('partials/_sidebar', $data);
            $this->load->view('anm/dashboard', $data);
            $this->load->view('partials/_footer',$data);
        } else {
            redirect('/');
        }
    }

    // profile page
    public function profile() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            //  $data['username'] = $session_data['username'];
            $data = ($session_data);

            $this->load->view('partials/_header');
            $this->load->view('partials/_sidebar', $data);
            $this->load->view('anm/profile', $data);
            $this->load->view('partials/_footer');
        } else {
            redirect('/');
        }
    }

    public function upcoming_ri_due_list() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            //  $data['username'] = $session_data['username'];
            $data = ($session_data);
            
            $this->load->view('partials/_header');
            $this->load->view('partials/_sidebar', $data);
            $this->load->view('anm/dashboard', $data);
            $this->load->view('partials/_footer');
        } else {
            redirect('/');
        }
    }

    public function done_list() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            //  $data['username'] = $session_data['username'];
            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];
            
            $data['js_to_load']=array("common-functions.js","today-done.js");
            $this->load->view('partials/_header');
            $this->load->view('partials/_sidebar', $data);
            $this->load->view('anm/done', $data);
            $this->load->view('partials/_footer',$data);
        } else {
            redirect('/');
        }
    }

    public function add_new_mother() {

        
        
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            
            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];
//            $data['query'] = $this->mother_model->sample_query();
            $data['mobile'] = !empty($this->input->get('mobile')) ? $this->input->get('mobile') : null;
            
            // loading js
            $data['js_to_load']=array("common-functions.js","add-mother.js");
            $this->load->view('partials/_header');
            $this->load->view('partials/_sidebar', $data);
            $this->load->view('anm/add_new_mother', $data);
            $this->load->view('partials/_footer',$data);
        } else {
            redirect('/');
        }
    }

    public function add_mother() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            //  $data['username'] = $session_data['username'];

            $data = ($session_data);
            $data['mobile'] = !empty($this->input->post('mobile')) ? $this->input->post('mobile') : null;
            $data['mother_name'] = !empty($this->input->post('mother_name')) ? $this->input->post('mother_name') : null;
            $data['child_name'] = !empty($this->input->post('child_name')) ? $this->input->post('child_name') : null;
            $data['child_dob'] = !empty($this->input->post('child_dob')) ? $this->input->post('child_dob') : null;
            $data['asha_name'] = !empty($this->input->post('asha_name')) ? $this->input->post('asha_name') : null;
            $data['area_name'] = !empty($this->input->post('area_name')) ? $this->input->post('area_name') : null;
            $data['vaccinations'] = !empty($this->input->post('vaccinations')) ? $this->input->post('vaccinations') : null;

            // future variable ..
            $data['anm_name'] = $session_data['first_name'];
            $data['anm_contact'] = isset($session_data['anm_contact']) ? $session_data['anm_contact'] : null;
            $data['mother_age'] = !empty($this->input->post('mother_age')) ? $this->input->post('mother_age') : null;
            $data['asha_contact'] = !empty($this->input->post('asha_contact')) ? $this->input->post('asha_contact') : null;



            if ($data['mobile'] == null) {
                $data['error_msg'] = 'mobile cannot be blank';
                $this->load->view('partials/_header');
                $this->load->view('partials/_sidebar', $data);
                $this->load->view('anm/add_new_number', $data);
                $this->load->view('partials/_footer');
            }

            $res = $this->mother_model->add_mother_details($data);

            redirect('anm/index');
//            $this->load->view('partials/_header');
//                $this->load->view('partials/_sidebar', $data);
//                $this->load->view('/index', $data);
//                $this->load->view('partials/_footer');
        } else {
            redirect('/');
        }
    }

    public function update_vaccination() {

        if ($this->session->userdata('logged_in')) {


            $data['vaccination_name'] = $this->input->post('vaccination_name');
            $data['child_id'] = $this->input->post('id');
            $data['select'] = $this->input->post('select');

            return $this->mother_model->update_vaccination($data);
        } else {
            return false;
        }
    }

    public function get_child_details() {

        if ($this->session->userdata('logged_in')) {


            $data['mother_id'] = $this->input->post('mother_id');
            $data['mobile'] = $this->input->post('mobile');

            $response = $this->mother_model->get_child_details($data['mobile']);
            json_output(200, $response);
        } else {
            return false;
        }
    }

    public function get_child_for_vaccination() {

        if ($this->session->userdata('logged_in')) {


            $data['child_ids'] = !empty($this->input->post('child_ids')) ? $this->input->post('child_ids') : null;

            $response = $this->mother_model->get_child_for_vaccination($data['child_ids']);
            json_output(200, $response);
        } else {
            return false;
        }
    }

}

