<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Api_model extends CI_Model {

    var $client_service = "frontend-client";
    var $auth_key = "authkey";
    // table variables..
    var $mother_details_table = "mothers_details";
    var $children_details_table = "children_details";
    var $anm_table = "anms";
    var $anm_asha_relation_table = "anm_asha_relation";
    var $asha_table = "asha";
    var $territory_table = "territory";
    var $vaccination_arr = array(
        //bucket one
        'BCG','Hep_B',
        // buket two..
        'OPV_O', 
        // bucket three..
         'RVV1','IPV1','OPV1', 'DPT1','PENTA1',
        
        // bucket four
        'RVV2','OPV2', 'DPT2','PENTA2',
        // bucket five
         'RVV3',  'IPV2',   'OPV3', 'DPT3',  'PENTA3',
        
        // bucket six
        'JE1', 'VIT_A_1','MMR',
        
        // bucket seven..
          'DPT_1_BOOSTER','MMR2',  'OPV_BOOSTER', 'JE2',
        // bucket eight
        'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9',
        
        // DPT bucket..
        'DPT_2_BOOSTER');
    
    var $vaccination_daydiff_arr = array(
        'BCG' => array('_date' => '', '_last_date' => '1 year'),
        'OPV_O' => array('_date' => '', '_last_date' => '15 days'),
        'Hep_B' => array('_date' => '', '_last_date' => '1 day'),
        
        'OPV1' => array('_date' => '42 days', '_last_date' => '1825 days'),
        'OPV2' => array('_date' => '70 days', '_last_date' => '1825 days'),
        'DPT1' => array('_date' => '42 days', '_last_date' => '730 days'),
        'DPT2' => array('_date' => '70 days', '_last_date' => '730 days'),
        // missing...
        'DPT3' => array('_date' => '98 days', '_last_date' => '730 days'),
        'HepB1' => array('_date' => '', '_last_date' => '1 day'),
        'HepB2' => array('_date' => '', '_last_date' => '1 day'),
        'HepB3' => array('_date' => '', '_last_date' => '730 days'),
        'RVV1' => array('_date' => '42 days', '_last_date' => '365 days'),
        // missing ends...
        'RVV2' => array('_date' => '70 days', '_last_date' => '365 days'),
        'RVV3' => array('_date' => '98 days', '_last_date' => '365 days'),
        // missing...
        'IPV' => array('_date' => '42 days', '_last_date' => '365 days'),
        // missing... end
        'IPV1' => array('_date' => '42 days', '_last_date' => '365 days'),
        // missing...
        'IPV2' => array('_date' => '98 days', '_last_date' => '365 days'),
        // missing...end
        'PENTA1' => array('_date' => '42 days', '_last_date' => '365 days'),
        'PENTA2' => array('_date' => '70 days', '_last_date' => '365 days'),
        // missing...
        'OPV3' => array('_date' => '98 days', '_last_date' => '1825 days'),
        'PENTA3' => array('_date' => '98 days', '_last_date' => '365 days'),
        'IPV' => array('_date' => '42 days', '_last_date' => '365 days'),
        'MMR' => array('_date' => '270 days', '_last_date' => '1825 days'),
        'MMR2' => array('_date' => '480 days', '_last_date' => '1825 days'),
        'JE1' => array('_date' => '270 days', '_last_date' => '5475 days'),
        'VIT_A_1' => array('_date' => '270 days', '_last_date' => '1825 days'),
        'OPV_BOOSTER' => array('_date' => '480 days', '_last_date' => '1825 days'),
        'DPT_1_BOOSTER' => array('_date' => '480 days', '_last_date' => '2555 days'),
        'JE2' => array('_date' => '480 days', '_last_date' => '5475 days'),
        'VIT_A_2' => array('_date' => '540 days', '_last_date' => '1825 days'),
        'VIT_A_3' => array('_date' => '720 days', '_last_date' => '1825 days'),
        'VIT_A_4' => array('_date' => '900 days', '_last_date' => '1825 days'),
        'VIT_A_5' => array('_date' => '1080 days', '_last_date' => '1825 days'),
        'VIT_A_6' => array('_date' => '1260 days', '_last_date' => '1825 days'),
        'VIT_A_7' => array('_date' => '1440 days', '_last_date' => '1825 days'),
        'VIT_A_8' => array('_date' => '1620 days', '_last_date' => '1825 days'),
        'VIT_A_9' => array('_date' => '1800 days', '_last_date' => '1825 days'),
        'DPT_2_BOOSTER' => array('_date' => '1825 days', '_last_date' => '2190 days'));
    var $vaccine_buckets = array(
        '3' => array('RVV1', 'IPV1', 'OPV1', 'DPT1', 'PENTA1'),
        '4' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2')
    );
    var $vaccination_date_change_case = array(
        // bucket 1
        'Hep_B' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('BCG'), 'next_bucket' => array('OPV_O', 'IPV1', 'RVV1', 'DPT1', 'PENTA1', 'RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'BCG' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('Hep_B'), 'next_bucket' => array('OPV_O', 'IPV1', 'RVV1', 'DPT1', 'PENTA1', 'RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // bucket 2
        'OPV_O' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('OPV_O'), 'next_bucket' => array('IPV1', 'RVV1', 'DPT1', 'PENTA1', 'RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // bucket 3
        'RVV1' => array('update_vaccine' => 'RVV2', 'days' => '28 DAY', 'check_for' => array('IPV1', 'OPV1', 'DPT1', 'PENTA1'), 'next_bucket' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'OPV1' => array('update_vaccine' => 'OPV2', 'days' => '28 DAY', 'check_for' => array('IPV1', 'RVV1', 'DPT1', 'PENTA1'), 'next_bucket' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'DPT1' => array('update_vaccine' => 'DPT2', 'days' => '28 DAY', 'check_for' => array('IPV1', 'OPV1', 'RVV1', 'PENTA1'), 'next_bucket' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'IPV1' => array('update_vaccine' => 'IPV2', 'days' => '28 DAY', 'check_for' => array('RVV1', 'OPV1', 'DPT1', 'PENTA1'), 'next_bucket' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'PENTA1' => array('update_vaccine' => 'PENTA2', 'days' => '28 DAY', 'check_for' => array('IPV1', 'OPV1', 'DPT1', 'RVV1'), 'next_bucket' => array('RVV2', 'OPV2', 'DPT2', 'PENTA2', 'RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9'), 'given_later' => 'DPT3'),
        // bucket 4
        'DPT2' => array('update_vaccine' => 'DPT3', 'days' => '28 DAY', 'check_for' => array('PENTA2', 'RVV2', 'OPV2'), 'next_bucket' => array('RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9'), 'given_later' => 'PENTA2', 'set_na' => 'PENTA1'),
//        'PENTA2' => array('given_later'=>'PENTA1','update_vaccine'=> 'DPT1','days'=>'28 days'),
        'PENTA2' => array('update_vaccine' => 'PENTA3', 'days' => '28 DAY', 'check_for' => array('DPT2', 'RVV2', 'OPV2'), 'next_bucket' => array('RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9'), 'given_later' => 'PENTA2'),
        'RVV2' => array('update_vaccine' => 'RVV3', 'days' => '28 DAY', 'check_for' => array('DPT2', 'PENTA2', 'OPV2'), 'next_bucket' => array('RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'OPV2' => array('update_vaccine' => 'OPV3', 'days' => '28 DAY', 'check_for' => array('DPT2', 'RVV2', 'PENTA2'), 'next_bucket' => array('RVV3', 'IPV2', 'OPV3', 'DPT3', 'PENTA3', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // bucket 5...
        'RVV3' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT3', 'IPV2', 'PENTA3', 'OPV3'), 'next_bucket' => array('MMR1', 'JE1', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'DPT3' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('RVV3', 'IPV2', 'PENTA3', 'OPV3'), 'next_bucket' => array('MMR1', 'JE1', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'IPV2' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT3', 'RVV3', 'PENTA3', 'OPV3'), 'next_bucket' => array('MMR1', 'JE1', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'PENTA3' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT3', 'IPV2', 'RVV3', 'OPV3'), 'next_bucket' => array('MMR1', 'JE1', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'OPV3' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT3', 'IPV2', 'RVV3', 'PENTA3'), 'next_bucket' => array('MMR1', 'JE1', 'DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // bucket 6
        'JE1' => array('update_vaccine' => 'JE2', 'days' => '28 days', 'check_for' => array('MMR1', 'VIT_A_1'), 'next_bucket' => array('DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'MMR1' => array('update_vaccine' => 'MMR2', 'days' => '28 DAY', 'check_for' => array('JE1', 'VIT_A_1'), 'next_bucket' => array('DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_1', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'VIT_A_1' => array('update_vaccine' => 'VIT_A_3', 'days' => '28 DAY', 'check_for' => array('MMR1', 'JE1'), 'next_bucket' => array('DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER', 'JE2', 'OPV1', 'IPV', 'MMR1', 'JE1', 'DPT_2_BOOSTER', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // bucket 7
        'DPT_1_BOOSTER' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('MMR2', 'OPV_BOOSTER', 'JE2'), 'next_bucket' => array('VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'MMR2' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT_1_BOOSTER', 'OPV_BOOSTER', 'JE2'), 'next_bucket' => array('VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'OPV_BOOSTER' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT_1_BOOSTER', 'MMR2', 'JE2'), 'next_bucket' => array('VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        'JE2' => array('update_vaccine' => null, 'days' => '28 DAY', 'check_for' => array('DPT_1_BOOSTER', 'MMR2', 'OPV_BOOSTER'), 'next_bucket' => array('VIT_A_3', 'VIT_A_4', 'VIT_A_5', 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9')),
        // vitamin bucket
        'VIT_A_2' => array('update_vaccine' => 'VIT_A_3', 'days' => '180 DAY'),
        'VIT_A_3' => array('update_vaccine' => 'VIT_A_4', 'days' => '180 DAY'),
        'VIT_A_4' => array('update_vaccine' => 'VIT_A_5', 'days' => '180 DAY'),
        'VIT_A_5' => array('update_vaccine' => 'VIT_A_6', 'days' => '180 DAY'),
        'VIT_A_6' => array('update_vaccine' => 'VIT_A_7', 'days' => '180 DAY'),
        'VIT_A_7' => array('update_vaccine' => 'VIT_A_8', 'days' => '180 DAY'),
        'VIT_A_8' => array('update_vaccine' => 'VIT_A_9', 'days' => '180 DAY'));
    var $date_arr = array('_date', '_last_date', '_done_date');

    public function check_auth_client() {

        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array('status' => 401, 'message' => 'अनधिकृत।'));
        }
    }

    public function login($mobile, $login_code) {

        $q = $this->db->select('id,mobile,login_code')->from('users')->where('mobile', $mobile)->get()->row();

        if ($q == "") {
            return array('status' => 204, 'message' => 'इस मोबाइल नंबर के लिए रिकॉर्ड नहीं मिला.');
        } else {
            /** uncomment following in case password is hashed */
            $user_login_code = $q->login_code;

            $id = $q->id;
            if (hash_equals($user_login_code, md5($login_code))) {

                $last_login = date('Y-m-d H:i:s');
//               $token = crypt(substr( md5(uniqid(rand())), 0, 7));
                $token = substr(password_hash(substr(md5(rand()), 0, 7), PASSWORD_DEFAULT), 0, 38);
                $expired_at = date("Y-m-d H:i:s", strtotime('+12 hours'));
                $this->db->trans_start();
                $this->db->where('id', $id)->update('users', array('last_login' => $last_login));
                $this->db->insert('users_authentication', array('users_id' => $id, 'token' => $token, 'expired_at' => $expired_at));
                if ($this->db->trans_status() === FALSE) {
                    $this->db->trans_rollback();
                    return array('status' => 500, 'message' => 'Internal server error.');
                } else {
                    $this->db->trans_commit();
                    return array('status' => 200, 'message' => 'सफलतापूर्वक लॉगिन करें', 'id' => $id, 'token' => $token);
                }
            } else {
                return array('status' => 204, 'message' => 'गलत पास कोड');
            }
        }
    }

    public function logout() {
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token = $this->input->get_request_header('Authorization', TRUE);
        $this->db->where('users_id', $users_id)->where('token', $token)->delete('users_authentication');
        return array('status' => 200, 'message' => 'सफलतापूर्वक लॉगआउट');
    }

    public function auth() {
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token = $this->input->get_request_header('Authorization', TRUE);
        $q = $this->db->select('expired_at')->from('users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array('status' => 401, 'message' => 'अनधिकृत।'));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array('status' => 401, 'message' => 'आपका सत्र समाप्त हो चुका है'));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = date("Y-m-d H:i:s", strtotime('+12 hours'));
                $this->db->where('users_id', $users_id)->where('token', $token)->update('users_authentication', array('expired_at' => $expired_at, 'updated_at' => $updated_at));
                return array('status' => 200, 'message' => 'अधिकार दिया गया।');
            }
        }
    }

    public function children_all_data() {
        $all_children_data = $this->db->select('*')->from($this->children_details_table)->order_by('child_id', 'desc')->get()->result();
        return array('status' => 200, 'data' => $all_children_data);
    }

    public function child_data_by_id($child_id) {
        $all_children_data = $this->db->select('*')->from($this->children_details_table)->order_by('child_id', 'desc')->where('child_id', $child_id)->get()->result();
        return $all_children_data[0];
    }

    public function get_vaccination_list() {
        return array('status' => 200, 'data' => $this->vaccination_arr);
    }

    public function update_vaccination($data) {
        if (!empty($data)) {
//            print_r($data);
            // Update vaccination data

            $get_previous_data = $this->Api_model->child_data_by_id($data['child_id']);
//            print_r($get_previous_data);

            $comma = ", ";
            $query = "UPDATE `" . $this->children_details_table . "` SET ";

            $next_vaccine_update_qry = '';
            $vaccine_date_qry = '';
            $today = date('Y-m-d');
            foreach ($data['vaccination_name'] as $v => $vaccine):

                $vaccine_date_qry .= " `" . $vaccine . "` = '" . $data['select'] . "' ";
                // now check if false .. then remove date
                if ($data['select'] == 'true') {
                    $vaccination_date = date('d/m/Y');
                }
                if ($data['select'] == 'false') {
                    $vaccination_date = '';
                }

                $vaccine_date_qry .= ", `" . $vaccine . '_done_date' . "` = '$vaccination_date',";

                /// now check if current vaccine is in dependent vaccine in order to update its future vaccine date & last date of coming vaccines...
                if (array_key_exists($vaccine, $this->vaccination_date_change_case)) {
//                            if($this->findKey($this->vaccination_date_change_case,$vaccination)){
//                    echo 'yes it is in bucket of updating dependant_vaccine'."\r\n";
                    $vaccine_to_be_updated = $this->vaccination_date_change_case[$vaccine];
//                    print_r($vaccine_to_be_updated['update_vaccine']);
                    if (isset($vaccine_to_be_updated['update_vaccine'])) {
//                        echo 'yes this vaccine is present'."\r\n";
                        $new_vaccine_name = $vaccine_to_be_updated['update_vaccine'];
                        $same_bucket_vaccines = $vaccine_to_be_updated['check_for'];
                        $next_bucket_vaccines = $vaccine_to_be_updated['next_bucket'];
//                        print_r($same_bucket_vaccines);
//                        print_r($next_bucket_vaccines);
                        // before updating let us compare if which date is bigger...

                        $prev_vaccine_date_column_nm = $new_vaccine_name . $this->date_arr[0];
                        $previous_vaccine_date = $get_previous_data->$prev_vaccine_date_column_nm;


                        $new_vaccine_date = date('Y-m-d', strtotime($today . ' + ' . str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days'));

                        $date1 = date_create($new_vaccine_date);
                        $date2 = date_create($previous_vaccine_date);
                        $diff = date_diff($date1, $date2);
//                            echo $diff->format("%R%a");
                        $next_vaccine_update_qry .= " , `" . $new_vaccine_name . "` = 'false', ";
                        if ($diff->format("%R%a") > 0) {
                            // previous date only..
                            $next_vaccine_update_qry .= " `" . $new_vaccine_name . $this->date_arr[0] . "` = '" . $previous_vaccine_date . "' ";
                        } else {
                            // we are updating new vaccine date..
                            $next_vaccine_update_qry .= " `" . $new_vaccine_name . $this->date_arr[0] . "` = '" . $new_vaccine_date . "' ";

                            // now let us update its next bucket... & let us check which bucket it is in
                            // now check if all same bucket vaccines are done...
                            $false_count = 0;
                            foreach ($same_bucket_vaccines as $same_bucket_vaccine):
//                            echo $get_previous_data->$same_bucket_vaccine;
                                if ($get_previous_data->$same_bucket_vaccine == 'false') {
                                    $false_count++;
                                }
//                            echo  "\r\nvaccine: $same_bucket_vaccine => ",$get_previous_data->$same_bucket_vaccine;
                            endforeach;
//                        echo $false_count;
                            // if false count is only one than is the case we will update next bucket vaccines
                            if ($false_count == 0) {
//                            echo 'ye condition matched this is last vaccine of this bucket';

                                foreach ($next_bucket_vaccines as $next_bucket_vaccine):
                                    // get previous date which is 70  days for bucket 4 & 98 days for bucket 5 & check if it is less than today..
                                    $next_bucket_vaccine_date_column_name = $next_bucket_vaccine . $this->date_arr[0];
//                                echo "\r\n $next_bucket_vaccine db date: ",$get_previous_data->$next_bucket_vaccine_date_column_name;
                                    if (array_key_exists($next_bucket_vaccine, $this->vaccination_date_change_case)) {
                                        $vaccine_data_matched = $this->vaccination_date_change_case[$next_bucket_vaccine];
                                        $next_bucket_days_to_increase = $vaccine_data_matched['days'];

                                        $next_bucket_vaccine_date = date('Y-m-d', strtotime($today . ' + ' . str_replace(' DAY', '', $next_bucket_days_to_increase) . ' days'));
                                        $next_date_by_increasing_days = date_create($next_bucket_vaccine_date);
                                        $db_date = date_create($get_previous_data->$next_bucket_vaccine_date_column_name);
                                        $date_diff = date_diff($next_date_by_increasing_days, $db_date);
                                        //                                        echo $date_diff->format("%R%a");

                                        if ($date_diff->format("%R%a") > 0) {
                                            // previous date only..
                                            $next_vaccine_update_qry .= ", `" . $next_bucket_vaccine . $this->date_arr[0] . "` = '" . $get_previous_data->$next_bucket_vaccine_date_column_name . "' ";
                                        } else {
                                            $next_vaccine_update_qry .= ", `" . $next_bucket_vaccine . $this->date_arr[0] . "` = '" . $next_bucket_vaccine_date . "' ";
                                        }
                                    }
                                endforeach;
                            } else {
//                            echo 'we still have vaccines left in this bucket';
                            }
                        }
                    }
                }


            endforeach;

            $query .= substr($vaccine_date_qry, 0, -1) . $next_vaccine_update_qry . " WHERE `child_id` = " . $data['child_id'];

//            echo $query;die;

            $res = $this->db->query($query);
//            print_r($res);die;
            $msg = ($res) ? "वैक्सीन सफलतापूर्वक अपडेट की गई!" : "कुछ त्रुटि हुई!";
            return array('status' => 200, 'message' => $msg);
        }
        return array('status' => 204, 'message' => 'कृपया एक इनपुट प्रदान करें');
    }

    public function upcoming_ri_due_list($data) {

        $new_array = array();
        $login_user_id = $this->input->get_request_header('User-ID', TRUE);

        $anm_data_arr = $this->Api_model->getANMDetailsByID(array('user_id' => $login_user_id));
        $anm_data = $anm_data_arr['data']['anm_data'];
        $anm_contact = $anm_data['mobile'];

        $date_range = isset($data['date_range']) ? ($data['date_range']) : 0;
//        $anm_contact = $anm_data;
        $child_ids = isset($data['child_ids']) ? ($data['child_ids']) : null;
        $limit = isset($data['limit']) ? ($data['limit']) : false;

        $today = date('Y-m-d');

        // first of all collect column names that meet the requirement

        $query = "SELECT c.*, m.*  FROM " . $this->children_details_table . " c RIGHT JOIN " . $this->mother_details_table . " m ON "
                . " (m.mthrs_mbl_no = c.child_contact) AND ( m.anm_contact='$anm_contact' ) WHERE ";



        $exist_qry = "";
//        $exist_qry = " EXISTS( SELECT c.* FROM " . $this->children_details_table . " c WHERE ";

        foreach ($this->vaccination_arr as $v => $vaccination):
// NOW() >= BCG_date AND NOW() <= BCG_last_date
            $exist_qry .= ($v != 0) ? " OR " : '';
            $exist_qry .= " (  NOW() >= c." . $vaccination . $this->date_arr[0] . " AND NOW() <= c." . $vaccination . $this->date_arr[1] . " AND c.$vaccination = 'false' ) ";

        endforeach;

        $exist_qry .= ($child_ids != null) ? " OR c.child_id IN ('$child_ids')" : '';

//        $exist_qry .= " ) ";
        // appending limit
//        $query .= ($limit != false) ? " LIMIT $limit" : '';
        $query .= $exist_qry . " ORDER BY c.child_id DESC";

//        echo $query;die;

        $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        // now perform operation to get list of today's due vaccination only...
        if ($res->num_rows() > 0) {
            $results = $res->result_array();
//            print_r($results);die;
            $return_array = array();
            foreach ($results as $r => $result) {
//                print_r($result);

                foreach ($this->vaccination_arr as $v => $vaccination):
                    $vaccine_name = $result[$vaccination];
                    $date_var = $vaccination . $this->date_arr[0];
                    $last_date_var = $vaccination . $this->date_arr[1];

                    if (($vaccine_name == 'false') &&
                            ($today >= $result[$date_var] && $today <= $result[$last_date_var])) {
//                            echo "<br/> $vaccination yes here for ".$result['child_id'];                            
                        $return_array[$r][] = $vaccination; // $r used for each row.. like child one & child row second
                    }
                endforeach;
            }

//
//        print_r($return_array);die;

            $exclude_array = array('mthrs_name', 'child_id', 'mthr_id', 'mother_name', 'mthrs_mbl_no', 'child_contact', 'child_name', 'child_dob', 'child_status', 'is_vacinated_before', 'added_time', 'last_updation_time');
            // now exclude other vaccinations from the list..
            foreach ($results as $r => $result) {


                foreach ($result as $u => $upcoming_ri_due) {
                    if (isset($return_array[$r])) {
                        // exclude ...for other useful details..
                        if (in_array($u, $exclude_array)) {
                            $new_array[$r][$u] = $upcoming_ri_due;
                        } else {


                            if (in_array($u, $return_array[$r])) {
                                $new_array[$r]['due_vaccinations'][] = $u;
                                //                                $new_array[$r][] =  $vaccination;
                            }
                        }
                    } else {
                        if (in_array($u, $exclude_array)) {
                            $new_array[$r][$u] = $upcoming_ri_due;
                        }
                        $new_array[$r]['due_vaccinations'] = $this->vaccination_arr;
                    }
                }
            }
        }

//        return array('status' => 200, 'data' => $new_array);
        return array('status' => 200, 'data' => $new_array,);
    }

    /**
     * 
     * @param type $child_ids
     * @return array
     */
    public function get_child_for_vaccination($data) {

        if (isset($data['child_ids'])) {
            $child_ids = $data['child_ids'];
            $condition = "child_id = " . "'" . $child_ids . "'";
            $this->db->select('*');
            $this->db->from($this->children_details_table);
            $this->db->where($condition);
            $query = $this->db->get();
            $str = $this->db->last_query();
            //    echo "<pre>";print_r($str);exit;
            $result = ($query->num_rows() > 0) ? $query->result_array() : false;
            return array('status' => 200, 'data' => $result);
        }
        return array('status' => 204, 'message' => 'कृपया एक इनपुट प्रदान करें');
    }

    // Function for finding first and last 
    // occurrence of an elements 
    public function findFirstOccurance($arr, $x) {
        $first = -1;
        for ($i = 0; $i < count($arr); $i++) {
            if ($x != $arr[$i])
                continue;
            if ($first == -1)
                $first = $i;
        }
        if ($first != -1)
            echo "First Occurrence = ", $first;
        else
            echo "Not Found";
    }

    // Read data from database to show data in admin page
    public function check_mother_detials($data) {

        if (isset($data['mobile'])) {
            $mobile_number = $data['mobile'];
            $condition = "mthrs_mbl_no LIKE " . "'" . $mobile_number . "%'";
            $this->db->select('*');
            $this->db->from($this->mother_details_table);
            $this->db->where($condition);
            $this->db->limit(1);
            $query = $this->db->get();

            $result = ($query->num_rows() > 0) ? $query->result_array()[0]['mthrs_db_id'] : false;

//            echo $query->num_rows();
//                    print_r($query);
//                    $res = $this->db->query($query);

            return $result;
        }
//        return array('status' => 204, 'msg' => 'कृपया एक इनपुट प्रदान करें');
    }

    // Read data from database to show data in admin page
    public function get_mother_detials($data) {

        if (isset($data['mobile'])) {
            $mobile_number = $data['mobile'];
            $condition = "mthrs_mbl_no LIKE " . "'" . $mobile_number . "%' "
                    . " OR mthrs_name LIKE " . "'" . $mobile_number . "%'  ";
            $this->db->select('*');
            $this->db->from($this->mother_details_table);
            $this->db->where($condition);
            $this->db->limit(1);
            $query = $this->db->get();

//                    return $query->result();
//                    $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
            $result = ($query->num_rows() > 0) ? $query->result_array() : false;
            return array('status' => 200, 'data' => $result);
        }
        return array('status' => 204, 'msg' => 'कृपया एक इनपुट प्रदान करें');
    }

    // Read data from database to show data in admin page
    public function search_mother_detials($data) {

        if (isset($data['mobile'])) {
            $mobile_number = $data['mobile'];
            $condition = " ( m.mthrs_mbl_no LIKE " . "'" . $mobile_number . "%' "
                    . " OR m.mthrs_name LIKE " . "'" . $mobile_number . "%'  "
                    . " OR c.child_contact LIKE " . "'" . $mobile_number . "%'  "
                    . " OR c.child_name LIKE " . "'" . $mobile_number . "%' ) ";

            $login_user_id = $this->input->get_request_header('User-ID', TRUE);
            $anm_data_arr = $this->Api_model->getANMDetailsByID(array('user_id' => $login_user_id));
            $anm_data = $anm_data_arr['data']['anm_data'];
            $anm_contact = $anm_data['mobile'];



            $query = "SELECT c.*, m.* FROM " . $this->children_details_table . " c LEFT JOIN " . $this->mother_details_table . " m ON "
                    . "m.mthrs_mbl_no = c.child_contact WHERE m.anm_contact='$anm_contact' AND $condition";


//            $exist_qry = " EXISTS( SELECT c.* FROM " . $this->children_details_table . " c WHERE ";
//        $query .= " m.anm_contact='$anm_contact' AND ";
//
//        foreach ($this->vaccination_arr as $v => $vaccination):
//            $exist_qry .= ($v != 0) ? " OR " : '';
//            $exist_qry .= " (c." . $vaccination . $this->date_arr[2] . " = '$today' ) ";
//        endforeach;
//
//        // appending limit
//        $exist_qry .= " ) ";
//        $query .= $exist_qry . " ORDER BY c.child_id ";

            $res = $this->db->query($query);
//            print_r($query);
//            $str = $this->db->last_query();
//    echo "<pre>";print_r($str);exit;
            $result = ($res->num_rows() > 0) ? $res->result_array() : false;
            return array('status' => 200, 'data' => $result, 'query' => $query);

//                    return $query->result();
//                    $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        }
        return array('status' => 204, 'message' => 'कृपया एक इनपुट प्रदान करें');
    }

    // Read data from database to show data in admin page
    public function get_child_details($data) {

        if (isset($data['mobile'])) {
            $mobile_number = $data['mobile'];
            $condition = " c.child_contact = " . "'" . $mobile_number . "'";
            $query = "SELECT c.*, m.* FROM " . $this->children_details_table . " c LEFT JOIN " . $this->mother_details_table . " m ON "
                    . "m.mthrs_mbl_no = c.child_contact WHERE $condition";
            $res = $this->db->query($query);
//            print_r($query);
//            $str = $this->db->last_query();
//    echo "<pre>";print_r($str);exit;
            $result = ($res->num_rows() > 0) ? $res->result_array() : false;
            return array('status' => 200, 'data' => $result);
        }
        return array('status' => 204, 'message' => 'कृपया एक मोबाइल नंबर प्रदान करें');
    }

    public function get_vaccinations_done_today() {

        $login_user_id = $this->input->get_request_header('User-ID', TRUE);
        $anm_data_arr = $this->Api_model->getANMDetailsByID(array('user_id' => $login_user_id));
        $anm_data = $anm_data_arr['data']['anm_data'];
        $anm_contact = $anm_data['mobile'];

        $today = date('d/m/Y');
        $new_array = array();

        $query = "SELECT c.*, m.*  FROM " . $this->children_details_table . " c RIGHT JOIN " . $this->mother_details_table . " m ON "
                . " (m.mthrs_mbl_no = c.child_contact) AND ( m.anm_contact='$anm_contact' ) WHERE ";

//        $query = "SELECT c.*, m.* FROM " . $this->children_details_table . " c LEFT JOIN " . $this->mother_details_table . " m ON "
//                . " (m.mthrs_mbl_no = c.child_contact ) AND (m.anm_contact='$anm_contact') WHERE ";
        $exist_qry = "";
//        $exist_qry = " EXISTS( SELECT c.* FROM " . $this->children_details_table . " c WHERE (";


        foreach ($this->vaccination_arr as $v => $vaccination):
            $exist_qry .= ($v != 0) ? " OR " : '';
            $exist_qry .= " (c." . $vaccination . $this->date_arr[2] . " = '$today' AND c." . $vaccination . "='true' ) "; // AND c." . $vaccination . $this->date_arr[2] . " IS NOT NULL
        endforeach;

        // appending limit
//        $exist_qry .= " ) ) ";
        $query .= $exist_qry . " ORDER BY c.child_id ";


//        echo '<pre>';echo $query;die;

        $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        // now perform operation to get list of today's due vaccination only...
        if ($res->num_rows() > 0) {
            $results = $res->result_array();
            $return_array = array();
            foreach ($results as $r => $result) {

                foreach ($result as $u => $upcoming_ri_due) {
                    // get list of vaccinations...
                    if (in_array($u, $this->vaccination_arr)) {


//                        echo "  $u => $upcoming_ri_due ";

                        if ($upcoming_ri_due == 'true') {
                            $return_array[$r][] = $u;
                        }
                    }
                }
            }


//        print_r($return_array);


            $exclude_array = array('mthrs_name', 'child_id', 'mthr_id', 'mother_name', 'mthrs_mbl_no', 'child_contact', 'child_name', 'child_dob', 'child_status', 'is_vacinated_before', 'added_time', 'last_updation_time');
            // now exclude other vaccinations from the list..
            foreach ($results as $r => $result) {

                foreach ($result as $u => $upcoming_ri_due) {
                    // exclude ...for other useful details..
                    if (isset($return_array[$r])) {
                        if (in_array($u, $exclude_array)) {
                            $new_array[$r][$u] = $upcoming_ri_due;
                        } else {
                            if (in_array($u, $return_array[$r])) {
//                        echo 'ye I m here for '.$u;
                                $new_array[$r]['done_vaccinations'][] = $u;
//                            $new_array[$r][] =  $vaccination;
                            }
                        }
                    }
//                    endforeach;
                }
            }
        }

        return array('status' => 200, 'data' => $new_array);
    }

    public function add_mother_details($data) {

        if (!empty($data['mobile'])) {

            // getting vaccinations..
            // now before adding mother let us check if mother already exist or not..
            $check_array['mobile'] = $data['mobile']; //setting mobile number only 
            $check_mother_if_exist = $this->check_mother_detials($check_array);

            $today = date('d/m/Y');

            $mother_unique_number = rand(1001, 9999);
            $child_unique_number = 'UNIQUE' . rand(10001, 99999);
//            echo $check_mother_if_exist;
//            print_r($data);
//            die;
            // when not forced to make new entry if mother/mother found in the database..
            if ($check_mother_if_exist == true && $data['force_new_child_entry'] == false) {

                return array('status' => 206, 'message' => 'बशर्ते मोबाइल पहले से पंजीकृत हो।');
            }
            // if mother found but forcefully save new child.. then get mothers db id
            if ($check_mother_if_exist && $data['force_new_child_entry'] == true) {
                $mothr_id = $check_mother_if_exist;
            } else {


                $mthr_query = "INSERT INTO " . $this->mother_details_table . " (`mthrs_db_id`, `mthrs_name`, `mthrs_last_name`,"
                        . " `mthrs_unq_no`, `mthrs_mbl_no`, `mthrs_optn_mbl_no`, `mthrs_passwrd`, `age`, `area`,"
                        . " `area_code`, `anm_name`, `anm_contact`, `asha_name`, `asha_contact`, `mthr_status`) "
                        . "VALUES (NULL, '" . $data['mother_name'] . "', NULL, '" . $mother_unique_number . "',"
                        . " '" . $data['mobile'] . "', NULL, '" . substr($data['mobile'], 0, -5) . "', '" . $data['mother_age'] . "',"
                        . " '" . $data['area_name'] . "', '" . $data['area_name'] . "', '" . $data['anm_name'] . "', "
                        . "'" . $data['anm_contact'] . "', '" . $data['asha_name'] . "', '" . $data['asha_contact'] . "', 1);";
                $res = $this->db->query($mthr_query);
                $mothr_id = $this->db->insert_id();
//            $mothr_id = 428;
            }

            // once mother data is added now add child data..
            // on if child data is provided..
            if ($mothr_id > 0 && isset($data['child_name']) && isset($data['child_dob'])) {

                $vaccine_qry = '';
                $vaccine_val_qry = '';
                $comma = ',';
                $previous_vaccine_id = 0;
                $previous_vaccine_status = false;
                $check_for_done_date = array();
                ///// in case child DOB is less than today so set previous vaccines to false 
                $date1 = date_create($data['child_dob']);
                $date2 = date_create(date('Y-m-d'));
                $diff = date_diff($date1, $date2);
//                            echo $diff->format("%R%a");
                $vaccine_date = $data['child_dob'];
//                var_dump( $data['vaccinations']);
                if ($diff->format("%R%a") > 0) {
                    // this is the case when DOB is less than today..
                    // now set all previous vaccines as true...
                    $previous_vaccine_status = (!empty($data['vaccinations'])) ?  true : false;
                    //$vaccine_date = date('Y-m-d');
//                    echo "dob is less";
                }
                
                foreach ($this->vaccination_arr as $v => $vaccination):

                    $vaccine_date = (!empty($this->vaccination_daydiff_arr[$vaccination]['_date'])) ? date('Y-m-d', strtotime($data['child_dob'] . ' + ' . $this->vaccination_daydiff_arr[$vaccination]['_date'])) : $vaccine_date; // dob in case when blank day is recevied and that is the case for bucket 1 vaccines to be 
                    $done_date = (!empty($this->vaccination_daydiff_arr[$vaccination]['_last_date'])) ? date('Y-m-d', strtotime($data['child_dob'] . ' + ' . $this->vaccination_daydiff_arr[$vaccination]['_last_date'])) : $data['child_dob'];
                    
//                    print_r($vaccine_date);die;
                    
                    if (in_array($vaccination, $data['vaccinations'])) {
//                            echo $data['child_dob'], "  ssss " , date('Y-m-d', strtotime($today));
                        if ($diff->format("%R%a") > 0) {
//                            echo 'yyyyyyy';
//                            $vaccine_date = date('Y-m-d');
                            $previous_vaccine_id = $v;
                        }
//                        echo "this time i m here for vaccine : $vaccination  \r\n";
                        $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "`, `" . $vaccination . $this->date_arr[1] . "` , `" . $vaccination . $this->date_arr[2] . "`" . $comma;
//
                        $vaccine_val_qry .= " 'true', '" . $vaccine_date . "' , '" . $done_date . "' , '$today' " . $comma;
                        
                        
                        
                        // now get vaccines to check done date with less than 28 days..
                        if (array_key_exists($vaccination, $this->vaccination_date_change_case)) {
                                $vaccine_to_be_updated = $this->vaccination_date_change_case[$vaccination];
                                $check_for_done_date = $vaccine_to_be_updated['next_bucket'];
                        }
                        
//                        print_r($check_for_done_date);die;
                        
                    } else {


//                        print_r($check_for_done_date);
//                        echo "vaccine: ",$vaccination , " statur: ". $previous_vaccine_status . " vaccine date : " . $vaccine_date ."\r\n";
//                            echo "$previous_vaccine_id => prev $v vaccine: ".$vaccination;
                        if ($previous_vaccine_status == true && $previous_vaccine_id > 0 && $previous_vaccine_id < $v) {
//                            echo "$v => future vaccine to be set false: " . $vaccination . "\r\n";
                            // now check if next bucket vaccine to update..

//                            print_r($check_for_done_date);
                            
                                if (isset($check_for_done_date) && in_array($vaccination, $check_for_done_date)) {
                                    // this is the case when we hvae to check & compare vaccine done date
                                    $new_vaccine_name = $vaccination;

                                    // now check if earlier date is less than current days difference
//                                                            echo $today . ' + ' . str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days'."\r\n";
                                    // days difference from first
//                                   echo $number_of_days = (!empty($this->vaccination_daydiff_arr[$new_vaccine_name]['_date'])) ? $this->vaccination_daydiff_arr[$new_vaccine_name]['_date'] : '0 day';
                                    $number_of_days = str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days';

                                    $new_vaccine_date = date("Y-m-d", strtotime($vaccine_date . '+' . $number_of_days));

                                    
                                    $date1 = date_create(date('y-m-d'));
//                                                            $date1->modify($number_of_days);
                                    $date2 = date_create($new_vaccine_date);
                                    $diff = date_diff($date1, $date2);

////                                                            print_r($date1);
//                                                            echo " <= "."\r\n => ";
//                                                            print_r($diff);
//                                                            print_r($date1);
//                                                            print_r($date2);
//                                                            echo "\r\n vaccine name $new_vaccine_name =>  $vaccine_date is this correct? ".$new_vaccine_date."\r\n";
//                                                           
//                                    echo "\r\n" . $diff->format("%R%a");
                                    $vaccine_qry .= " `" . $new_vaccine_name . "`, `" . $new_vaccine_name . $this->date_arr[0] . "`, `" . $new_vaccine_name . $this->date_arr[1] . "` " . $comma;
//
//                                    $vaccine_qry .= " , `" . $new_vaccine_name . "` = 'false', ";
                                    if ($diff->format("%R%a") < 28) {
                                        
                                        // now add number days.. for example 28 for next vaccine... to maintain gap in bucket..
//                                        echo $new_vaccine_name . ' less than 28 days new date is => ' . date("Y-m-d", strtotime('+' . str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days')) . "\r\n";

                                        $vaccine_val_qry .= " 'false', '" . date("Y-m-d", strtotime('+' . str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days')) . "' , '" . $done_date . "'" . $comma;
                                    } else {
                                        // previous date only..
//                                                            echo "no need to update \r\n";echo "\r\n".$vaccination," to =>",$new_vaccine_date;
                                        $vaccine_val_qry .= " 'false', '" . date("Y-m-d", strtotime($new_vaccine_date . '+' . str_replace(' DAY', '', $vaccine_to_be_updated['days']) . ' days')) . "' , '" . $done_date . "'" . $comma;
                                    }


                            } else {
//                                echo "when no vaccine is found for date comparison" . "\r\n";
                                
                                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "` , `" . $vaccination . $this->date_arr[1] . "`" . $comma;
                                $vaccine_val_qry .= " 'false', '" . $vaccine_date . "' , '" . $done_date . "' " . $comma;
   
                            }


                        } elseif ($previous_vaccine_status == false) {
//                            echo 'yes we are here => ' . $vaccination . "\r\n";
                            $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "` , `" . $vaccination . $this->date_arr[1] . "`" . $comma;
                            $vaccine_val_qry .= " 'false', '" . $vaccine_date . "' , '" . $done_date . "' " . $comma;
                        } else {
//                            echo $previous_vaccine_status;echo "yaha kyun aya?"."\r\n";

                            if(isset($check_for_done_date) && !in_array($vaccination, $check_for_done_date)){
                                // these vaccines are which are earlier then the selected one.. so marking them all as true..
//                                echo 'yes we are here for vaccine => ' . $vaccination . "\r\n"; 
//                                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "` , `" . $vaccination . $this->date_arr[1] . "` , `" . $vaccination . $this->date_arr[2] . "`" . $comma;
                                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "` , `" . $vaccination . $this->date_arr[1] . "` ". $comma;
                                $vaccine_val_qry .= " 'true', '" . $vaccine_date . "' , '" . $done_date . "' " . $comma;
                            }
                        }
                    }

                endforeach;

//                echo "\r\n" . ' vaccine qry; ', $vaccine_qry;
//                echo "\r\n" . 'vaccing val qry: ', $vaccine_val_qry;

                $child_qry = "INSERT INTO " . $this->children_details_table . " (`child_id`, `mthr_id`, `mother_name`,"
                        . " `child_contact`, `child_unq_id`, `child_name`, `child_dob`, `child_status`, `is_vacinated_before`,"
                        . $vaccine_qry
                        . " `added_time`) "
                        . "VALUES (NULL, '" . $mothr_id . "', '" . $data['mother_name'] . "', '" . $data['mobile'] . "',"
                        . " '" . $child_unique_number . "', '" . $data['child_name'] . "', '" . date('Y-m-d', strtotime($data['child_dob'])) . "',"
                        . " 'yes','yes',"
                        . $vaccine_val_qry
                        . " NOW() "
                        . ");";

                $res = $this->db->query($child_qry);
                $child_id = $this->db->insert_id();

//                echo "\r\n" . @$mthr_query . "\r\n" . 'Child query: =>', "\r\n" .$child_qry;die;
            }

            $result = ($mothr_id) ? true : false;
            return array('status' => 200, 'message' => 'माँ / बच्चे की जानकारी को सहेज लिया गया है। यूनिक नंबर है - ' . $mother_unique_number);
        }
        return array('status' => 200, 'message' => 'कृपया एक मोबाइल नंबर प्रदान करें');
    }

    public function get_mothekr_detials($data) {

        if (isset($data['mobile'])) {
            $mobile_number = $data['mobile'];
            $condition = "mthrs_mbl_no LIKE " . "'" . $mobile_number . "%' "
                    . " OR mthrs_name LIKE " . "'" . $mobile_number . "%'  ";
            $this->db->select('*');
            $this->db->from($this->mother_details_table);
            $this->db->where($condition);
            $this->db->limit(1);
            $query = $this->db->get();

//                    return $query->result();
//                    $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
            $result = ($query->num_rows() > 0) ? $query->result_array() : false;
            return array('status' => 200, 'data' => $result);
        }
        return array('status' => 204, 'msg' => 'कृपया एक इनपुट प्रदान करें');
    }

    public function getANMDetailsByID($data) {

        if (isset($data['user_id'])) {
            $anm_data_array = array();
            $user_id = $data['user_id'];

            //"SELECT u.mobile,u.id,u.first_name, u.is_active,u.last_login,u.created_at, a.anm_name a.territory_id, (SELECT GROUP_CONCAT(territory_name SEPARATOR ', ') as territory_list  FROM `territory` WHERE `id` IN (3,4)) as t.territory_list FROM `users` u, anms a, territory t WHERE u.id=".$data['user_id']." AND u.is_active=1 AND u.id=a.user_id";
            $anm_qry = "SELECT u.mobile,u.id as user_id,u.first_name, u.is_active,u.last_login,u.created_at, a.id as anm_relation_id, a.anm_name, a.territory_id FROM `users` u LEFT JOIN  anms a ON u.id=a.user_id  WHERE u.id=" . $user_id . " AND u.is_active=1 ";
            $res = $this->db->query($anm_qry);
            $result = ($res->num_rows() > 0) ? $res->result_array() : false;

            $anm_data_array['anm_data'] = $result[0];

            $anm_data = $anm_data_array['anm_data'];
//            print_r($anm_data);
            // now get list of locations...
            if (isset($anm_data['territory_id']) && !empty($anm_data['territory_id'])) {

                $territory_qry = "SELECT id as territory_id,GROUP_CONCAT(territory_name SEPARATOR ', ') as territory_list FROM `territory` WHERE `id` IN (" . $anm_data['territory_id'] . ") GROUP BY id";
                $res = $this->db->query($territory_qry);
//                print_r($res);
                $anm_data_array['anm_data']['locations'] = ($res->num_rows() > 0) ? $res->result_array() : false;



//                
                // now get asha name list w.r.t locations...

                foreach ($anm_data_array['anm_data']['locations'] as $l => $location):
                    $asha_rel_qry = "SELECT GROUP_CONCAT(asha_id SEPARATOR ', ') as asha_ids FROM `anm_asha_relation` WHERE anm_id = '" . $anm_data['anm_relation_id'] . "' AND location_id='" . $location['territory_id'] . "' ";
                    $res = $this->db->query($asha_rel_qry);
                    $result = ($res->num_rows() > 0) ? $res->result_array() : false;
                    if (count($result) && !empty($result[0]['asha_ids'])) {
                        $asha_ids = $result[0]['asha_ids'];
                        //SELECT * FROM `asha` WHERE `id` IN (1,2) ORDER BY `asha_name` ASC
                        $asha_qry = "SELECT * FROM `asha` WHERE `id` IN ($asha_ids) ORDER BY `asha_name` ASC";
                        $res = $this->db->query($asha_qry);
                        $result = ($res->num_rows() > 0) ? $res->result_array() : false;
//                        print_r($result);
                        $anm_data_array['anm_data']['locations'][$l]['asha_details'] = $result;
                    }
//                    print_r($result);
                endforeach;
            }


            return array('status' => 200, 'data' => $anm_data_array);
        }
    }

    public function findKey($array, $keySearch) {
        foreach ($array as $key => $item) {
            if ($key == $keySearch) {
                return true;
            } elseif (is_array($item) && findKey($item, $keySearch)) {
                return true;
            }
        }
        return false;
    }

}
