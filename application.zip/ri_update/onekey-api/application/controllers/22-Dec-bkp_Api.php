<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

    var $check_auth_client;

    function __construct() {

        parent::__construct();

        $this->output->set_header('Access-Control-Allow-Origin: *');

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == "OPTIONS") {
            die('Option method used to access');
        }
        // Load file helper
        $this->load->model('Api_model');

        $this->check_auth_client = $this->Api_model->auth();
        if ($this->check_auth_client != true) {
            return false;
        }
    }

    public function login() {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->Api_model->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $mobile = $params['mobile'];
                $code = $params['code'];
                $response = $this->Api_model->login($mobile, $code);
                json_output($response['status'], $response);
            }
        }
    }

    public function logout() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->Api_model->check_auth_client();
            if ($check_auth_client == true) {
                $response = $this->Api_model->logout();
                json_output($response['status'], $response);
            }
        }
    }

    public function children_all_data() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
//            $check_auth_client = $this->Api_model->auth();
            if ($this->check_auth_client == true) {
                $response = $this->Api_model->children_all_data();
                json_output($response['status'], $response);
            }
        }
    }

    public function update_vaccination() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
//            $check_auth_client = $this->Api_model->auth();
            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $response = $this->Api_model->update_vaccination($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function upcoming_ri_due_list() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $login_user_id = $this->input->get_request_header('User-ID', TRUE);
//                $anm_data = $this->Api_model->getANMDetailsByID($login_user_id);
//                print_r($anm_data);die;
                $response = $this->Api_model->upcoming_ri_due_list($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function get_child_for_vaccination() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_child_for_vaccination($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function get_mother_detials() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_mother_detials($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function get_child_details() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_child_details($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function get_vaccinations_done_today() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_vaccinations_done_today($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function add_mother_details() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->add_mother_details($params);
                json_output($response['status'], $response);
            }
        }
    }

    public function search_number() {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $response = $this->Api_model->search_mother_detials($params);

                json_output(200, $response);
            }
        }
    }

    public function get_vaccination_list() {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $response = $this->Api_model->get_vaccination_list($params);

                json_output(200, $response);
            }
        }
    }

    public function get_anm_details() {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $response = $this->Api_model->getANMDetailsByID($params);

                json_output(200, $response);
            }
        }
    }
    
       public function get_child_by_id_and_phone() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_child_by_id_and_phone($params);
                json_output($response['status'], $response);
            }
        }
    }
    
       public function get_mother_by_id_and_phone() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_mother_by_id_and_phone($params);
                json_output($response['status'], $response);
            }
        }
    }
    
       public function get_child_by_mother_id_and_phone() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_child_by_mother_id_and_phone($params);
                json_output($response['status'], $response);
            }
        }
    }
    
       public function get_mothers_by_phone() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {

            if ($this->check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $response = $this->Api_model->get_mothers_by_phone($params);
                json_output($response['status'], $response);
            }
        }
    }

}
