$(document).ready(function () {

$("#msg").hide();

    var vaccination_list = [];
    var update_button = '<button class="btn btn-warning my-2 my-sm-0" type"submit" value="Update">अपडेट करें</button>';
    var add_new_mother_button = '<small>कोई रिकॉर्ड नहीं मिला! तो यहां <a href="add_new_mother/"> क्लिक करे  माँ / बच्चे की नई इंट्री करें! </a>';
    var click_to_select_for_vaccination_text = 'टीका के लिए क्लिक करें';
    var no_record_found = '<strong>कोई रिकॉर्ड नहीं मिला!</strong>';


    fetch_today_done_vaccintion();

    function fetch_today_done_vaccintion() {

        $.ajax({
            url: api_url + "api/get_vaccinations_done_today/",
            method: "POST",
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_done_list tbody').empty();
                $('#vaccination_done_list').show();
            },
            success: function (data)
            {

                var output;
                var myObj = data.data;
                
                
                if (myObj == '') {
                    output += '<tr><td colspan="4">' + no_record_found + '</td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr>' + '<td class="'+ myObj[i].child_id +'">' + myObj[i].mthrs_name + '</td><td>' + myObj[i].child_name + '</td><td>' + myObj[i].mthrs_mbl_no +
                                '</td><td class="vaccine_list"><div class="custom-controlw rcustom-checkbox">' ; 
                                for (v in myObj[i].done_vaccinations) {

//                                    output += '<label class="form-check-label">'+myObj[i].done_vaccinations[v].replace("_"," ") + '</label>&nbsp;&nbsp;<input class="" type="checkbox" name="vaccination_name[]" disabled="disbaled" checked="checked" value="' + myObj[i].done_vaccinations[v] + '" />|&nbsp;';
                                       output += '<label class="custom-input"><input class="form-check-input" type="checkbox" name="vaccinations[]" checked="checked" value="' + myObj[i].done_vaccinations[v] + '">'  +myObj[i].done_vaccinations[v].replace("_", " ").replace("_", " ") + '<span class="checkmark"></span></label>';
                                }
                                
                                output += '</div></td></tr>';
                    }
                }

//                var add_new_mother = '<tr><td colspan="5"><small>कोई रिकॉर्ड नहीं मिला! तो नई माँ जोड़ सकते हैं! यहां क्लिक करे --></small> <a href="add_new_mother/">नई माँ जोड़ें</a></td></tr>';
                $('#vaccination_done_list tbody').html(output);
//                $('#vaccination_done_list tbody').append(add_new_mother);
            }
        });
    }


});
