$(document).ready(function () {

$("#msg").hide();

    var vaccination_list = [];
    var update_button = '<button class="btn btn-warning my-2 my-sm-0" type"submit" value="Update">अपडेट करें</button>';
    var add_new_mother_button = '<small>कोई रिकॉर्ड नहीं मिला! तो यहां <a href="add_new_mother/"> क्लिक करे  माँ / बच्चे की नई इंट्री करें! </a>';
    var click_to_select_for_vaccination_text = 'टीका के लिए क्लिक करें';
    var no_record_found = '<strong>कोई रिकॉर्ड नहीं मिला!</strong>';


//        var selected_vaccinations = $('input[name="vaccinations[]"]:checked').map(function (_, el) {
//            return $(el).val();
//        }).get().join(',');

    $('#add_mother').on('click', function (event) {

        // check if mother name & mobile number is missing
        var mobile = $("#mobile").val();
        var mother_name = $("#mother_name").val();
        
        if(mobile=='undefined' || mobile==''){
            alert('Mobile number cannot be blank!');
            $("#mobile").focus();
            return false;
        }else{
            if(mobile.length>10 || mobile.length<10){
                alert('Invalid number');
                $("#mobile").focus();
            return false;
            } 
        }
        if(mother_name=='undefined' || mother_name==''){
            alert('mother name cannot be blank!');
            $("#mother_name").focus();
            return false;
        }

        var selected_vaccinations = [];
        $.each($("input[name='vaccinations[]']:checked"), function () {
            selected_vaccinations.push($(this).val());
        });

        add_mother_details(selected_vaccinations);
    });



    function add_mother_details(selected_vaccinations) {

        $.ajax({
            url: api_url + "api/add_mother_details/",
            method: "POST",
            data: JSON.stringify({
                "mobile": $("#mobile").val(),
                "mother_name": $("#mother_name").val(),
                "mother_age": '',
                "area_name": '',
                "anm_name": '',
                "anm_contact": '',
                "asha_name": '',
                "asha_contact": '',
                "child_name": $("#child_name").val(),
                "child_dob": $("#child_dob").val(),
                "vaccinations": selected_vaccinations
            }),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#msg').empty();
            },
            success: function (data)
            {
                console.log(data);
                console.log(data.status);
                // success
                if (data.status === '200') {
//                    alert(data.message);
                    $("#msg").show().addClass('warning').html(data.message);
                } else {
//                    alert(data.message);
                    $("#msg").show().addClass('success').html(data.message);
                }

            }
        });
    }


    fetch_vaccination_array();

    function fetch_vaccination_array() {
        $.ajax({
            url: api_url + "api/get_vaccination_list/",
            method: "POST",
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_array').empty();
            },
            success: function (data)
            {
                var output;
                var myObj = data.data;
                vaccination_list = data.data;
                if (myObj !== false) {
                    for (var i in myObj) {
                        // here you structured the code depend on the table of yours
                        output += myObj[i] + '&nbsp;&nbsp;<input type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">&nbsp;&nbsp;|&nbsp;&nbsp;';
                    }
                }
                $("#vaccination_array").html(output.replace('undefined', ''));
            }
        });
    }

    fetch_today_done_vaccintion();

    function fetch_today_done_vaccintion() {

        $.ajax({
            url: api_url + "api/get_vaccinations_done_today/",
            method: "POST",
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_done_list tbody').empty();
                $('#vaccination_done_list').show();
            },
            success: function (data)
            {

                var output;
                var myObj = data.data;
//                console.log(myObj);
//                console.log(data.query);
                if (myObj == false) {
                    output += '<tr><td colspan="4">' + no_record_found + '</td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr>' + '<td>' + myObj[i].mthrs_name + '</td><td>' + myObj[i].child_name + '</td><td>' + myObj[i].mthrs_mbl_no +
                                '</td><td>' ; 
                                for (v in myObj[i].done_vaccinations) {

                                    output += myObj[i].done_vaccinations[v] + '&nbsp;&nbsp;<input type="checkbox" name="vaccination_name[]" checked="checked" value="' + myObj[i].done_vaccinations[v] + '" />&nbsp;|&nbsp;';
                                }
                                
                                output += '</td></tr>';
                    }
                }

//                var add_new_mother = '<tr><td colspan="5"><small>कोई रिकॉर्ड नहीं मिला! तो नई माँ जोड़ सकते हैं! यहां क्लिक करे --></small> <a href="add_new_mother/">नई माँ जोड़ें</a></td></tr>';
                $('#vaccination_done_list tbody').html(output);
//                $('#vaccination_done_list tbody').append(add_new_mother);
            }
        });
    }

    fetch_today_due_vaccintion();

    function fetch_today_due_vaccintion() {
        $.ajax({
            url: api_url + "api/upcoming_ri_due_list/",
            method: "POST",
            data: JSON.stringify({view: "html"}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_list tbody').empty();
                $('#vaccination_list').show();
            },
            success: function (data)
            {

                var output;
                var myObj = data.data;
//                console.log(myObj);
//                console.log(data.query);
//                console.log(vaccination_list);
                if (myObj == false) {
                    output += '<tr><td colspan="4"><strong>कोई रिकॉर्ड नहीं मिला!</strong></td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr>' + '<td>' + myObj[i].mother_name + '</td><td>' + myObj[i].child_name +
                                '</td><td>' + myObj[i].child_contact + '</td><td>';
                        for (v in myObj[i].due_vaccinations) {

                            output += myObj[i].due_vaccinations[v] + '<input type="checkbox" name="vaccination_name[]" value="' + myObj[i].due_vaccinations[v] + '" />&nbsp;|&nbsp;';
                        }

                        output += '</td><td><button class="btn btn-warning my-2 my-sm-0 update_vaccine" type"submit" id="' + myObj[i].child_id + '" value="Update">अपडेट करें</button></td></tr>';
                    }
                }

                var add_new_mother = '<tr><td colspan="5">' + add_new_mother_button + '</td></tr>';
                $('#vaccination_list tbody').html(output);
                $('#vaccination_list tbody').append(add_new_mother);
                
                // update record based on selection of vaccinations... and update button click..
                $(".update_vaccine").click(function(){
                    if(confirm("Are you sure want to update?")){
                        // now proceed with updating vaccination..
                            var selected_vaccinations = [];
                            $.each($("input[name='vaccination_name[]']:checked"), function () {
                                selected_vaccinations.push($(this).val());
                            });

                            // now hit the update API..
                            $.ajax({
                                url: api_url + "api/update_vaccination/",
                                method: "POST",
                                data: JSON.stringify({
                                    "vaccination_name": selected_vaccinations,
                                    "select": 'true',
                                    "child_id": $(this).attr("id")
                                }),
                                headers: {
                                    "Authorization": token,
                                    "User-ID": user_id,
                                    "Content-Type": "application/json"
                                },
                                beforeSend: function () {
                                    $('#msg').empty();
                                },
                                success: function (data)
                                {

                                    // success
                                    if (data.status == '200') {
                    //                    alert(data.message);
                                        $("#msg").show().addClass('success').html(data.message);
                                        
                                    } else {
                    //                    alert(data.message);
                                        $("#msg").show().addClass('warning').html(data.message);
                                    }

                                }
                            });
                            
                    }else{
                        alert('cancelled!');
                    }
                });
            }
        });
    }

    $('#mother_data_result_div').hide();
    $('#child_data_result_div').hide();
    $('#mother_mobile').on('keyup', function (event) {
        if (!this.value) {
            $('#mother_data_result_div').hide();
            $('#child_data_result_div').hide();
        }
        if (this.value.length < 2) {
            return;
        }
        event.preventDefault();
        mobile_number = this.value;
        $.ajax({
            url: api_url + "api/search_number/",
            method: "POST",

            data: JSON.stringify({"mobile": mobile_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#mother_search_result tbody').empty();
                $('#mother_data_result_div').show();
            },
            success: function (res)
            {

                console.log(res.query);
                var myObj = res.data;//JSON.parse(mother_details);
                console.log(myObj);
                var output;
                if (myObj == false) {
                    output += '<tr><td colspan="4">' + no_record_found + '</td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr><td><a id="' + myObj[i].mthrs_db_id + '" data-value="' + myObj[i].mthrs_mbl_no + '" class="select_mother" href="#">' + click_to_select_for_vaccination_text + '</a></td>' + '<td>' + myObj[i].mthrs_name + '</td><td>' + myObj[i].mthrs_mbl_no +
                                '</td><td>' + myObj[i].area_code + '</td><td>' + myObj[i].asha_name + '</td></tr>';
                    }
                }

                var add_new_mother = '<tr class="add_new_record"><td colspan="5">' + add_new_mother_button + '</td></tr>';

                // after finish creating html structure, append the output

                $('#mother_search_result tbody').empty();
                // into the table
                $('#mother_search_result').append(output);
                $('#mother_search_result').append(add_new_mother);

                // now select mother from the search result..
                $('a.select_mother').on('click', function () {
//                    alert($(this).attr('id'));
//                    $(this).data('value');
//                    child
                    // now get child data for selected mother...
                    event.preventDefault();
                    $.ajax({
                        url: api_url + "api/get_child_details/",
                        method: "POST",
                        data: JSON.stringify({'mother_id': $(this).attr('id'), 'mobile': $(this).data('value')}),
                        headers: {
                            "Authorization": token,
                            "User-ID": user_id,
                            "Content-Type": "application/json"
                        },
                        beforeSend: function () {
                            $('#child_search_result tbody').empty();
                            $('#child_data_result_div').show();
                        },
                        success: function (res)
                        {
//                            console.log(res);
                            var childObj = res.data;//JSON.parse(mother_details);
//                            console.log(childObj);

                            var child_data;
                            if (childObj == false) {
                                output += '<tr><td colspan="4"><small>कोई रिकॉर्ड नहीं मिला</small></td></tr>';

                            } else {

                                for (i in childObj) {

                                    // here you structured the code depend on the table of yours
                                    // <td><a href="'+childObj[i].mthrs_db_id+'">Select</a></td>
                                    child_data += '<tr><td><a id="' + childObj[i].child_contact + '" data-value="' + childObj[i].child_id
                                            + '" class="select_child" href="#">' + click_to_select_for_vaccination_text + '</a></td><td>' + childObj[i].child_name + '</td>' + '<td>' + childObj[i].mother_name + '</td><td>' + childObj[i].child_contact +
                                            '</td><td>' + childObj[i].child_dob + '</td></tr>';
                                }

                            }

                            var add_new_child = '<tr><td colspan="5"><a href="add_new_mother/?mobile=' + mobile_number + '">नए बच्चे की इंट्री करें</a></td></tr>';

                            // after finish creating html structure, append the output
                            $('#mother_data_result_div').hide();
                            $('#child_data_result_div').show();
                            $('#child_search_result tbody').empty();
                            // into the table
                            $('#child_search_result').append(child_data);
                            $('#child_search_result').append(add_new_child);

                            // now pull data of selected child...
                            $('a.select_child').on('click', function () {

                                // now get child data for selected mother...

                                event.preventDefault();
                                $.ajax({
                                    url: api_url + "api/upcoming/",
                                    method: "POST",
                                    data: JSON.stringify({'child_ids': $(this).attr('id')}),
                                    headers: {
                                        "Authorization": token,
                                        "User-ID": user_id,
                                        "Content-Type": "application/json"
                                    },
                                    beforeSend: function () {
                                        $('#child_search_result tbody').empty();
                                        $('#child_data_result_div').show();
                                    },
                                    success: function (res)
                                    {
//                                        console.log(res);
                                        var childObj = res.data;//JSON.parse(mother_details);
                                        var child_data;

                                        for (i in childObj) {

                                            // here you structured the code depend on the table of yours
                                            child_data += '<tr><td>' + childObj[i].child_name + '</td>' + '<td>' + childObj[i].mother_name + '</td><td>' + childObj[i].child_contact + '</td>' + '<td>';
                                            for (v in vaccination_list) {
                                                var selected = eval(childObj[i].vaccination_list[v]);
                                                console.log(selected);
                                                child_data += vaccination_list[v] + '<input type="checkbox" name="vaccination_name[]" value="' + vaccination_list[v] + '" />&nbsp;|&nbsp;';
                                            }

                                            child_data += '</td><td><button type"submit" value="Update">डेटा भेजें</button></td></tr>';
                                        }

                                        // after finish creating html structure, append the output
                                        $('#mother_data_result_div').hide();
                                        $('#child_data_result_div').hide();
                                        $('#child_search_result tbody').empty();
                                        $('#vaccination_list tbody').empty();
                                        // into the table
                                        var add_new_mother = '<tr class="add_new_record"><td colspan="5"><small>कोई रिकॉर्ड नहीं मिला! तो माँ / बच्चे की नई इंट्री करें! यहां क्लिक करे --></small> <a href="add_new_mother/">नई माँ जोड़ें</a></td></tr>';
                                        $('#vaccination_list tbody').append(child_data);
                                        $('#vaccination_list tbody').append(add_new_mother);
                                    }
                                });
                            });
                        }
                    });
                });
            }
        })
    });

});
