

fetch_anm_details();


function anm_ajax_post(url, vars, if_redirect_url) {
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file

    var url = url;
    var vars = vars;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request

    hr.setRequestHeader("Authorization", token);
    hr.setRequestHeader("User-ID", user_id);
    hr.setRequestHeader("Content-Type", "application/json");

    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function () {
        if (hr.readyState == 4) {
            var return_data = hr.responseText;
//                    console.log(hr);console.log(hr.status);
            if (hr.status == '200') {

                if (return_data != 'undefined') {
                    var data = JSON.parse(return_data);
//                    console.log(data);
                    var anm_data = data.data.anm_data;
                    var anm_name = anm_data.anm_name;
                    var anm_contact = anm_data.mobile;
                    $(".anm_detail_name").text(anm_name);
                    $(".anm_detail_mobile").text(anm_contact);
                }

            } else if (hr.status == '204') {

                // no data found
            }
        }
    };
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request

}



function fetch_vaccination_array() {
    $.ajax({
        url: api_url + "api/get_vaccination_list/",
        method: "POST",
        headers: {
            "Authorization": token,
            "User-ID": user_id,
            "Content-Type": "application/json"
        },
        beforeSend: function () {
            $('#vaccination_array').empty().addClass("custom-control- -custom-checkbox");
        },
        success: function (data)
        {
            var output;
            var myObj = data.data;
            vaccination_list = data.data;
            if (myObj !== false) {
                for (var i in myObj) {
                    // here you structured the code depend on the table of yours
//                        output += '<div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">' + myObj[i].replace("_", " ") + '</label></div>';
                    output += '<label class="custom-input"><input class="form-check-input" type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">' + myObj[i].replace("_", " ").replace("_", " ") + '<span class="checkmark"></span></label>';
                }
            }
            $("#vaccination_array").html(output.replace('undefined', ''));
        }
    });
}






function fetch_anm_details() {


    var url = api_url + "api/get_anm_details/";
    var data = {"user_id": user_id};
    var vars = JSON.stringify(data);

    anm_ajax_post(url, vars);

}