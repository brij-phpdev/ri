

fetch_anm_details();


function anm_ajax_post(url, vars, if_redirect_url) {
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file

    var url = url;
    var vars = vars;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request

    hr.setRequestHeader("Authorization", token);
    hr.setRequestHeader("User-ID", user_id);
    hr.setRequestHeader("Content-Type", "application/json");

    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function () {
        if (hr.readyState == 4) {
            var return_data = hr.responseText;
//                    console.log(hr);console.log(hr.status);
            if (hr.status == '200') {

                if (return_data != 'undefined') {
                    var data = JSON.parse(return_data);
//                    console.log(data);
                    var anm_data = data.data.anm_data;
                    var anm_name = anm_data.anm_name;
                    var anm_contact = anm_data.mobile;
                    $(".anm_detail_name").text(anm_name);
                    $(".anm_detail_mobile").text(anm_contact);
                }

            } else if (hr.status == '204') {

                // no data found
            }
        }
    };
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request

}



function fetch_vaccination_array() {
    $.ajax({
        url: api_url + "api/get_vaccination_list/",
        method: "POST",
        headers: {
            "Authorization": token,
            "User-ID": user_id,
            "Content-Type": "application/json"
        },
        beforeSend: function () {
            $('#vaccination_array').empty().addClass("custom-control- -custom-checkbox");
        },
        success: function (data)
        {
            var output;
            var myObj = data.data;
            vaccination_list = data.data;
            if (myObj !== false) {
                for (var i in myObj) {
                    // here you structured the code depend on the table of yours
//                        output += '<div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">' + myObj[i].replace("_", " ") + '</label></div>';
                    output += '<label class="custom-input"><input class="form-check-input" type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">' + myObj[i].replace("_", " ").replace("_", " ") + '<span class="checkmark"></span></label>';
                }
            }
            $("#vaccination_array").html(output.replace('undefined', ''));
        }
    });
}






function fetch_anm_details() {


    var url = api_url + "api/get_anm_details/";
    var data = {"user_id": user_id};
    var vars = JSON.stringify(data);

    anm_ajax_post(url, vars);

}

function fetch_today_due_vaccintion() {

    $.ajax({
        url: api_url + "api/upcoming_ri_due_list/",
        method: "POST",
        data: JSON.stringify({view: "html"}),
        headers: {
            "Authorization": token,
            "User-ID": user_id,
            "Content-Type": "application/json"
        },
        beforeSend: function () {
            $('#vaccination_list tbody').empty();
            $('#vaccination_list').show();
        },
        success: function (data)
        {

            var output;
            var myObj = data.data;
//                console.log(myObj);
                console.log(data.query);
//                console.log(vaccination_list);
            if (myObj == false) {
                output += '<tr><td colspan="4"><strong>कोई रिकॉर्ड नहीं मिला!</strong></td></tr>';

            } else {
                for (var i in myObj) {

                    output += '<tr class="' + myObj[i].child_id + '">' + '<td>' + myObj[i].mother_name + '</td><td>' + myObj[i].child_name +
                            '</td><td>' + myObj[i].child_contact + '</td>';

                    output += '<td><a href="update_child/' + myObj[i].child_id + '/' + myObj[i].child_contact + '"><button class="btn btn-warning my-2 my-sm-0 ">अपडेट करें</button></a></td></tr>';
                }
            }

            $('#vaccination_list tbody').html(output);

            // call update click button
//            update_record();
        }
    });
}


function get_due_list() {

    $.ajax({
        url: api_url + "api/get_due_list/",
        method: "POST",
        data: JSON.stringify({view: "html"}),
        headers: {
            "Authorization": token,
            "User-ID": user_id,
            "Content-Type": "application/json"
        },
        beforeSend: function () {
            $('#vaccination_list tbody').empty();
            $('#vaccination_list').show();
        },
        success: function (data)
        {

            var output;
            var myObj = data.data;
//                console.log(myObj);
                console.log(data.query);
//                console.log(vaccination_list);
            if (myObj == false) {
                output += '<tr><td colspan="4"><strong>कोई रिकॉर्ड नहीं मिला!</strong></td></tr>';

            } else {
                for (var i in myObj) {

                    output += '<tr class="' + myObj[i].child_id + '">' + '<td>' + myObj[i].mother_name + '</td><td>' + myObj[i].child_name +
                            '</td><td>' + myObj[i].child_contact + '</td>';

                    output += '<td><a href="update_child/' + myObj[i].child_id + '/' + myObj[i].child_contact + '"><button class="btn btn-warning my-2 my-sm-0 ">अपडेट करें</button></a></td></tr>';
                }
            }

            $('#vaccination_list tbody').html(output);

            // call update click button
//            update_record();
        }
    });
}



function sortTable(tableID) {

    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById(tableID);

    switching = true;
    /* Make a loop that will continue until
     no switching has been done: */
    while (switching) {
        // Start by saying: no switching is done:
        switching = false;
        rows = table.rows;
        
        /* Loop through all table rows (except the
         first, which contains table headers): */
        for (i = 1; i < (rows.length - 1); i++) {
            // Start by saying there should be no switching:
            shouldSwitch = false;
            /* Get the two elements you want to compare,
             one from current row and one from the next: */
            x = rows[i].getElementsByTagName("TD")[0];
            y = rows[i + 1].getElementsByTagName("TD")[0];
            // Check if the two rows should switch place:
            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                // If so, mark as a switch and break the loop:
                shouldSwitch = true;
                break;
            }
        }
        if (shouldSwitch) {
            /* If a switch has been marked, make the switch
             and mark that a switch has been done: */
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}