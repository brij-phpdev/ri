$(document).ready(function(){

 //load_data();

 function load_csv_titles()
 {
  $.ajax({
   url:"load_csv_titles",
   method:"POST",
   success:function(data)
   {
	console.log(data);
    //$('#imported_csv_data').html(data);
   }
  })
 }

 function load_data()
 {
  $.ajax({
   url:"import_csv",
   method:"POST",
   success:function(data)
   {
    $('#imported_csv_data').html(data);
   }
  })
 }

 $('#import_csv').on('submit', function(event){
  event.preventDefault();
  var formData = new FormData(this);
  $.ajax({
   url:"load_csv_titles",
   method:"POST",
   data:formData,
   contentType:false,
   cache:false,
   processData:false,
   beforeSend:function(){
    $('#import_csv_btn').html('Importing...');
   },
   success:function(data)
   {

    //$('#import_csv')[0].reset();
    //$('#import_csv_btn').attr('disabled', false);
    //$('#import_csv_btn').html('Import Done');
//$('#imported_csv_data').html();
//    $('#imported_csv_data').html(data);
	var d = ["Mother Name", "Father Name", "Child Name", "Child D.O.B", "Contact Number", "Additional Number", "Last Vacination", "Vaccination Date","ANM Name","Asha Name","Location"];

	 var output;
       $.each(d,function(i,e) {
          // here you structured the code depend on the table of yours
           output += '<tr><td>'+d[i]+'</td><td>'+data+'</td></tr>';
       });

       // after finish creating html structure, append the output
       // into the table
       $('#csv_column').append(output);
   }
  })
 });
 
});
