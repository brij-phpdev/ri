$(document).ready(function () {

    $('#mother_data_result_div').hide();
    $('#child_data_result_div').hide();
    $('#mother_mobile').on('keyup', function (event) {
        if (!this.value) {
            $('#mother_data_result_div').hide();
            $('#child_data_result_div').hide();
        }
        if (this.value.length < 3) {
            return;
        }
        event.preventDefault();
        mobile_number = this.value;
        $.ajax({
            url: api_url + "api/search_number/",
            method: "POST",

            data: JSON.stringify({"mobile": mobile_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#mother_search_result tbody').empty();
                $('#mother_data_result_div').show();
            },
            success: function (res)
            {

                //console.log(data);
                var myObj = res.data;//JSON.parse(mother_details);
//                console.log(myObj);
                var output;
                if (myObj == false) {
                    output += '<tr><td colspan="4"><small>कोई रिकॉर्ड नहीं मिला</small></td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr><td><a id="' + myObj[i].mthrs_db_id + '" data-value="' + myObj[i].mthrs_mbl_no + '" class="select_mother" href="#">इसे चुनें</a></td>' + '<td>' + myObj[i].mthrs_name + '</td><td>' + myObj[i].mthrs_mbl_no +
                                '</td><td>' + myObj[i].area_code + '</td><td>' + myObj[i].asha_name + '</td></tr>';
                    }
                }

                var add_new_mother = '<tr><td colspan="5"><small>कोई रिकॉर्ड नहीं मिला! तो नई माँ जोड़ सकते हैं! यहां क्लिक करे --></small> <a href="add_new_mother/?mobile=' + mobile_number + '">नई माँ जोड़ें</a></td></tr>';

                // after finish creating html structure, append the output

                $('#mother_search_result tbody').empty();
                // into the table
                $('#mother_search_result').append(output);
                $('#mother_search_result').append(add_new_mother);

                // now select mother from the search result..
                $('a.select_mother').on('click', function () {
//                    alert($(this).attr('id'));
//                    $(this).data('value');
//                    child
                    // now get child data for selected mother...
                    event.preventDefault();
                    $.ajax({
                        url: api_url + "api/get_child_details/",
                        method: "POST",
                        data: JSON.stringify({'mother_id': $(this).attr('id'), 'mobile': $(this).data('value')}),
                         headers: {
                            "Authorization": token,
                            "User-ID": user_id,
                            "Content-Type": "application/json"
                        },
                        beforeSend: function () {
                            $('#child_search_result tbody').empty();
                            $('#child_data_result_div').show();
                        },
                        success: function (res)
                        {
//                            console.log(res);
                            var childObj = res.data;//JSON.parse(mother_details);
                            console.log(childObj);
                            var child_data;
                            if (childObj == false) {
                                output += '<tr><td colspan="4"><small>कोई रिकॉर्ड नहीं मिला</small></td></tr>';

                            } else {

                                for (i in childObj) {

                                    // here you structured the code depend on the table of yours
                                    // <td><a href="'+childObj[i].mthrs_db_id+'">Select</a></td>
                                    child_data += '<tr><td><a id="' + childObj[i].child_id + '" data-value="' + childObj[i].child_contact
                                            + '" class="select_child" href="?child_ids=' + childObj[i].child_id + '">इसे चुनें</a></td><td>' + childObj[i].child_name + '</td>' + '<td>' + childObj[i].mother_name + '</td><td>' + childObj[i].child_contact +
                                            '</td><td>' + childObj[i].child_dob + '</td></tr>';
                                }

                            }

                            var add_new_child = '<tr><td colspan="5"><a href="add_new_mother/?mobile=' + mobile_number + '">नया बच्चा जोड़ें</a></td></tr>';

                            // after finish creating html structure, append the output
                            $('#mother_data_result_div').hide();
                            $('#child_data_result_div').show();
                            $('#child_search_result tbody').empty();
                            // into the table
                            $('#child_search_result').append(child_data);
                            $('#child_search_result').append(add_new_child);

                            // now pull data of selected child...
                            $('a.select_child').on('click', function () {

                                // now get child data for selected mother...
                                event.preventDefault();
                                $.ajax({
                                    url: "../anm/index/",
                                    method: "POST",
                                    data: {'child_ids': $(this).attr('id')},
                                    beforeSend: function () {
                                        $('#child_search_result tbody').empty();
                                        $('#child_data_result_div').show();
                                    },
                                    success: function (res)
                                    {
                                        console.log(res);
                                        var childObj = res;//JSON.parse(mother_details);
                                        //console.log(childObj);
                                        var child_data;

                                        for (i in childObj) {

                                            // here you structured the code depend on the table of yours
                                            // <td><a href="'+childObj[i].mthrs_db_id+'">Select</a></td>
                                            child_data += '<tr><td><a id="' + childObj[i].child_id + '" data-value="' + childObj[i].child_contact
                                                    + '" class="select_child" href="#">इसे चुनें</a></td><td>' + childObj[i].child_name + '</td>' + '<td>' + childObj[i].mother_name + '</td><td>' + childObj[i].child_contact +
                                                    '</td><td>' + childObj[i].child_dob + '</td></tr>';
                                        }

                                        // after finish creating html structure, append the output
                                        $('#mother_data_result_div').hide();
                                        $('#child_data_result_div').show();
                                        $('#child_search_result tbody').empty();
                                        // into the table
                                        $('#child_search_result').append(child_data);
                                    }
                                });
                            });
                        }
                    });
                });
            }
        })
    });

});
