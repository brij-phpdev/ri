$(document).ready(function () {

    $("#msg").hide();

    var vaccination_list = [];
    var update_button = '<button class="btn btn-warning my-2 my-sm-0" type"submit" value="Update">अपडेट करें</button>';
    var add_new_mother_button = '<small>कोई रिकॉर्ड नहीं मिला! तो यहां <a href="add_new_mother/"> क्लिक करे  माँ / बच्चे की नई इंट्री करें! </a>';
    var click_to_select_for_vaccination_text = 'टीका के लिए क्लिक करें';
    var no_record_found = '<strong>कोई रिकॉर्ड नहीं मिला!</strong>';



    fetch_vaccination_array();

    fetch_today_due_vaccintion();


    function update_record() {
        // update record based on selection of vaccinations... and update button click..
        $(".update_vaccine").on("click", function () {
            if (confirm("Are you sure want to update?")) {
                // now proceed with updating vaccination..
                var selected_vaccinations = [];
                $.each($("input[name='vaccination_name[]']:checked"), function () {
                    selected_vaccinations.push($(this).val());
                });

                // now hit the update API..
                $.ajax({
                    url: api_url + "api/update_vaccination/",
                    method: "POST",
                    data: JSON.stringify({
                        "vaccination_name": selected_vaccinations,
                        "select": 'true',
                        "child_id": $(this).attr("id")
                    }),
                    headers: {
                        "Authorization": token,
                        "User-ID": user_id,
                        "Content-Type": "application/json"
                    },
                    beforeSend: function () {
                        $('#msg').empty();
                    },
                    success: function (data)
                    {
                                    console.log(data.query);
                        // success
                        if (data.status == '200') {
                            //                    alert(data.message);
                            $("#vaccination_list table tr." + $(this).attr("id")).hide();

                            $("#msg").show().removeClass('alert-warning').addClass('alert-success').html(data.message);
                            $("#msg").scrollTop(0);
                            alert(data.message);
                            refreshPage();
                        } else {
                            //                    alert(data.message);
                            $("#msg").show().removeClass('alert-success').addClass('alert-warning').html(data.message);

                        }

                    }
                });

            } else {
                alert('cancelled!');
            }
        });
    }


    function fetch_today_due_vaccintion() {

        $.ajax({
            url: api_url + "api/upcoming_ri_due_list/",
            method: "POST",
            data: JSON.stringify({view: "html"}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_list tbody').empty();
                $('#vaccination_list').show();
            },
            success: function (data)
            {

                var output;
                var myObj = data.data;
//                console.log(myObj);
//                console.log(data.query);
//                console.log(vaccination_list);
                if (myObj == false) {
                    output += '<tr><td colspan="4"><strong>कोई रिकॉर्ड नहीं मिला!</strong></td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr class="' + myObj[i].child_id + '">' + '<td>' + myObj[i].mother_name + '</td><td>' + myObj[i].child_name +
                                '</td><td>' + myObj[i].child_contact + '</td><td class="vaccine_list"><div class="custom-control- custom-checkbox-">';
                        for (v in myObj[i].due_vaccinations) {
//                            output += myObj[i].due_vaccinations[v] + '<input type="checkbox" name="vaccination_name[]" value="' + myObj[i].due_vaccinations[v] + '" />&nbsp;|&nbsp;';
//
                            output += '<label class="custom-input">'+myObj[i].due_vaccinations[v].replace("_", " ").replace("_", " ") + '<input type="checkbox" name="vaccination_name[]" value="' + myObj[i].due_vaccinations[v] + '" ><span class="checkmark"></span></label>';
                        }

                        output += '</div></td><td><button class="btn btn-warning my-2 my-sm-0 update_vaccine" type"submit" id="' + myObj[i].child_id + '" value="Update">अपडेट करें</button></td></tr>';
                    }
                }

                var add_new_mother = '<tr><td colspan="5">' + add_new_mother_button + '</td></tr>';
                $('#vaccination_list tbody').html(output);
                $('#vaccination_list tbody').append(add_new_mother);

                // call update click button
                update_record();
            }
        });
    }

    $('#mother_data_result_div').hide();
    $('#child_data_result_div').hide();
    $('#mother_mobile').on('keyup', function (event) {
        if (!this.value) {
            $('#mother_data_result_div').hide();
            $('#child_data_result_div').hide();
        }
        if (this.value.length < 2) {
            return;
        }
        event.preventDefault();
        mobile_number = this.value;
        $.ajax({
            url: api_url + "api/search_number/",
            method: "POST",

            data: JSON.stringify({"mobile": mobile_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#mother_search_result tbody').empty();
                $('#mother_data_result_div').show();
            },
            success: function (res)
            {

                console.log(res);
                var myObj = res.data;//JSON.parse(mother_details);
                console.log(myObj);
                var output;
                if (myObj == false) {
                    output += '<tr><td colspan="5">' + no_record_found + '</td></tr>';

                } else {
                    for (var i in myObj) {

                        // here you structured the code depend on the table of yours
                        // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                        output += '<tr><td><a id="' + myObj[i].mthrs_db_id + '" data-value="' + myObj[i].mthrs_mbl_no + '" class="select_mother" href="#">' + click_to_select_for_vaccination_text + '</a></td>' + '<td>' + myObj[i].mthrs_name + '</td><td>' + myObj[i].mthrs_mbl_no +
                                '</td><td>' + myObj[i].area_code + '</td><td>' + myObj[i].asha_name + '</td></tr>';
                    }
                }

                var add_new_mother = '<tr class="add_new_record"><td colspan="5">' + add_new_mother_button + '</td></tr>';

                // after finish creating html structure, append the output

                $('#mother_search_result tbody').empty();
                // into the table
                $('#mother_search_result').append(output);
                $('#mother_search_result').append(add_new_mother);

                // now select mother from the search result..
                $('a.select_mother').on('click', function () {
//                    alert($(this).attr('id'));
//                    $(this).data('value');
//                    child
                    // now get child data for selected mother...
                    event.preventDefault();
                    $.ajax({
                        url: api_url + "api/get_child_details/",
                        method: "POST",
                        data: JSON.stringify({'mother_id': $(this).attr('id'), 'mobile': $(this).data('value')}),
                        headers: {
                            "Authorization": token,
                            "User-ID": user_id,
                            "Content-Type": "application/json"
                        },
                        beforeSend: function () {
                            $('#child_search_result tbody').empty();
                            $('#child_data_result_div').show();
                        },
                        success: function (res)
                        {
//                            console.log(res);
                            var childObj = res.data;//JSON.parse(mother_details);
//                            console.log(childObj);

                            var child_data;
                            if (childObj == false) {
                                output += '<tr><td colspan="4"><small>कोई रिकॉर्ड नहीं मिला</small></td></tr>';

                            } else {

                                for (i in childObj) {

                                    // here you structured the code depend on the table of yours
                                    // <td><a href="'+childObj[i].mthrs_db_id+'">Select</a></td>
                                    //<td></td>
                                    child_data += '<tr><td><a id="' + childObj[i].child_contact + '" data-value="' + childObj[i].child_id
                                            + '" class="select_child" href="#">' + click_to_select_for_vaccination_text + '</a> | <a href="add_new_mother/?mobile=' + childObj[i].child_contact +  '">नए बच्चे की इंट्री करें</a> </td><td>' + childObj[i].child_name + '</td>' + '<td>' + childObj[i].mother_name + '</td><td>' + childObj[i].child_contact +
                                            '</td><td>' + childObj[i].child_dob + '</td></tr>';
                                }

                            }

//                            var add_new_child = '<tr><td colspan="5"><a href="add_new_mother/?mobile=' + mobile_number + '">नए बच्चे की इंट्री करें</a></td></tr>';

                            // after finish creating html structure, append the output
                            $('#mother_data_result_div').hide();
                            $('#child_data_result_div').show();
                            $('#child_search_result tbody').empty();
                            // into the table
                            $('#child_search_result').append(child_data);
//                            $('#child_search_result').append(add_new_child);

                            // now pull data of selected child...
                            $('a.select_child').on('click', function () {

                                // now get child data for selected mother...

                                event.preventDefault();
                                var selected_child_id = $(this).attr('data-value');
                                $.ajax({
                                    url: api_url + "api/upcoming_ri_due_list/",
                                    method: "POST",
                                    data: JSON.stringify({"child_ids": selected_child_id}),
                                    headers: {
                                        "Authorization": token,
                                        "User-ID": user_id,
                                        "Content-Type": "application/json"
                                    },
                                    beforeSend: function () {
                                        $('#msg').addClass("success").html('loading please wait');

                                        $('#vaccination_list tbody').html('');
                                    },
                                    success: function (res)
                                    {
                                        $('#child_data_result_div').hide();
                                        $('#msg').removeClass("success").html('');

//                                        console.log(res.query);
//                                        console.log(res);
                                        var myObj = res.data;//JSON.parse(mother_details);
//                                        var child_data;
                                        var output = '';
                                        if (myObj == false) {
                                            output += '<tr><td colspan="5"><strong>कोई रिकॉर्ड नहीं मिला!</strong></td></tr>';

                                        } else {
                                            for (var i in myObj) {
//                                                console.log(myObj[i].child_id);
//                                                console.log(selected_child_id);
                                                var highlight_class = (selected_child_id == myObj[i].child_id) ? ' alert alert-warning' : '';

                                                // here you structured the code depend on the table of yours
                                                // <td><a href="'+myObj[i].mthrs_db_id+'">Select</a></td>
                                                output += '<tr class="' + myObj[i].child_id + ' ' + highlight_class + '">' + '<td>' + myObj[i].mother_name + '</td><td>' + myObj[i].child_name +
                                                        '</td><td>' + myObj[i].child_contact + '</td><td class="vaccine_list">';
                                                for (v in myObj[i].due_vaccinations) {

//                                                    output += myObj[i].due_vaccinations[v] + '<input type="checkbox" name="vaccination_name[]" value="' + myObj[i].due_vaccinations[v] + '" />&nbsp;|&nbsp;';
                                                    output += '<label class="custom-input">'+myObj[i].due_vaccinations[v] + '<input type="checkbox" name="vaccination_name[]" value="' + myObj[i].due_vaccinations[v] + '" ><span class="checkmark"></span></label>';
                                                }

                                                output += '</td><td><button class="btn btn-warning my-2 my-sm-0 update_vaccine" type"submit" id="' + myObj[i].child_id + '" value="Update">अपडेट करें</button></td></tr>';
                                            }
                                        }

                                        var add_new_mother = '<tr><td colspan="5">' + add_new_mother_button + '</td></tr>';
                                        $('#vaccination_list tbody').append(output);
                                        $('#vaccination_list tbody').append(add_new_mother);

                                        // call update click button
                                        update_record();

                                    }
                                });
                            });
                        }
                    });
                });
            }
        })
    });


    


});
