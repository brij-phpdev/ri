$(document).ready(function(){


 $('input.vaccination_done').on('change', function(event){
  event.preventDefault();
//console.log($(this).prop('checked'));
//console.log(this.name + '==' );
  $.ajax({
   url:"../anm/update_vaccination",
   method:"POST",
   data:{'vaccination_name':this.value,'id':$(this).data('value'),'select':$(this).prop('checked')},
   beforeSend:function(){
    $('.msg').empty();
   },
   success:function(data)
   {
	console.log(data);
	$('.msg').html('Data updated!');
   }
  });
 });
 
});
