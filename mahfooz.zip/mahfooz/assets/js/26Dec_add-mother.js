$(document).ready(function () {


    $("#msg").hide();

    var vaccination_list = [];
    var update_button = '<button class="btn btn-warning my-2 my-sm-0" type"submit" value="Update">अपडेट करें</button>';
    var add_new_mother_button = '<small>कोई रिकॉर्ड नहीं मिला! तो यहां <a href="add_new_mother/"> क्लिक करे  माँ / बच्चे की नई इंट्री करें! </a>';
    var click_to_select_for_vaccination_text = 'टीका के लिए क्लिक करें';
    var no_record_found = '<strong>कोई रिकॉर्ड नहीं मिला!</strong>';
    var force_new_child_entry = false;
    


//        var selected_vaccinations = $('input[name="vaccinations[]"]:checked').map(function (_, el) {
//            return $(el).val();
//        }).get().join(',');

    $('#add_mother').on('click', function (event) {

        // check if mother name & mobile number is missing
        var mobile = $("#mobile").val();
        var mother_name = $("#mother_name").val();

        if (mobile == 'undefined' || mobile == '') {
            alert('Mobile number cannot be blank!');
            $("#mobile").focus();
            return false;
        } else {
            if (mobile.length > 10 || mobile.length < 10) {
                alert('Invalid number');
                $("#mobile").focus();
                return false;
            }
        }
        if (mother_name == 'undefined' || mother_name == '') {
            alert('mother name cannot be blank!');
            $("#mother_name").focus();
            return false;
        }

        var selected_vaccinations = [];
        $.each($("input[name='vaccinations[]']:checked"), function () {
            selected_vaccinations.push($(this).val());
        });

        add_mother_details(selected_vaccinations,force_new_child_entry);
    });



    function add_mother_details(selected_vaccinations, force_new_child_entry) {

        $.ajax({
            url: api_url + "api/add_mother_details/",
            method: "POST",
            data: JSON.stringify({
                "mobile": $("#mobile").val(),
                "mother_name": $("#mother_name").val(),
                "mother_age": '',
                "area": $("#area_name option:selected").attr('data-areacode'),
                "area_name": $("#area_name option:selected").val(),
                "anm_name": $("#anm_name").val(),
                "anm_contact": $("#anm_contact").val(),
                "asha_name": $("#asha_name option:selected").val(),
                "asha_contact": $("#asha_name option:selected").attr('data-mobile'),
                "child_name": $("#child_name").val(),
                "child_dob": $("#child_dob").val(),
                "force_new_child_entry": force_new_child_entry,
                "vaccine_date": $("#vaccine_date").val(),
                "vaccinations": selected_vaccinations
            }),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#msg').empty();
            },
            success: function (data)
            {
                console.log(data);
//                console.log(data.status);
                // success
                if (data.status == '206') {

                    // number already exist
                    $("#msg").show().removeClass('alert-success').addClass('alert-warning').html(data.message);
                    $("#msg").scrollTop(0);
                    $("#mobile").focus();
                    if(confirm('मोबाइल पहले से पंजीकृत है! क्या आप वाकई नया जोड़ना चाहते हैं?')){
                        add_mother_details(selected_vaccinations,true);
                    }else{
                        refreshPage();
                        return false;
                    }

                } else {
                    if (data.status == '200') {

                        $("#msg").show().removeClass('alert-warning').addClass('alert-success').html(data.message);
                        $("#msg").scrollTop(0);
                        $("#mobile").focus();
                        alert(data.message);
                        refreshPage();

                    } else {
                        $("#msg").show().removeClass('alert-success').addClass('alert-warning').html(data.message);

                        $("#mobile").text();
                        $("#mother_name").text();
                        $("#child_name").text();
                        $('input[type=checkbox]').prop('checked', false);
                    }
                }

                // now clean 

            }
        });
    }


    fetch_vaccination_array();

    function fetch_vaccination_array() {
        $.ajax({
            url: api_url + "api/get_vaccination_list/",
            method: "POST",
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#vaccination_array').empty().addClass("just-for-testing container");
            },
            success: function (data)
            {
                var output;
                var myObj = data.data;
                vaccination_list = data.data;
                if (myObj !== false) {

                    for (var i in myObj) {
                        // here you structured the code depend on the table of yours
                        output += '<div class="form-check"><label class="form-check-label"><input class="form-check-input" type="checkbox" name="vaccinations[]" value="' + myObj[i] + '">' + myObj[i].replace("_", " ") + '</label></div>';
//                        output += '<li><input type="checkbox" name="vaccinations[]" value="' + myObj[i] + '"><label class="custom-input">' + myObj[i].replace("_", " ").replace("_", " ") + '</label>';
                    }
                }
                $("#vaccination_array").html( '<ul class="ks-cboxtags">' +output.replace('undefined', '') + '</ul>');
            }
        });
    }


    fetch_asha_location_details();

    function fetch_asha_location_details() {

        $.ajax({
            url: api_url + "api/get_anm_details/",
            method: "POST",
            data: JSON.stringify({
                "user_id": user_id
            }),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $('#asha_name_list').empty();
            },
            success: function (data)
            {

//            console.log(data);
                var anm_name = '';
                var anm_contact = '';
                var locations = '';
                var asha_name_list = '<select class="form-control" id="asha_name" name="asha_name"><option>--select--</option>';
                var area_name_list = '<select class="form-control" id="area_name" name="area_name"><option>--select--</option>';

                if (data.data.anm_data != '') {
                    var anm_data = data.data.anm_data;

                    anm_name = anm_data.anm_name;
                    anm_contact = anm_data.mobile;
                    locations = anm_data.locations;
                }
                var asha_details_list;

//                console.log(locations);
//                console.log(asha_details);
                if (locations !== false) {
                    for (var location in locations) {
                        // here you structured the code depend on the table of yours
                        area_name_list += '<option data-areacode="'+ locations[location].parent_territory_name  +'" value="' + locations[location].territory_list + '" >' + locations[location].territory_list + '</option>';
                        if (locations[location].asha_details != 'null') {
                            asha_details_list = locations[location].asha_details;
//                        console.log(asha_details_list);
                            for (var asha in asha_details_list){
//                                console.log(asha_details_list[asha][0]);
                                asha_name_list += '<option data-mobile="' + asha_details_list[asha][0].mobile_number + '" value="' + asha_details_list[asha][0].asha_name + '">' + asha_details_list[asha][0].asha_name + ' < ' + asha_details_list[asha][0].mobile_number + ' >' + '</option>';
                            }
                        }
                    }
                    area_name_list += '</select>';
                    asha_name_list += '</select>';
                }
                $("#anm_name").val(anm_name);
                $("#anm_contact").val(anm_contact);
                $("#area_name_list").html(area_name_list);
                $("#asha_name_list").html(asha_name_list);
            }
        });
    }

    function refreshPage() {
        location.reload();
    }

});
