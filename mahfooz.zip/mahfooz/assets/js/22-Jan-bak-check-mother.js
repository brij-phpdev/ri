
var vaccination_list = [];
var update_button = '<button class="btn btn-warning my-2 my-sm-0" type"submit" value="Update">अपडेट करें</button>';
var add_new_mother_button = '<small>कोई रिकॉर्ड नहीं मिला! तो यहां <a href="add_new_mother/"> क्लिक करे  माँ / बच्चे की नई इंट्री करें! </a>';
var no_record_found = '<strong>कोई रिकॉर्ड नहीं मिला!</strong>';

$(document).ready(function () {

    $("#msg").hide();


    $('#display').on('click', function (event) {

        var mobile = $("#mobile").val();

        if (mobile == 'undefined' || mobile == '') {
            alert('Mobile number cannot be blank!');
            $("#mobile").focus();
            return false;

        } else {
            if (mobile.length < 2) {
                alert('name cannot be blank');
                $("#mobile").focus();
                return false;
            }
        }


        search_mother_details(mobile);
    });

});


function search_mother_details(mobile) {
    $.ajax({
        type: 'POST',
        url: api_url + "api/search_number/",
        dataType: "json",
        data: JSON.stringify({"mobile": mobile}),
        headers: {
            "Authorization": token,
            "User-ID": user_id,
            "Content-Type": "application/json"
        },
        beforeSend:function(){
            $("#msg").hide();
            $("#mother_details #number_search_child_result_table").empty();
            
        },
        success: function (res) {

//            console.log(res);

            var myObj1 = res.data;

           
            if (res.status == '200' && res.data!= false) {
                
                var myObj = res.data;//JSON.parse(mother_details);
                var mother_row = '';
                var child_row = '';
                var mothers = myObj.mothers;
                var children = myObj.children;
                for (var mother in mothers) {
                    console.log(mothers);
                     mother_row += "<td ><a href='findmother/" + mothers[mother].mthrs_db_id + "/" + mothers[mother].mthrs_mbl_no + "'> <button class='btn btn-success'>" + mothers[mother].mthrs_name + "</button> </a></td> ";
                }
                for (var child in children) {
                     child_row += "<td ><a href='update_child/" + children[child].child_id + "/" + children[child].child_contact + "'> <button class='btn btn-success'>" + children[child].child_name + "</button> </a></td> ";
                }

                var add_new_mother = "<td> <a href='add_new_mother/" +mobile + " ' > + माँ बच्चे की नई इंट्री करें</a> </td>";
                var add_new_child = "<td> <a href='add_new_mother/" +mobile +" ' > + बच्चे की नई इंट्री करें</a> </td>";
                $("#mother_details #number_search_mother_result_table").empty();
                $("#mother_details #number_search_mother_result_table").append(mother_row).append(add_new_mother);
                $("#mother_details #number_search_child_result_table").append(child_row).append(add_new_child);
                return false;
            }
            
            if (res.data== false) {
                $("#msg").removeClass('alert-success').addClass('alert-warning').html(no_record_found).show();
                var add_new_mother = "<td> <a href='add_new_mother/" + $("#mobile").val() + " ' > + माँ की नई इंट्री करें</a> </td>";
                $("#mother_details #number_search_mother_result_table").empty();
                $("#mother_details #number_search_mother_result_table").append(add_new_mother);

                return false;
            }
            
        }
    });
}