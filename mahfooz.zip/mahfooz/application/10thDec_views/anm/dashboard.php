
<!-- partial -->

<div class="row">

                        <div class="col-md-12">
                            <h3 class="grid-header panel-title">माँ के नाम / मोबाइल का उपयोग करके खोजें</h3><input class="form-control input-lg" type="text" id="mother_mobile" placeholder="9988776655 / ममता" aria-label="खोजें">
                        </div>

</div>
<div class="row">

    
    <div class="col-md-12">
        <div class="grid">
            <br/>
            <div id="mother_data_result_div" class="table-responsive mb-5" >
                <table class="table info-table table-bordered table-striped table-dark- " id="mother_search_result">
                    <thead><tr><td>टीकाकरण के लिए क्लिक करें</td><td>मां का नाम</td><td>मोबाइल नंबर</td><td>स्थान</td><td>आशा का नाम</td></tr></thead>
                    <tbody></tbody>
                </table>
            </div>
            <div id="child_data_result_div" class="table-responsive mb-5" >
                <table class="table info-table table-bordered table-striped table-dark-" id="child_search_result">
                    <thead><tr><td>टीकाकरण के लिए क्लिक करें</td><td>बच्चे का नाम</td><td>मां का नाम</td><td>मोबाइल नंबर</td><td>DOB</td></tr></thead>
                    <tbody></tbody>
                </table>
            </div>


            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
        
                            <div id="msg" class="alert alert-success success"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="grid-header panel-title">आज की टीकाकरण सूची</h3>
                        </div>
                    </div>
                </div>
                <div class="panel-body" id="vaccination_list">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <td>मां का नाम</td>
                                <td>बच्चे का नाम</td>
                                <td>मोबाइल नंबर</td>
                                <td>टीका</td>
                                <td>अपडेट</td>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>


</div>
