  <div class="page-body">
      <!-- partial:partials/_sidebar.html -->
      <div class="sidebar">
        <div class="user-profile">
          <div class="display-avatar animated-avatar">
            <img class="profile-img img-lg rounded-circle" src="<?php echo base_url();?>assets/images/profile/male/image_1.png" alt="profile image">
          </div>
          <div class="info-wrapper">
            <p class="user-name">Vishnu</p>
            <h6 class="display-income">Field Coordinator</h6>
          </div>
        </div>
        <ul class="navigation-menu">
          <li class="nav-category-divider">MAIN</li>
          <li>
            <a href="index.html">
              <span class="link-title">Dashboard</span>
              <i class="mdi mdi-gauge link-icon"></i>
            </a>
          </li>
          <li>
            <a href="#sample-pages" data-toggle="collapse" aria-expanded="false">
              <span class="link-title">Collected Data</span>
              <i class="mdi mdi-flask link-icon"></i>
            </a>
            <ul class="collapse navigation-submenu" id="sample-pages">
		<li>
                <a href="add_vaccination">Add Vaccination</a>
              </li>
		<li>
                <a href="<?php echo base_url();?>index.php/coordinator/import">Import Data</a>
              </li>
		<li>
                <a href="<?php echo base_url();?>index.php/coordinator/profile">Profile</a>
              </li>
              <li>
                <a href="#" target="_blank">Kids</a>
              </li>
              <li>
                <a href="#" target="_blank">Ladies (pregnant)</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="#ui-elements" data-toggle="collapse" aria-expanded="false">
              <span class="link-title">Target</span>
              <i class="mdi mdi-bullseye link-icon"></i>
            </a>
            <ul class="collapse navigation-submenu" id="ui-elements">
              <li>
                <a href="pages/ui-components/buttons.html">Kids</a>
              </li>
              <li>
                <a href="pages/ui-components/tables.html">Ladies (pregnant)</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="pages/forms/form-elements.html">
              <span class="link-title">New Record</span>
              <i class="mdi mdi-clipboard-outline link-icon"></i>
            </a>
          </li>
          <li>
            <a href="pages/charts/chartjs.html">
              <span class="link-title">Reports</span>
              <i class="mdi mdi-chart-donut link-icon"></i>
            </a>
          </li>
          
          <li class="nav-category-divider">Support</li>
          <li>
            <a href="../docs/docs.html">
              <span class="link-title">Ticket</span>
              <i class="mdi mdi-ticket link-icon"></i>
            </a>
          </li>
        </ul>
      </div>
