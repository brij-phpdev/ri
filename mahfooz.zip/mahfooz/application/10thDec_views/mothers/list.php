<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
    <!-- partial -->
      <div class="page-content-wrapper">
        <div class="page-content-wrapper-inner">
          <div class="content-viewport">
            <div class="row">
              <div class="col-12 py-5">
                <h4>Upcoming RI List</h4>

              </div>
            </div>
		
            <div class="row">
              
              <div class="col-md-12 equel-grid">
                <div class="grid">
                  <div class="grid-body py-3">
                    <p class="card-title ml-n1">Mothers/Kids list for upcoming RI Session</p>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-hover table-sm">
                      <thead>
                        <tr class="solid-header">
                          <th>Action</th>
                          <th>Mother/Gaurdian Name</th>
                          <th>Child Name</th>
                          <th>Contact No</th>
                          <th>Vaccination Due</th>
                        </tr>
                      </thead>
                      <tbody>
			<?php if(count($upcoming_ri_due_list)): ?>
			<?php foreach($upcoming_ri_due_list as $upcoming_ri_due): ?>
                        <tr>
                          <td class="pr-0">
                            <a class="" href="tel:<?php echo $upcoming_ri_due['child_contact'] ?>">Call</a> | <a href="#">Send SMS</a>
                          </td>
                          <td >
                            <small class="text-black font-weight-medium d-block"><?php echo $upcoming_ri_due['mother_name'] ?></small>
                          </td>
			<td>
                            <span class="text-gray">
                              <span class="status-indicator rounded-indicator small bg-primary"></span><?php echo $upcoming_ri_due['child_name'] ?> </span>
                          </td>
                          <td>
                            <small><?php echo $upcoming_ri_due['child_contact'] ?></small>
                          </td>
                          <td> <?php //echo findFirstOccurance($upcoming_ri_due,'false');
					$vaccination = array_search('false',$upcoming_ri_due);
					echo $vaccination, " | ", date_format(date_create($upcoming_ri_due[$vaccination.'_last_date']),'d-m-Y');
				 ?></td>
                        </tr>
			<?php endforeach; ?>
			<?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                  <a class="border-top px-3 py-2 d-block text-gray" href="#">
	                   <?php echo $this->pagination->create_links(); ?>
                  </a>
                </div>
              </div>
 <div class="query row" style="display: block">
	<pre><?php //print_r( $upcoming_ri_due_list) ?></pre>
</div>
              
            </div>
          </div>
        </div>
	<!--/div>
	</div-->
        <!-- content viewport ends -->

<?php
// Function for finding first and last 
// occurrence of an elements 
function findFirstOccurance( $arr, $x) 
{ 
    $first = -1;
    for ( $i = 0; $i < count($arr); $i++) 
    { 
        if ($x != $arr[$i]) 
            continue; 
        if ($first == -1) 
            $first = $i; 
    } 
    if ($first != -1) 
        echo "First Occurrence = ", $first; 
    else
        echo "Not Found"; 
} 
?>
