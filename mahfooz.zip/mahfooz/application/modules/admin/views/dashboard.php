
<!-- partial -->
<?php
//echo $today = date_create_from_format("Y-m-d",date("Y-m-d"));
//echo $today = date("Y-m-d");
//$days = date_interval_format('-7 days');
//$last_day = date_sub(date_create($today),$days);
//echo "today: ",$today," days: $days  last days $last_day ";

$monday = strtotime("last monday");
$monday = date('w', $monday) == date('w') ? $monday + 7 * 86400 : $monday;

$sunday = strtotime(date("Y-m-d", $monday) . " +6 days");

$this_week_sd = date("Y-m-d", $monday);
$this_week_ed = date("Y-m-d", $sunday);

//echo "Current week range from $this_week_sd to $this_week_ed ";

$date_array = array('today' => 'Today', 'week' => 'Week', 'month' => 'Month','year'=>'Year');
?>



<div class="row">
    <div class="columns" style="float: left;">
        <div class="well-"> <h2><?php echo $date_array[$report_duration] ?>'s Stats</h2>
        </div>
    </div>
    <div class="columns" style="float: right;">
        <div class="well-"> Filters => Period
            <form action="" method="post" name="filters">
                <select name="report_duration" onchange="document.forms['filters'].submit()">
                    <?php foreach ($date_array as $d => $date): ?>
                        <option <?php echo ($report_duration == $d) ? 'selected="selected"' : '' ?> value="<?php echo $d ?>"><?php echo $date ?></option>
                    <?php endforeach; ?>
                </select> 
                <input type="submit" name="filter" value="apply filter"/>
            </form>
        </div>
    </div>
</div>
<div class="row">
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">Number of Vaccines done (<?php echo $date_array[$report_duration] ?>)</h6>
                    <div class="flexbox mt-2">
                        <span class="color-green font-size-30"><?php echo isset($number_of_total_vaccines_done_today) ? $number_of_total_vaccines_done_today : 0 ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">New registrations (<?php echo $date_array[$report_duration] ?>)</h6>
                    <div class="flexbox mt-2">
                        <span class="color-blue font-size-30"><?php echo $registered_children ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">Total number of corrected record (<?php echo $date_array[$report_duration] ?>)</h6>
                    <div class="flexbox mt-2">
                        <span class="color-red font-size-30"><?php echo $corrected_records ?></span>

                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<div class="row">
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">Number of ANMs</h6>
                    <div class="flexbox mt-2">
                        <span class="color-099 font-size-30"><?php echo ($number_of_anms) ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">Number of Asha</h6>
                    <div class="flexbox mt-2">
                        <span class="color-grey font-size-30"><?php echo $number_of_asha ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="span4 columns">
        <div class="well">

            <div class="col-md-12">
                <div class="box box-body">
                    <h6 class="text-uppercase">Total number of locations</h6>
                    <div class="flexbox mt-2">
                        <span class=" font-size-30"><?php echo $number_of_locations ?></span>

                    </div>
                </div>
            </div>

        </div>
    </div>

</div>