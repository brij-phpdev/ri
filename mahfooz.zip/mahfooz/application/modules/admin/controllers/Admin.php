<?php

#session_start(); //we need to start session in order to access it through CI

Class Admin extends MX_Controller {

    var $admin_api_url = '';
    var $admin_language = 'english';

    public function __construct() {

        parent::__construct();

        $this->admin_api_url = public_api_url();

        // Load form helper library
        $this->load->helper('form');

        // Load form validation library
        $this->load->library('form_validation');

        // Load session library
        $this->load->library('session');

//        $this->lang->load('information', 'english');
    }

    public function logout() {

        // Removing session data
        $sess_array = array(
            'username' => ''
        );
        $this->session->unset_userdata('logged_in', $sess_array);
        $data['message_display'] = 'Successfully Logout';
        redirect('/admin', $data);
    }

    // Show login page
    public function index() {

        $this->load->view('admin_login_form');
    }

    // Show dashboard page
    public function main() {

        $token = $this->input->get('token');
        $user_id = $this->input->get('user_id');

        $this->session->set_userdata('token', $token);
        $this->session->set_userdata('user_id', $user_id);
        $this->session->set_userdata('site_lang', $this->admin_language);
        $this->session->set_userdata('logged_in', TRUE);

        redirect('admin/dashboard');
    }

    public function dashboard() {


        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];
            
            $data['report_duration'] = !empty($this->input->post('report_duration')) ? $this->input->post('report_duration') : 'today' ;
            
             // number of new registrations 
            $json_response = $this->getDataUsingcURL('admin/registered_children/',$data);

            $decode_json = json_decode($json_response);

            if(isset($decode_json->data)):
                
                $data['registered_children'] = $decode_json->data->todays_registration;
                $data['query']['registered_children'] = $decode_json->query;
            else:
                $data['registered_children'] = 0;
            endif;
            
             // number of corrected vaccines
            $json_response = $this->getDataUsingcURL('admin/corrected_records_count/',$data);

            $decode_json = json_decode($json_response);
            
            if(isset($decode_json->data)):
                $data['corrected_records'] = $decode_json->data->corrected_records_count;
                $data['query']['corrected_records'] = $decode_json->query;
            else:
                $data['corrected_records'] = 0;
            endif;
            
            // no of vaccines done today
            $json_response = $this->getDataUsingcURL('admin/get_vaccinations_done_today/',$data);

            $decode_json = json_decode($json_response);
            
            if(isset($decode_json->data)):
                $data['number_of_total_vaccines_done_today'] = count($decode_json->data);
                $data['query']['number_of_total_vaccines_done_today'] = $decode_json->query;
            else:
                $data['number_of_total_vaccines_done_today'] = 0;
            endif;

            
            // total number of anms..
            
            $json_response = $this->getDataUsingcURL('admin/anm_list/', $data);

            $decode_json = json_decode($json_response);
            
             if(isset($decode_json->data)):
                $data['number_of_anms'] = count($decode_json->data);
                $data['query']['number_of_anms'] = $decode_json->query;
            else:
                $data['number_of_anms'] = 0;
            endif;
           
            // total number of ASHA...
            
            $json_response = $this->getDataUsingcURL('admin/asha/', $data);

            $decode_json = json_decode($json_response);

             if(isset($decode_json->data)):
                $data['number_of_asha'] = count($decode_json->data);
                $data['query']['number_of_asha'] = $decode_json->query;
            else:
                $data['number_of_asha'] = 0;
            endif;
 
            // total number of locations...
            
            $json_response = $this->getDataUsingcURL('admin/locations/', $data);

            $decode_json = json_decode($json_response);
            print_r($decode_json);
            if(isset($decode_json->data)):
                $data['number_of_locations'] = count($decode_json->data);
                $data['query']['number_of_locations'] = $decode_json->query;
            else:
                $data['number_of_locations'] = 0;
            endif;
            
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");
            //load the view
            $data['main_content'] = 'admin/dashboard';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function anm() {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
//            print_r($this->session->userdata('token'));
            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            $json_response = $this->getDataUsingcURL('admin/anm_list/', $data);

            $decode_json = json_decode($json_response);
            
             if(isset($decode_json->data)):
                $data['anms'] = $decode_json->data;
                $data['query']['anms'] = $decode_json->query;
            else:
                $data['anms'] = array();
            endif;
            
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");
            
            //load the view
            
            $content_view = 'admin/anm';
            // now check if add view is called
            if(!empty($this->uri->segment(3))){
                $additional_view = $this->uri->segment(3);
                $content_view .= "/$additional_view";
            }else{
                $default_view = "list";
                $content_view .= "/$default_view";
            }
            //load the view
            
            $data['main_content'] = $content_view;
            
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function anm_edit() {

        if ($this->session->userdata('logged_in')) {
//            die('what???');
            $session_data = $this->session->userdata('logged_in');
//            print_r($this->session->userdata('token'));

            $id = $this->uri->segment(3);
            $data['anm_id'] = $id;

            $json_response = $this->getDataUsingcURL('admin/anm_edit/', $data);

            $decode_json = json_decode($json_response);

            $data['anm'] = $decode_json->data;

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/anm/edit';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function asha() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            $json_response = $this->getDataUsingcURL('admin/asha/', $data);

            $decode_json = json_decode($json_response);

             if(isset($decode_json->data)):
                $data['asha'] = $decode_json->data;
                $data['query']['asha'] = $decode_json->query;
            else:
                $data['asha'] = array();
            endif;
            

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            $content_view = 'admin/asha';
            // now check if add view is called
            if(!empty($this->uri->segment(3))){
                $additional_view = $this->uri->segment(3);
                $content_view .= "/$additional_view";
            }else{
                $default_view = "list";
                $content_view .= "/$default_view";
            }
            //load the view
            
            $data['main_content'] = $content_view;
            
            
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function asha_edit() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $id = $this->uri->segment(3);
            $data['asha_id'] = $id;
            $json_response = $this->getDataUsingcURL('admin/asha_edit/', $data);

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];


            $decode_json = json_decode($json_response);

            $data['asha'] = $decode_json->data;
//          
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/asha/edit';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function locations() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            $json_response = $this->getDataUsingcURL('admin/locations/', $data);

            $decode_json = json_decode($json_response);
            if(isset($decode_json->data)):
                $data['locations'] = $decode_json->data;
                $data['query']['locations'] = $decode_json->query;
            else:
                $data['locations'] = array();
            endif;

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            $content_view = 'admin/locations';
            // now check if add view is called
            if(!empty($this->uri->segment(3))){
                $additional_view = $this->uri->segment(3);
                $content_view .= "/$additional_view";
            }else{
                $default_view = "list";
                $content_view .= "/$default_view";
            }
            //load the view
            
            $data['main_content'] = $content_view;
            
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function location_edit() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $id = $this->uri->segment(3);
            $data['location_id'] = $id;
            $json_response = $this->getDataUsingcURL('admin/location_edit/', $data);

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];


            $decode_json = json_decode($json_response);

            $data['location'] = $decode_json->data->current_location;
            $data['parent_locations'] = $decode_json->data->parent_locations;
//            print_r($data);die;
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/locations/edit';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function anm_location_asha() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            $json_response = $this->getDataUsingcURL('admin/anm_location_asha/', $data);

            $decode_json = json_decode($json_response);

            if(isset($decode_json->data)):
                $data['anm_location_ashas'] = $decode_json->data;
                $data['query']['anm_location_ashas'] = $decode_json->query;
            else:
                $data['anm_location_ashas'] = array();
            endif;

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            $content_view = 'admin/anm_location_asha';
            // now check if add view is called
            if(!empty($this->uri->segment(3))){
                
                $json_response = $this->getDataUsingcURL('admin/anm_list/', $data);

                $decode_json = json_decode($json_response);
                if(isset($decode_json->data)):
                    $data['anm_list'] = $decode_json->data;
                    $data['query']['anm_list'] = $decode_json->query;
               else:
                   $data['anm_list'] = array();
               endif;
                
                $json_response = $this->getDataUsingcURL('admin/asha/', $data);

                $decode_json = json_decode($json_response);
                if(isset($decode_json->data)):
                    $data['asha_list'] = $decode_json->data;
                    $data['query']['asha_list'] = $decode_json->query;
                else:
                    $data['asha_list'] = array();
                endif;
                
                $json_response = $this->getDataUsingcURL('admin/locations/', $data);
                
                $decode_json = json_decode($json_response);
                
                if(isset($decode_json->data)):
                    $data['locations_list'] = $decode_json->data;
                    $data['query']['locations_list'] = $decode_json->query;
                else:
                    $data['locations_list'] = array();
                endif;
                
                $additional_view = $this->uri->segment(3);
                $content_view .= "/$additional_view";
            }else{
                $default_view = "list";
                $content_view .= "/$default_view";
            }
            //load the view
            
            $data['main_content'] = $content_view;
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function anm_location_asha_edit() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $id = $this->uri->segment(3);
            $data['location_id'] = $id;
            $json_response = $this->getDataUsingcURL('admin/location_edit/', $data);

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];


            $decode_json = json_decode($json_response);

            $data['location'] = $decode_json->data->current_location;
            $data['parent_locations'] = $decode_json->data->parent_locations;
//            print_r($data);die;
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/locations/edit';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function vaccine_edit() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $child_id = $this->uri->segment(3);
            $mobile = $this->uri->segment(4);
            $data['child_id'] = $child_id;
            $data['mobile'] = $mobile;

            $json_response = $this->getDataUsingcURL('admin/get_child_by_id_and_phone/', $data);

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];


            $decode_json = json_decode($json_response);
            if(isset($decode_json->data)):
                $data['vaccine_edit'] = $decode_json->data;
                $data['query']['vaccine_edit'] = $decode_json->query;
            else:
                $data['vaccine_edit'] = array();
            endif;
//            print_r($data);die;
            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/vaccine/edit';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function vaccine_update() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            $data_to_store = $_POST;

            $json_response = $this->getDataUsingcURL('admin/update_vaccination/', $data_to_store);



            $decode_json = json_decode($json_response);
//            print_r($decode_json);die;
            if($decode_json->status==200){
                $this->session->set_flashdata('flash_message', 'vaccine_information_updated');
                redirect('admin/done_list');
            }else{
                $this->session->set_flashdata('flash_message', 'not_updated');
                redirect('admin/vaccine_edit');
            }

            //load the view
            
        } else {
            redirect('/');
        }
    }

    public function done_list() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $json_response = $this->getDataUsingcURL('admin/get_vaccinations_done_today/');

            $decode_json = json_decode($json_response);
//             print_r($decode_json);die;
             if(isset($decode_json->data)):
                $data['vaccines'] = $decode_json->data;
                $data['query']['vaccines'] = $decode_json->query;
            else:
                $data['vaccines'] = array();
            endif;

            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            //load the view
            $data['main_content'] = 'admin/vaccine/list';
            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }
    
    public function child() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');

            $json_response = $this->getDataUsingcURL('admin/children_all_data/');

            $decode_json = json_decode($json_response);
//             print_r($decode_json);die;
             if(isset($decode_json->data)):
                $data['children'] = $decode_json->data;
                $data['query']['children'] = $decode_json->query;
            else:
                $data['children'] = array();
            endif;


            $data['user_id'] = $session_data['user_id'];
            $data['token'] = $session_data['token'];

            // loading js
            $data['js_to_load'] = array("admin-common-functions.js");

            $content_view = 'admin/child';
            // now check if add view is called
            if(!empty($this->uri->segment(3))){
                $additional_view = $this->uri->segment(3);
                $content_view .= "/$additional_view";
            }else{
                $default_view = "list";
                $content_view .= "/$default_view";
            }
            //load the view
            
            $data['main_content'] = $content_view;

            $this->load->view('includes/template', $data);
        } else {
            redirect('/');
        }
    }

    public function getDataUsingcURL($api_end_point, $data = array(), $api_url = '') {

        $complete_api_url = (!empty($api_url) ? $api_url : public_api_url()) . $api_end_point;

        $json_string = !empty($data) ? json_encode($data) : '';
//        echo date("Y-m-d H:i:s")."<pre>",$complete_api_url;        print_r($json_string);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $complete_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $json_string,
            CURLOPT_HTTPHEADER => array(
                "Authorization: " . $this->session->userdata('token'),
                "User-ID: " . $this->session->userdata('user_id'),
                "Content-Type: application/json",
                "cache-control: no-cache"
            ),
        ));

        $response = curl_exec($curl);

        $err = curl_error($curl);
//        echo "<pre>"; print_r($response);echo "\r\nfff";print_r($err);die;
        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }

}

?>