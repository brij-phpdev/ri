

      <?php
//flash messages
if ($this->session->flashdata('flash_message')) {
    if ($this->session->flashdata('flash_message') == 'updated') {
        echo '<div class="alert alert-success">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Well done!</strong> child information updated successfully.';
        echo '</div>';
    } else {
        echo '<div class="alert alert-error">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
        echo '</div>';
    }
}
?>
      <div class="row">
        <div class="span12 columns">
          
          <table id="myTable" class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                <th class="yellow header headerSortDown">Mother Name </th>
                <th class="yellow header headerSortDown">Child </th>
                <th class="green header">Mobile Number</th>
                <th class="green header">Child DOB</th>
                <th class="green header">ANM</th>
                <th class="green header">Asha</th>
                <th class="green header">Area</th>
                <th class="red header">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if($children):
              foreach($children as $r => $row)
              {
//                  print_r($row);
                echo '<tr>';
                echo '<td>'.++$r.'</td>';
                echo '<td>'.$row->mother_name.'</td>';
                echo '<td>'.$row->child_name.'</td>';
                echo '<td>'.$row->child_contact.'</td>';
                echo '<td>'.$row->child_dob.'</td>';
                echo '<td>'.$row->anm_name.'</td>';
                echo '<td>'.$row->asha_name.'</td>';
                echo '<td>'.$row->area_code.'</td>';
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin").'/vaccine_edit/'.$row->child_id.'/'.$row->child_contact.'" class="btn btn-info">Edit</a>
                  <a href="'.site_url("admin").'/child/delete/'.$row->child_id.'" class="btn btn-danger">Deactivate</a>
                </td>';
                echo '</tr>';
              }
              else:
                  echo '<tr><td colspan="6"><center>No record found!</center></td></tr>';
              endif;
              ?>      
            </tbody>
          </table>

          <?php // echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>