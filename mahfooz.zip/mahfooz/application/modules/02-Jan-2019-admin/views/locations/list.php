

   
      
      <div class="row">
        <div class="span12 columns">
          
          <table id="myTable" class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                <th class="yellow header headerSortDown">Location (English)</th>
                <th class="yellow header">Location (Hindi)</th>
                <th class="green header">Parent</th>
                <th class="red header">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if($locations):
              foreach($locations as $r => $row)
              {
//                  print_r($row);
                echo '<tr>';
                echo '<td>'.++$r.'</td>';
                echo '<td>'.$row->territory_en_name.'</td>';
                echo '<td>'.$row->territory_list.'</td>';
                echo '<td>'.$row->parent_territory_name.'</td>';
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin").'/location_edit/'.$row->territory_id.'" class="btn btn-info">Edit</a>  
                  <a href="'.site_url("admin").'/location/delete/'.$row->territory_id.'" class="btn btn-danger">Deactivate</a>
                </td>';
                echo '</tr>';
              }
              else:
                  echo '<tr><td colspan="5"><center>No record found!</center></td></tr>';
              endif;
              ?>      
            </tbody>
          </table>

          <?php // echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>