


 
      <?php
      //flash messages
      if($this->session->flashdata('flash_message')){
        if($this->session->flashdata('flash_message') == 'updated')
        {
          echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Well done!</strong> Location updated with success.';
          echo '</div>';       
        }else{
          echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">×</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
          echo '</div>';          
        }
      }
      ?>
      
      <?php
      //form data
      $attributes = array('class' => 'form-horizontal', 'id' => '');

      //form validation
      echo validation_errors();

      echo form_open('admin/locations/update/'.$this->uri->segment(4).'', $attributes);

      ?>
        <fieldset>
          <div class="control-group">
            <label for="inputError" class="control-label">Location Name(En)</label>
            <div class="controls">
              <input type="text" id="" name="anm_name" value="<?php echo $location[0]->territory_en_name; ?>" >
              <!--<span class="help-inline">Woohoo!</span>-->
            </div>
          </div>
          <div class="control-group">
            <label for="inputError" class="control-label">Location Name (Hindi)</label>
            <div class="controls">
              <input type="text" id="" name="stock" value="<?php echo $location[0]->territory_name; ?>">
              <!--<span class="help-inline">Cost Price</span>-->
            </div>
          </div>     
          <div class="control-group">
            <label for="inputError" class="control-label">Parent Location</label>
            <div class="controls">
                <select name="territory_parent" >
                    <option value="">--Select One--</option>
                    <?php foreach($parent_locations as $parent_location): ?> 
                    <option <?php echo ($parent_location->id == $location[0]->territory_parent) ? 'selected="selected"' : '' ?> value="<?php echo $parent_location->id ?>"><?php echo $parent_location->territory_name ?></option>
                    <?php endforeach ?>
                </select>

            </div>
          </div>          
         
        
          <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save changes</button>
            <button class="btn" type="reset">Cancel</button>
          </div>
        </fieldset>

      <?php echo form_close(); ?>

 
     