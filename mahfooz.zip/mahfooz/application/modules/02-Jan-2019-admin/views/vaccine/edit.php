

<?php
//flash messages
if ($this->session->flashdata('flash_message')) {
    if ($this->session->flashdata('flash_message') == 'updated') {
        echo '<div class="alert alert-success">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Well done!</strong> product updated with success.';
        echo '</div>';
    } else {
        echo '<div class="alert alert-error">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
        echo '</div>';
    }
}
?>

<?php
//form data
$attributes = array('class' => 'form-horizontal', 'id' => '');

//form validation
echo validation_errors();

echo form_open('admin/vaccine_update/' . $this->uri->segment(3) . '/' . $this->uri->segment(4) . '', $attributes);


?>
<fieldset>
<?php
if($vaccine_edit):
    
if(isset($vaccine_edit->done_vaccines)):
    $done_vaccines = $vaccine_edit->done_vaccines;
endif;
if(isset($vaccine_edit->future_due_vaccines)):
    $future_due_vaccines = $vaccine_edit->future_due_vaccines;
endif;

if(isset($vaccine_edit->today_due_vaccines)):
    $today_due_vaccines = $vaccine_edit->today_due_vaccines;
endif;


$user_info_array = array('mother_name','child_contact','child_name','child_dob');
$exclude_array_edit = array('child_id', 'mthr_id', 'child_unq_id', 'is_vacinated_before', 'child_status',
    'done_vaccines', 'future_due_vaccines', 'today_due_vaccines', 'added_time', 'last_updation_time');

$true_n_false = array('true', 'false');
    
    
$row_class = '';
foreach ($vaccine_edit as $column_name => $child_info):
    if (in_array($column_name, $exclude_array_edit)) {
        continue;
    }


    if (strpos($column_name, '_date')) {
        
        $input_type = 'date';

        // now change vaccine done date format...
        if (strpos($column_name, '_done_date') && !empty($child_info)) {
            
            $max = ' max="'.date('Y-m-d').'" ';
            $row_class = ($child_info == date('d/m/Y')) ? 'alert alert-info' : '';

            $new_date = date_create_from_format('d/m/Y',$child_info);
            $date = $new_date->format('Y-m-d');
//            print_r($new_date);echo "Y-m-d => ";print_r($date);

            $child_info = $date;
        }else{
            $row_class = '';
        }
    } else {
        $max = '';
        $input_type = 'text';
        $row_class = (in_array($column_name, $user_info_array)) ? 'alert alert-success' : '';
    }
    ?>
        <div class="control-group <?php echo $row_class; ?>">
            <label for="inputError" class="control-label"><?php echo ucfirst(str_replace("_", " ", $column_name));//echo " ",$column_name ?></label>
            <div class="controls">
                <?php
                // for true & false for Vaccine..

                if (in_array($child_info, $true_n_false)) {
                    ?>
                    <select name="<?php echo $column_name ?>">
                    <?php foreach ($true_n_false as $tf): ?>
                            <option <?php echo ($child_info == $tf) ? 'selected="selected"' : '' ?> value="<?php echo $tf ?>"><?php echo $tf ?></option>
                        <?php endforeach; ?>
                    </select>
                        <?php
                    } else {
                        ?>

                    <input type="<?php echo $input_type ?>" id="<?php echo $column_name ?>" name="<?php echo $column_name ?>" value="<?php echo $child_info; ?>" <?php echo isset($max) ? $max : '' ?> >
                <?php } ?>
            </div>
        </div>
            <?php endforeach; ?>


    <div class="control-group">
        <input type="hidden" name="child_id" value="<?php echo $this->uri->segment(3) ?>"/>
        <input type="hidden" name="child_contact" value="<?php echo $this->uri->segment(4) ?>"/>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit">Save changes</button>
        <button class="btn" type="reset">Cancel</button>
    </div>
    <?php
    else:
        echo "<strong><center>In correct request, please try again !</center></strong>";
    endif;
    ?>
</fieldset>

<?php echo form_close(); ?>

</div>
