

      
      <div class="row">
        <div class="span12 columns">
          

          <table id="myTable" class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                <th class="yellow header headerSortDown">Anm name</th>
                <th class="green header">Mobile Number</th>
                <th class="red header">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($asha as $r => $row)
              {
                echo '<tr>';
                echo '<td>'.++$r.'</td>';
                echo '<td>'.$row->asha_name.'</td>';
                echo '<td>'.$row->mobile_number.'</td>';
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin").'/asha_edit/'.$row->id.'" class="btn btn-info">Edit</a>  
                  <a href="'.site_url("admin").'/asha/delete/'.$row->id.'" class="btn btn-danger">Deactivate</a>
                </td>';
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

          <?php // echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>