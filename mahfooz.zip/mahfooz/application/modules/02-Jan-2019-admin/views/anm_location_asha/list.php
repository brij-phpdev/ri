      
      <div class="row">
        <div class="span12 columns">
         

            <table id="myTable" class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                
                <th class="yellow header">Asha Name</th>
                <th class="yellow header">Asha Contact</th>
                <th class="yellow header">ANM</th>
                <th class="yellow header">Location (Hindi)</th>
                <th class="yellow header headerSortDown">Location (English)</th>
                <th class="red header">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($anm_location_ashas as $r => $row)
              {
                echo '<tr>';
                echo '<td>'.++$r.'</td>';
                echo '<td>'.$row->asha_name.'</td>';
                echo '<td>'.$row->asha_contact.'</td>';
                echo '<td>'.$row->anm_name.'</td>';
                echo '<td>'.$row->territory_name.'</td>';
                echo '<td>'.$row->territory_en_name.'</td>';
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin").'/location_edit/'.$row->id.'" class="btn btn-info">Edit</a>  
                  <a href="'.site_url("admin").'/location/delete/'.$row->id.'" class="btn btn-danger">Deactivate</a>
                </td>';
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

          <?php // echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>
      
  