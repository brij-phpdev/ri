      


<?php
//flash messages
if (isset($flash_message)) {
    if ($flash_message == TRUE) {
        echo '<div class="alert alert-success">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Well done!</strong> new anm/asha relationship added with success.';
        echo '</div>';
    } else {
        echo '<div class="alert alert-error">';
        echo '<a class="close" data-dismiss="alert">×</a>';
        echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
        echo '</div>';
    }
}
?>

<?php

//form data
$attributes = array('class' => 'form-horizontal', 'id' => '');


//form validation
echo validation_errors();


echo form_open('admin/anm_location_asha/add', $attributes);
?>
<fieldset>


    <div class="control-group">
        <label for="inputError" class="control-label">ANM Name</label>
        <div class="controls">
            <select name="anm_id">
                <option value="">-- select -- </option>
                <?php if ($anm_list):
                    foreach ($anm_list as $anm):
                        ?>
                        <option value="<?php echo $anm->id ?>"><?php echo $anm->anm_name ?> [<?php echo $anm->mobile_number ?>]</option>
                    <?php
                    endforeach;
                endif;
                ?>
            </select>

        </div>
    </div>
    <div class="control-group">
        <label for="inputError" class="control-label">Asha</label>
        <div class="controls">
            <select name="asha_id">
                <option value="">-- select -- </option>
                <?php
                if ($asha_list):
                    foreach ($asha_list as $asha):
                        ?>
                        <option value="<?php echo $asha->id ?>"><?php echo $asha->mobile_number ?> [<?php echo $asha->asha_name ?>]</option>
                    <?php
                    endforeach;
                endif;
                ?>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label for="inputError" class="control-label">Location</label>
        <div class="controls">
            <select name="location_id">
                <option value="">-- select -- </option>
                <?php
                if ($locations_list):
                    foreach ($locations_list as $l => $location):
                    // skipping parent ids from list
                    if($location->territory_parent==0){continue;}
                        ?>
                <option data-parent_name="<?php echo $location->parent_territory_name ?>" value="<?php echo $location->territory_id ?>"><?php echo $location->territory_en_name ?> [<?php echo $location->territory_list ?>]</option>
    <?php
    endforeach;
endif;
?>
            </select>

        </div>
    </div>



</form>
</div>
<div class="form-actions">
    <button class="btn btn-primary" type="submit">Save changes</button>
    <button class="btn" type="reset">Cancel</button>
</div>
</fieldset>

<?php echo form_close(); ?>


