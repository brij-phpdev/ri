<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->

        <title> OneKeyCare | आर आई सिस्टम</title>

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/shared/style.css">

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/demo_1/style.css">        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/signin.css" />
    </head>
    <body class="login-page text-center">
        <div class="row">

            <div class="col-md-12 col-12 text-center">
                <div id="msg" class="msg success"></div>
            </div>
        </div>
        <form class="form-signin" method="post" id="login-form">
            <a href="<?php echo base_url(); ?>"><img class="mb-4" src="<?php echo base_url(); ?>/assets/images/logo.png" alt="site logo"></a>
            <h1 class="h3 mb-3 font-weight-normal">कृपया साइन इन करें</h1>
            <label for="inputEmail" class="sr-only">मोबाइल नंबर</label>
            <input type="text" id="inputMobile" name="mobile" class="form-control" placeholder="मोबाइल नंबर" required autofocus>
            <label for="inputPassword" class="sr-only">पास कोड</label>
            <input type="password" id="inputCode" name="code" class="form-control" placeholder="पास कोड" required>
            <!--            <div class="checkbox mb-3">
                            <label>
                                <input type="checkbox" value="remember-me">मुझे लॉग इन रखना
                            </label>
                        </div>-->

            <button class="btn btn-lg btn-primary btn-block" onclick="ajax_post();return false;" type="submit">साइन इन करें</button>
            <p class="mt-5 mb-3 text-muted">&copy; 2019</p>
        </form>
        <!--page body ends -->
        <!-- SCRIPT LOADING START FORM HERE /////////////-->


        <!-- endbuild -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <!--<script src="<?php echo base_url(); ?>assets/vendors/js/core.js"></script>-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

        <script>
            function ajax_post() {
                // Create our XMLHttpRequest object
                var hr = new XMLHttpRequest();
                // Create some variables we need to send to our PHP file

                var url = "<?php echo public_api_url() . 'api/login' ?>";
                var vars = JSON.stringify({"mobile": $("#inputMobile").val(), "code": $("#inputCode").val()});
                hr.open("POST", url, true);
                // Set content type header information for sending url encoded variables in the request
                hr.setRequestHeader("Client-Service", "<?php echo client_service ?>");
                hr.setRequestHeader("Auth-Key", "<?php echo auth_key ?>");
                hr.setRequestHeader("Content-Type", "application/json");


                // Access the onreadystatechange event for the XMLHttpRequest object
                hr.onreadystatechange = function () {
                    if (hr.readyState == 4) {
                        var return_data = hr.responseText;
//                    console.log(hr);
//                    console.log(hr.status);
                        if (hr.status == '200') {
                            var obj = JSON.parse(return_data);
//                            console.log(obj);
                            $("#msg").addClass('alert alert-success').removeClass('alert-warning').html(obj.message + 'कृपया प्रतीक्षा करें कि हम डैशबोर्ड पर पुनर्निर्देशित कर रहे हैं!').scrollTop(0);
                            //
//                            alert(obj.message + 'कृपया प्रतीक्षा करें कि हम डैशबोर्ड पर पुनर्निर्देशित कर रहे हैं!');
                            setTimeout(function () {
                                window.location.href = "<?php echo base_url() ?>anm/main/?token=" + encodeURIComponent(obj.token) + "&user_id=" + obj.id;
                            }, 1000);
                            return false;
                        } else if (hr.status == '204') {

                            $("#msg").addClass('alert alert-warning').removeClass('alert-success').html('इस मोबाइल नंबर के लिए रिकॉर्ड नहीं मिला.').scrollTop(0);

                            return false;
                        
                        } else if (hr.status == '0') {

                            $("#msg").addClass('alert alert-warning').removeClass('alert-success').html('Server related issue. Kindly contact site administrator.').scrollTop(0);

                            return false;
                        }
                    }
                }
                // Send the data to PHP now... and wait for response to update the status div
                hr.send(vars); // Actually execute the request

            }
        </script>

    </body>
</html>