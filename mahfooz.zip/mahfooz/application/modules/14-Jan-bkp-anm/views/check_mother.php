<style type="text/css">
    .btn{
        color: #fff;
        font-size: 16px !important;
    }
    td{

        /* width: 33.5%;*/
        border: 1px solid #f2f4f9;
        padding: 10px;
    }
</style>

<div class="row">

    <div class="col-md-8">

        <div class="grid">
            <p class="grid-header"><?php echo $this->lang->line('search_mother_or_child_by_mobile') ?></p>
            <div class="grid-body">
                <div class="row">
                    <div class="col-md-8 alert alert-success" id="msg">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-8">

                        <div class="form-group row showcase_row_area">
                            <div class="col-md-3 showcase_text_area">
                                <label for="inputType1">मोबाइल नंबर</label>
                            </div>
                            <div class="col-md-6 showcase_content_area" style="padding-bottom: 15px;">
                                <input type="text" class="form-control" name="mobile" id="mobile" style="height:40px" value="" placeholder="मोबाइल नंबर">
                            </div>

                            <div class="col-md-3 showcase_content_area">
                                <button class="btn btn-success my-2 my-sm-0" style="display: none;" type="submit" id="check_mother" value="Update">OLD चेक करें </button> 
                                <button class="btn btn-success my-2 my-sm-0" type="submit" id="display" value="Update">चेक करें </button>

                            </div>



                        </div> </div> </div>


                <div class="row">

                    <div class="table-responsive" id="mother_details" >


                        <table id="number_search_mother_result_table" class="table table-bordered">

                            <tbody>

                            </tbody>

                        </table>
                        <table id="number_search_child_result_table" class="table table-bordered table-condensed">

                            <tbody>

                            </tbody>

                        </table>


                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
