<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$lang['welcome_message'] = 'You\'re welcome!';
$lang['date'] = 'दिनांक:';

// top nav

$lang['todays_due_vaccine_list'] = 'Todays Due list';
$lang['todays_done_vaccine_list'] = 'Today\'s Done List';
$lang['new_entry_mother_or_child'] = 'Add new Mother/Child';
$lang['logout'] = 'Log out';

// listing
$lang['mother_name'] = 'Mother\'s name';
$lang['child_name'] = 'Child name';
$lang['mobile_number'] = 'Mobile Number';
$lang['child_dob'] = 'Child DOB';
$lang['anm_mobile_number'] = 'Anm\'s Contact Number';
$lang['anm_name'] = 'Name of ANM';
$lang['asha_name'] = 'Name of ASHA';
$lang['asha_contact_number'] = 'ASHA\'s Contact Number';
$lang['location_name'] = 'Location name';
$lang['list_vaccines'] = 'List of Vaccines';

$lang['vaccine_done_date'] = 'Date of Vaccine';

$lang['vaccine'] = 'Vaccine';
$lang['action_title'] = 'Action';
$lang['action_text'] = 'Action';

$lang['todays_due_list'] = 'Today\'s due list';

$lang['search_mother_or_child_by_mobile'] = 'Search mother or child using mobile number';
$lang['search_using_mobile'] = 'Search using mobile number';
$lang['dashboard'] = 'Dashboard';
$lang['details_of_mother'] = 'Details of mother';
$lang['vaccines_already_given'] = 'Vaccines already given';
$lang['todays_vaccine_list'] = 'Today\s vaccine list';
$lang['future_vaccine_list'] = 'Future list of Vaccine';





// buttons
$lang['update_button_text'] = 'अपडेट करें';
$lang['entry_button_text'] = 'इंट्री करें';


// alert / confirm messages...
$lang['update_conform_msg'] = 'क्या आप वाकई अपडेट करना चाहते हैं?';