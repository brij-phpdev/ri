<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mother_model extends CI_Model {

        var $vaccination_arr = array('BCG', 'OPV_O', 'Hep_B', 'OPV1', 'OPV2', 'DPT1', 'DPT2', 'DPT3', 'HepB1', 'HepB2', 'HepB3'
        , 'RVV1', 'RVV2', 'RVV3', 'IPV1', 'IPV2', 'PENTA1', 'PENTA2', 'OPV3', 'PENTA3', 'IPV', 'MMR', 'MMR2'
        , 'JE1', 'VIT_A_1', 'OPV_BOOSTER', 'DPT_1_BOOSTER', 'JE2', 'VIT_A_2', 'VIT_A_3', 'VIT_A_4', 'VIT_A_5'
        , 'VIT_A_6', 'VIT_A_7', 'VIT_A_8', 'VIT_A_9', 'DPT_2_BOOSTER');
    var $vaccination_daydiff_arr = array(
                                    'BCG'=>array('_date'=>'','_last_date'=>'1 year'),
                                    'OPV_O'=>array('_date'=>'','_last_date'=>'15 days'),
                                    'Hep_B'=>array('_date'=>'','_last_date'=>'1 day'),
                                    'OPV1'=>array('_date'=>'42 days','_last_date'=>'1825 days'),
                                    'OPV2'=>array('_date'=>'70 days','_last_date'=>'1825 days'),
                                    'DPT1'=>array('_date'=>'42 days','_last_date'=>'730 days'),
                                    'DPT2'=>array('_date'=>'70 days','_last_date'=>'730 days'),
                                    'DPT3'=>array('_date'=>'70 days','_last_date'=>'730 days'),
                                    'HepB1'=>array('_date'=>'70 days','_last_date'=>'730 days'),
                                    'HepB2'=>array('_date'=>'70 days','_last_date'=>'730 days'),
                                    'HepB3'=>array('_date'=>'70 days','_last_date'=>'730 days'),
                                    'RVV1'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'RVV2'=>array('_date'=>'70 days','_last_date'=>'365 days'),
                                    'RVV3'=>array('_date'=>'98 days','_last_date'=>'365 days'),
                                    'IPV'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'IPV1'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'IPV2'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'PENTA1'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'PENTA2'=>array('_date'=>'70 days','_last_date'=>'365 days'),
                                    'OPV3'=>array('_date'=>'70 days','_last_date'=>'365 days'),
                                    'PENTA3'=>array('_date'=>'70 days','_last_date'=>'365 days'),
                                    'IPV'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'MMR'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'MMR2'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'JE1'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_1'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'OPV_BOOSTER'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'DPT_1_BOOSTER'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'JE2'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_2'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_3'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_4'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_5'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_6'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_7'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_8'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'VIT_A_9'=>array('_date'=>'42 days','_last_date'=>'365 days'),
                                    'DPT_2_BOOSTER'=>array('_date'=>'42 days','_last_date'=>'365 days'));
    
    var $date_arr = array('_date', '_last_date', '_done_date');

            
    function __construct() {
        // Set table name
        $this->table = 'mothers_details';
        $this->children_details = 'children_details';
    }

    /*
     * Fetch mothers data from the database
     * @param array filter data based on the passed parameters
     */

    function getRows($params = array()) {
        $this->db->select('*');
        $this->db->from($this->table);

        if (array_key_exists("where", $params)) {
            foreach ($params['where'] as $key => $val) {
                $this->db->where($key, $val);
            }
        }

        if (array_key_exists("returnType", $params) && $params['returnType'] == 'count') {
            $result = $this->db->count_all_results();
        } else {
            if (array_key_exists("id", $params)) {
                $this->db->where('id', $params['id']);
                $query = $this->db->get();
                $result = $query->row_array();
            } else {
                $this->db->order_by('id', 'desc');
                if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                    $this->db->limit($params['limit'], $params['start']);
                } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                    $this->db->limit($params['limit']);
                }

                $query = $this->db->get();
                $result = ($query->num_rows() > 0) ? $query->result_array() : FALSE;
            }
        }

        // Return fetched data
        return $result;
    }

    /*
     * Insert mothers data into the database
     * @param $data data to be insert based on the passed parameters
     */

    public function insert($data = array()) {
        if (!empty($data)) {
            // Add created and modified date if not included
            if (!array_key_exists("created", $data)) {
                $data['created'] = date("Y-m-d H:i:s");
            }
            if (!array_key_exists("modified", $data)) {
                $data['modified'] = date("Y-m-d H:i:s");
            }

            // Insert mother data
            $insert = $this->db->insert($this->table, $data);

            // Return the status
            return $insert ? $this->db->insert_id() : false;
        }
        return false;
    }

    /*
     * Update mother data into the database
     * @param $data array to be update based on the passed parameters
     * @param $condition array filter data
     */

    public function update($data, $condition = array()) {
        if (!empty($data)) {
            // Add modified date if not included
            if (!array_key_exists("modified", $data)) {
                $data['modified'] = date("Y-m-d H:i:s");
            }

            // Update mother data
            $update = $this->db->update($this->table, $data, $condition);

            // Return the status
            return $update ? true : false;
        }
        return false;
    }

    public function update_vaccination($data) {
        if (!empty($data)) {

            // Update vaccination data

            $query = "UPDATE `" . $this->children_details . "` SET `" . $data['vaccination_name'] . "` = '" . $data['select'] . "' ";
            // now check if false .. then remove date
            if ($data['select'] == 'true') {
                $vaccination_date = date('Y-m-d');
            }
            if ($data['select'] == 'false') {
                $vaccination_date = '';
            }
            $query .= ', ' . $data['vaccination_name'] . '_done_date' . " = '$vaccination_date' ";
            $query .= " WHERE `child_id` = " . $data['child_id'];
            //echo $query;
            $res = $this->db->query($query);
            return $res ? true : false;
        }
        return false;
    }

    public function upcoming_ri_due_list($date_range = 15, $child_ids = null, $limit = false) {
        // SELECT * FROM `children_details` WHERE BCG_last_date >= NOW() AND `BCG_last_date` < NOW() + INTERVAL 15 DAY AND BCG = 'false';
        // $query .= " (".$vaccination.$this->date_arr[1]. " >= NOW() AND ".$vaccination.$this->date_arr[1]. " < NOW() + INTERVAL 15 DAY AND ".$vaccination." = 'false') ";

//        $this->date_arr = array('date', '_last_date', '_done_date');
        $today = date('Y-m-d');
        $query = "SELECT c.* FROM " . $this->children_details . " c LEFT JOIN " . $this->table . " m ON "
                . "m.mthrs_mbl_no = c.child_contact WHERE ";
        foreach ($this->vaccination_arr as $v => $vaccination):
            $query .= ($v != 0) ? " OR " : '';
            $query .= " (" . $vaccination . $this->date_arr[1] . " >= NOW() AND " . $vaccination . $this->date_arr[1] . " < NOW() + INTERVAL $date_range DAY ) ";
            $query .= " OR (" . $vaccination . $this->date_arr[2] . " = '$today' ) ";
        endforeach;

        $query .= ($child_ids != null) ? " OR c.child_id='$child_ids'" : '';
        // appending limit
        $query .= " GROUP BY c.child_id ";

      
        $query .= ($limit != false) ? " LIMIT $limit" : '';
//        echo $query;
        $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        $result = ($res->num_rows() > 0) ? $res->result_array() : false;
        return $result;
    }

    /**
     * 
     * @param type $child_ids
     * @return array
     */
    public function get_child_for_vaccination($child_ids = null) {

        $condition = "child_id = " . "'" . $child_ids . "'";
        $this->db->select('*');
        $this->db->from($this->children_details);
        $this->db->where($condition);
        $query = $this->db->get();
        $str = $this->db->last_query();
//    echo "<pre>";print_r($str);exit;
        $result = ($query->num_rows() > 0) ? $query->result_array() : false;
        return $result;
    }

    // Function for finding first and last 
    // occurrence of an elements 
    public function findFirstOccurance($arr, $x) {
        $first = -1;
        for ($i = 0; $i < count($arr); $i++) {
            if ($x != $arr[$i])
                continue;
            if ($first == -1)
                $first = $i;
        }
        if ($first != -1)
            echo "First Occurrence = ", $first;
        else
            echo "Not Found";
    }

    // Read data from database to show data in admin page
    public function get_mother_detials($mobile_number) {

        $condition = "mthrs_mbl_no LIKE " . "'" . $mobile_number . "%'";
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where($condition);
        $this->db->limit(10);
        $query = $this->db->get();

//                    return $query->result();
//                    $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        $result = ($query->num_rows() > 0) ? $query->result_array() : false;
        return $result;
    }

    // Read data from database to show data in admin page
    public function get_child_details($mobile_number) {

        $condition = "child_contact = " . "'" . $mobile_number . "'";
        $this->db->select('*');
        $this->db->from($this->children_details);
        $this->db->where($condition);
        $query = $this->db->get();
//            print_r($query);
        $str = $this->db->last_query();
//    echo "<pre>";print_r($str);exit;
        $result = ($query->num_rows() > 0) ? $query->result_array() : false;
        return $result;
    }
    
    
    public function get_vaccinations_done_today() {

        $today = date('Y-m-d');
        $query = "SELECT c.* FROM " . $this->children_details . " c LEFT JOIN " . $this->table . " m ON "
                . "m.mthrs_mbl_no = c.child_contact WHERE ";

        foreach ($this->vaccination_arr as $v => $vaccination):
            $query .= ($v != 0) ? " OR " : '';
            $query .= " (" . $vaccination . $this->date_arr[2] . " = '$today' ) ";
        endforeach;

        // appending limit
        $query .= " GROUP BY c.child_id ";      

//        echo $query;
        $res = $this->db->query($query);
//        echo '<pre>';print_r($res);die;
        $result = ($res->num_rows() > 0) ? $res->result_array() : false;
        return $result;
    }
    
    public function add_mother_details($data) {

        print_r($data);
        print_r(json_encode($data));
        die;
        $today = date('Y-m-d');
        
        $mother_unique_number = rand(1001,9999);
        $child_unique_number = 'UNIQUE'.rand(10001,99999);
        
        $mthr_query = "INSERT INTO " . $this->table . " (`mthrs_db_id`, `mthrs_name`, `mthrs_last_name`,"
                . " `mthrs_unq_no`, `mthrs_mbl_no`, `mthrs_optn_mbl_no`, `mthrs_passwrd`, `age`, `area`,"
                . " `area_code`, `anm_name`, `anm_contact`, `asha_name`, `asha_contact`, `mthr_status`) "
                . "VALUES (NULL, '".$data['mother_name']."', NULL, '".$mother_unique_number."',"
                . " '".$data['mobile']."', NULL, '".substr($data['mobile'],0,-5)."', '".$data['mother_age']."',"
                . " '".$data['area_name']."', '".$data['area_name']."', '".$data['anm_name']."', "
                . "'".$data['anm_contact']."', '".$data['asha_name']."', '".$data['asha_contact']."', 1);";
        $res = $this->db->query($mthr_query);
            $mothr_id = $this->db->insert_id();
//            $mothr_id = 428;
        
        // once mother data is added now add child data..
            // on if child data is provided..
            if(isset($data['child_name']) && isset($data['child_dob']))
            {
        $vaccine_qry = '';
        $vaccine_val_qry = '';
        $comma = ',';
        foreach($this->vaccination_arr as $v => $vaccination):

            if(in_array($vaccination,$data['vaccinations'])){
                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[2] . "`" . $comma;
                $vaccine_val_qry .= " 'true', '$today' ".$comma;
            }else{
                $vaccine_qry .= " `" . $vaccination . "`" . $comma;
                $vaccine_val_qry .= " 'false' ".$comma;
            }
        endforeach;

        
//        echo '<br/>vaccine qry; ',$vaccine_qry;echo '<br/>vaccing val qry: ',$vaccine_val_qry;die;
        
        $child_qry = "INSERT INTO " . $this->children_details . " (`child_id`, `mthr_id`, `mother_name`,"
                . " `child_contact`, `child_unq_id`, `child_name`, `child_dob`, `child_status`, `is_vacinated_before`,"
                . $vaccine_qry
                . " `added_time`) "
                . "VALUES (NULL, '".$mothr_id."', '".$data['mother_name']."', '".$data['mobile']."',"
                . " '".$child_unique_number."', '".$data['child_name']."', '".date('Y-m-d',strtotime($data['child_dob']))."',"
                . " 'yes','yes',"
                . $vaccine_val_qry
                . " NOW() "
                . ");";
        
        $res = $this->db->query($child_qry);
            $child_id = $this->db->insert_id();
            

//        echo $mthr_query,'<br/>Child query: <br/>',$child_qry;
            }
        $result = ($child_id || $mothr_id) ? true : false;
        return $result;
    }
    
    public function sample_query() {
        
        $today = date('Y-m-d');
        $data['child_dob'] = '2019-11-29';
        $vaccine_qry = '';
        $vaccine_val_qry = '';
        $comma = ',';
        $data['vaccinations'] = array('BCG','OPV_O');
        foreach ($this->vaccination_arr as $v => $vaccination):
            $vaccine_date = (!empty($this->vaccination_daydiff_arr[$vaccination]['_date'])) ? date('Y-m-d', strtotime($data['child_dob']. ' + '.$this->vaccination_daydiff_arr[$vaccination]['_date'])) : $data['child_dob'];
                $done_date = (!empty($this->vaccination_daydiff_arr[$vaccination]['_last_date'])) ? date('Y-m-d', strtotime($data['child_dob']. ' + '.$this->vaccination_daydiff_arr[$vaccination]['_last_date'])) : $data['child_dob'];
            if (in_array($vaccination, $data['vaccinations'])) {
                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "`, `" . $vaccination . $this->date_arr[1] . "` , `" . $vaccination . $this->date_arr[2] . "`" . $comma;
                
                $vaccine_val_qry .= " 'true', '" . $vaccine_date ."' , '" . $done_date  . "' , '$today' " . $comma;
            } else {
                $vaccine_qry .= " `" . $vaccination . "`, `" . $vaccination . $this->date_arr[0] . "` , `" . $vaccination . $this->date_arr[1] . "`" . $comma;
                $vaccine_val_qry .= " 'false', '" . $vaccine_date ."' , '" . $done_date . "' " . $comma;
            }
        endforeach;
        
        echo '<br/><b>vaccine qry; </b>',$vaccine_qry;echo '<br/><b>vaccing val qry:</b> ',$vaccine_val_qry;
        

    }

}
