<?php

#session_start(); //we need to start session in order to access it through CI

Class User extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// Load form helper library
		$this->load->helper('form');

		// Load form validation library
		$this->load->library('form_validation');

		// Load session library
		$this->load->library('session');

		// Load database
		$this->load->model('user_model');
	}

	// Show login page
	public function index() {

	$this->load->view('login_form_hindi');

	}

	// Show registration page
	public function user_registration_show() {
		$this->load->view('registration_form');
	}

	// Validate and store registration data in database
	public function new_user_registration() {

		// Check validation for user input in SignUp form
		$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('email_value', 'Email', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('registration_form');
		} else {
			$data = array(
			'username' => $this->input->post('username'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'password' => $this->input->post('password')
			);
			$result = $this->user_model->registration_insert($data);
			if ($result == TRUE) {
				$data['message_display'] = 'Registration Successfully !';
				$this->load->view('login_form', $data);
			} else {
				$data['message_display'] = 'Username already exist!';
				$this->load->view('registration_form', $data);
			}
		}
	}

	// Check for user login process
	public function user_login_process() {


		$this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|xss_clean');
		$this->form_validation->set_rules('code', 'Code', 'trim|required|xss_clean');

		/*if ($this->form_validation->run() == FALSE) {
		if(isset($this->session->userdata['logged_in'])){
		$this->load->view('mother_search');
		}else{
		$this->load->view('login_form');
		}
		} else {*/
		$data = array(
			'mobile' => $this->input->post('mobile'),
			'code' => $this->input->post('code')
		);
		$result = $this->user_model->login($data);

		if ($result == TRUE) {

			$mobile = $this->input->post('mobile');
			$result = $this->user_model->read_user_information($mobile);
			if ($result != false) {
				$session_data = array(
				'user_id' => $result[0]->id,
				'username' => $result[0]->username,
				'first_name' => $result[0]->first_name,
				'last_name' => $result[0]->last_name,
				);
			// Add user data in session
			$this->session->set_userdata('logged_in', $session_data);
			redirect('anm/index');

		}
		} else {
			$data = array(
			'error_message' => 'Invalid Username or Password'
			);
			$this->load->view('login_form', $data);
		}
	}

	// Logout from admin page
	public function logout() {

		// Removing session data
		$sess_array = array(
		'username' => ''
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$data['message_display'] = 'Successfully Logout';
		redirect('/', $data);
	}


	public function search_mother(){

		$mobile_number = $this->input->post('mobile');
		echo json_encode($this->user_model->get_mother_detials($mobile_number));
		//return json_encode(array'mother_details'=>$this->user_model->get_mother_detials($mobile_number));
	}


}

?>
