<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

        <title>OneKeyCare | आर आई सिस्टम</title>
        
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        

<!--        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/shared/style.css">

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/demo_1/style.css">        -->
        
        
        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/signin.css" />
        <link rel="stylesheet" media="screen and (max-width: 768px)" href="<?php echo base_url(); ?>assets/css/mobile.css" />
        <!--<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">-->
<!--        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>-->

    </head>
    <script>
        var api_url = '<?php echo public_api_url() ?>';
        var client_service = '<?php echo client_service ?>';
        var auth_key = '<?php echo auth_key ?>';

        var token = '<?php echo $_SESSION['token'] ?>';
        var user_id = '<?php echo $_SESSION['user_id'] ?>';

    </script>
    <body>

