<style type="text/css">
    .btn{
        color: #fff;
        font-size: 16px !important;
    }
    td{

        /* width: 33.5%;*/
        border: 1px solid #f2f4f9;
        padding: 10px;
    }

    .sls{
        /*font-size:10px;
        font-weight:700;
        width: 24%;
        float: left;*/

        font-size: 13px;
        font-weight: 700;
        /*width: 100%;*/
        /* float: left;*/
        color :#000;
    }

    .sls span{
        font-size:16px;
        font-weight:700;
        width: 100%;
        color: green;
        /*float: right;*/
    }

</style>

<div class="row">

    <div class="col-md-12">

        <div class="grid">
            <p class="grid-header"><?php echo $this->lang->line('details_of_mother') ?></p>
            <div class="grid-body">
                <div class="row">
                    <div class="col-md-8 alert alert-success" id="msg">
                    </div>
                </div>


                <div class="row">

                    <div class="col-md-12">

                        <div class="table-responsive" id="mother_details" >

                            <div class="options" >

                                <a href="<?php echo base_url(); ?>anm/check_mother"> Back To Check Mother</a>








                                <table id="table" class="table table-bordered">
                                    <tr>


                                        <th>Mother's INFO</th> 
                                        <th></th> 

                                    </tr>


                                    <tbody>
                                        <tr><td class="sls"> Mother ID :</td><td class="sls"> <span> MFZ-000-<span class="mother_id"></span></span>  </a></td> </tr>

                                        <tr><td class="sls">  Mother Name :</td><td class="sls">  <span class="mother_name">  </span>  </a></td> </tr>

                                        <tr><td class="sls"> Contact : </td><td class="sls"> <span class="mother_contact"> </span>  </a></td> </tr>

                                        <!--
                                        <?php
//foreach ($child_n_details as $child_n_details) { 
                                        ?>
                                        <tr><td><a href="#" class="sls" > Child-Name : </a><a href="<?php echo base_url(); ?>anm/findchild/<?php echo $child_n_details->child_id; ?>/<?php echo $child_n_details->child_contact; ?>"><span class="btn btn-success" > <?php echo $child_n_details->child_name; ?> </span> </a></td> <td><a href="#" class="sls" > Child-Dob : <span> <?php echo $child_n_details->child_dob; ?> </span></a> </td>  </tr>
                                         
                                        <?php // } ?>
                                         
                                        -->



                                    </tbody>


<?php //  }   ?>

                                </table>
                                
                                <table class="table table-responsive table-bordered" id="children_details_table">
                                    <thead>
                                        <tr>
                                            <th>Child name</th>
                                            <th>Child DOB</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>

                            </div> 
                        </div> </div>
                </div>







            </div>
        </div>
    </div>
</div>
<?php
$mobile = $this->uri->segment(4);
$mother_id = $this->uri->segment(3);
?>
<script>

    get_mother_by_id_and_phone('<?php echo $mother_id ?>', '<?php echo $mobile ?>');

    function get_mother_by_id_and_phone(mother_id, phone_number) {

        $.ajax({
            url: api_url + "api/get_mother_by_id_and_phone/",
            method: "POST",
            data: JSON.stringify({"mthr_id": mother_id, "mobile": phone_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $("#msg").hide();
            },
            success: function (data)
            {
                
//                console.log(data);
                if(data.status=='200'){
                    var myObj = data.data;
                    $(".mother_id").text(myObj.mthrs_db_id);
                    $(".mother_name").text(myObj.mthrs_name);
                    $(".mother_contact").text(myObj.mthrs_mbl_no);
                }else{
                    $("msg").addClass('alert alert-warning').removeClass('alert-success').text('no details found!');
                }

            }
        });
    }



    get_child_by_mother_id_and_phone('<?php echo $mother_id ?>', '<?php echo $mobile ?>');

    function get_child_by_mother_id_and_phone(mother_id, phone_number) {

        $.ajax({
            url: api_url + "api/get_child_by_mother_id_and_phone/",
            method: "POST",
            data: JSON.stringify({"mthr_id": mother_id, "mobile": phone_number}),
            headers: {
                "Authorization": token,
                "User-ID": user_id,
                "Content-Type": "application/json"
            },
            beforeSend: function () {
                $("#msg").hide();
            },
            success: function (data)
            {
               if(data.status=='200'){
                    
                    var childObj = data.data;
//                    console.log(childObj);
                    var child_row='';
                    for(var i in childObj){
                        console.log(childObj[i].child_name);
                        console.log(childObj[i].child_contact);
                        console.log(childObj[i].child_dob);
                        child_row +="<tr><td><a href='#' class=\"sls\" > Child-Name : </a><a href='<?php echo base_url() ?>anm/update_child/" + childObj[i].child_id + "/" 
                                + childObj[i].child_contact + "'><span class='btn btn-success' >" + childObj[i].child_name +
                                " </span> </a></td> <td><a href=\"#\" class=\"sls\" > Child-Dob : <span> " +
                                childObj[i].child_dob + " </span></a> </td>  </tr>";
                    }
                    $("#children_details_table").append(child_row);
                }else{
                    $("#children_details_table").append("<tr><td colspan='2'>No child</td></tr>");
                }
            }
        });
    }



</script>


