
<!-- partial -->
    
<div class="row">
    <div class="col-md-12">
    <form class="form-inline my-2 my-lg-0">
        
        <input class="form-control input-lg" type="text" id="mother_mobile" placeholder="खोजें" aria-label="खोजें">
        &nbsp;माँ के नाम / बच्चे के नाम / मोबाइल का उपयोग करके खोजें
      <!--<button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>-->
    </form>
    </div>
</div>
            <div class="row">
                
                <div class="col-md-12">
                    <div class="msg success"></div>
                </div>
                <div class="col-md-12">
                    <div class="grid">
                        <br/>
                        <div id="mother_data_result_div" class="table-responsive" >
					<table class="table info-table table-dark" id="mother_search_result">
                                            <thead><tr><td>इसका चयन करें</td><th>मां का नाम</th><th>मोबाइल नंबर</th><th>स्थान</th><th>आशा का नाम</th></tr></thead>
						<tbody></tbody>
					</table>
				</div>
				<div id="child_data_result_div" class="table-responsive" >
					<table class="table info-table table-dark" id="child_search_result">
                                            <thead><tr><td>इसका चयन करें</td><td>बच्चे का नाम</td><th>मां का नाम</th><th>मोबाइल नंबर</th><th>DOB</th></tr></thead>
						<tbody></tbody>
					</table>
				</div>
                        
                        
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="panel-title">आज की टीकाकरण सूची</h3>
                                </div>
                            </div>
                        </div>
                            <div class="panel-body" id="vaccination_list">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr class="solid-header">
                                        <th>मां का नाम</th>
                                        <th>बच्चे का नाम</th>
                                        <th>मोबाइल नंबर</th>
                                        <th>टीका</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php if (is_array($upcoming_ri_due_list) && count($upcoming_ri_due_list)): ?>
                                        <?php foreach ($upcoming_ri_due_list as $upcoming_ri_due): ?>
                                            <tr>
                                                <td class="pr-0 pl-4">
                                                    <!--<pre><?php //print_r($vaccination_arr)  ?></pre>-->
                                                    <a class="" href="tel:<?php echo $upcoming_ri_due['child_contact'] ?>">Call</a> | <a href="#">Send SMS</a>
                                                </td>
                                                <td class="pl-md-0">
                                                    <small class="text-black font-weight-medium d-block"><?php echo $upcoming_ri_due['mother_name'] ?></small>
                                                    <span class="text-gray">
                                                        <span class="status-indicator rounded-indicator small bg-primary"></span><?php echo $upcoming_ri_due['child_name'] ?> </span>
                                                </td>
                                                <td>
                                                    <small><?php echo $upcoming_ri_due['child_contact'] ?></small>
                                                </td>
<!--                                                <td> <?php
                                                    //echo findFirstOccurance($upcoming_ri_due,'false');
                                                    $vaccination = array_search('false', $upcoming_ri_due);
                                                    echo $vaccination, " | ", date_format(date_create($upcoming_ri_due[$vaccination . '_last_date']), 'd-m-Y');
                                                    ?></td>-->
                                                <td> <?php
                                                    // showing last 2 due ..

                                                    $last_vaccination = findFirstOccurance($upcoming_ri_due, 'false');
                                                    //echo $last_vaccination;

                                                    $vaccination_key = array_search($last_vaccination, $vaccination_arr);
                                                    $initial_loop = ($vaccination_key - 2) > 0 ? $vaccination_key - 2 : 0;
                                                    $final_loop = $vaccination_key + 5;
                                                    for ($v = $initial_loop; $v <= $final_loop; $v++):
                                                        ?>

                                                    <input class="vaccination_done" data-value="<?php echo $upcoming_ri_due['child_id'] ?>" type="checkbox" name="vaccinations_done[<?php echo $upcoming_ri_due['child_id'] ?>][]" <?php echo ($upcoming_ri_due[$vaccination_arr[$v]] == 'true') ? 'checked="checked" disabled="disabled"' : '' ?> value="<?php echo $vaccination_arr[$v] ?>" /> <?php echo ($vaccination_arr[$v]); ?>&nbsp;|&nbsp;
                                                    <?php
                                                    endfor;
                                                    
                                                    ?></td>

                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                            <tr>
                                                <td colspan="4">आज के लिए कोई परिणाम नहीं मिला</td>
                                            </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        </div>
                        
                    </div>
                </div>
                

            </div>

    <!-- content viewport ends -->
